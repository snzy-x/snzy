var _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
};

(global.webpackJsonp = global.webpackJsonp || []).push([ [ "common/vendor" ], {
    "0ca3": function(t, e) {
        var n = require("../siteinfo");
        t.exports = n;
    },
    "14a6": function(e, t, n) {
        (function(r) {
            var t = {
                getClipboardData: function(t, e, n) {
                    r.setClipboardData({
                        data: t,
                        success: function(t) {
                            "function" == typeof e && e(!0);
                        },
                        fail: function(t) {
                            "function" == typeof e && e(!1);
                        }
                    });
                }
            };
            e.exports = {
                getClipboardData: t.getClipboardData
            };
        }).call(this, n("543d").default);
    },
    "3a75": function(n, t, l) {
        (function(o) {
            var e = t(l("542b")), i = t(l("0ca3"));
            function t(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            function a(t, e, n) {
                return e in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t;
            }
            var s = {};
            s.md5 = function(t) {
                return (0, e.default)(t);
            }, s.url = function(t, e) {
                var n = i.default.siteroot + "?i=" + i.default.uniacid + "&t=" + i.default.multiid + "&v=" + i.default.version + "&";
                if (t && ((t = t.split("/"))[0] && (n += "c=" + t[0] + "&"), t[1] && (n += "a=" + t[1] + "&"), 
                t[2] && (n += "do=" + t[2] + "&")), e && "object" === (void 0 === e ? "undefined" : _typeof(e))) for (var r in e) r && e.hasOwnProperty(r) && e[r] && (n += r + "=" + e[r] + "&");
                return n;
            }, s.request = function(e) {
                l("a035"), e = e || {};
                var t, n, r = o.getStorageSync("userInfo").sessionid, i = e.url;
                if (-1 == i.indexOf("http://") && -1 == i.indexOf("https://") && (i = s.url(i)), 
                (t = i, n = "state", n = new RegExp("(^|&)" + n + "=([^&]*)(&|$)"), null != (n = t.split("?")[1].match(n)) ? unescape(n[2]) : null) || e.data && e.data.state || !r || (i = i + "&state=we7sid-" + r), 
                e.data && e.data.m || (i += "&m=baiban_wxlinks"), !i) return !1;
                e.hideloading || o.showLoading({
                    mask: !0,
                    title: "加载中"
                }), o.request((a(i = {
                    url: i,
                    data: e.data || {},
                    header: e.header || {},
                    method: e.method || "GET"
                }, "header", {
                    "content-type": "application/x-www-form-urlencoded"
                }), a(i, "success", function(t) {
                    if (o.hideLoading(), t.data.errno) {
                        if ("41009" == t.data.errno) return o.setStorageSync("userInfo", ""), void s.getUserInfo(function() {
                            s.request(e);
                        });
                        e.fail && "function" == typeof e.fail ? e.fail(t) : t.data.message && (null != t.data.data && t.data.data.redirect && t.data.data.redirect, 
                        o.showToast({
                            icon: "none",
                            title: t.data.message
                        }));
                    } else e.success && "function" == typeof e.success && e.success(t);
                }), a(i, "fail", function(t) {
                    o.hideLoading(), e.fail && "function" == typeof e.fail && e.fail(t);
                }), a(i, "complete", function(t) {
                    e.complete && "function" == typeof e.complete && e.complete(t);
                }), i));
            }, s.getWe7User = function(e, t) {
                var n = o.getStorageSync("userInfo") || {};
                s.request({
                    url: "auth/session/openid",
                    data: {
                        code: t || ""
                    },
                    success: function(t) {
                        t.data.errno || (n.sessionid = t.data.data.sessionid, n.memberInfo = t.data.data.userinfo, 
                        o.setStorageSync("userInfo", n)), "function" == typeof e && e(n);
                    }
                });
            }, s.checkSession = function(e) {
                s.request({
                    url: "auth/session/check",
                    method: "POST",
                    success: function(t) {
                        t.data.errno ? "function" == typeof e.fail && e.fail() : "function" == typeof e.success && e.success();
                    },
                    fail: function() {
                        "function" == typeof e.fail && e.fail();
                    }
                });
            }, s.getUserInfo = function(e) {
                function t() {
                    console.log("start login"), o.login({
                        success: function(t) {
                            s.getWe7User(function(t) {
                                "function" == typeof e && e(t);
                            }, t.code);
                        },
                        fail: function() {
                            o.showModal({
                                title: "获取信息失败",
                                content: "请允许授权以便为您提供给服务",
                                success: function(t) {}
                            });
                        }
                    });
                }
                var n = o.getStorageSync("userInfo") || {};
                n.sessionid ? s.checkSession({
                    success: function() {
                        "function" == typeof e && e(n);
                    },
                    fail: function() {
                        n.sessionid = "", console.log("relogin"), o.removeStorageSync("userInfo"), t();
                    }
                }) : t();
            }, n.exports = s;
        }).call(this, l("543d").default);
    },
    "542b": function(t, e) {
        function h(t, e) {
            var n = (65535 & t) + (65535 & e);
            return (t >> 16) + (e >> 16) + (n >> 16) << 16 | 65535 & n;
        }
        function s(t, e, n, r, i, o) {
            return h((o = h(h(e, t), h(r, o))) << i | o >>> 32 - i, n);
        }
        function f(t, e, n, r, i, o, a) {
            return s(e & n | ~e & r, t, e, i, o, a);
        }
        function p(t, e, n, r, i, o, a) {
            return s(e & r | n & ~r, t, e, i, o, a);
        }
        function d(t, e, n, r, i, o, a) {
            return s(e ^ n ^ r, t, e, i, o, a);
        }
        function g(t, e, n, r, i, o, a) {
            return s(n ^ (e | ~r), t, e, i, o, a);
        }
        function a(t, e) {
            var n, r, i, o;
            t[e >> 5] |= 128 << e % 32, t[14 + (e + 64 >>> 9 << 4)] = e;
            for (var a = 1732584193, s = -271733879, l = -1732584194, c = 271733878, u = 0; u < t.length; u += 16) s = g(s = g(s = g(s = g(s = d(s = d(s = d(s = d(s = p(s = p(s = p(s = p(s = f(s = f(s = f(s = f(r = s, l = f(i = l, c = f(o = c, a = f(n = a, s, l, c, t[u], 7, -680876936), s, l, t[u + 1], 12, -389564586), a, s, t[u + 2], 17, 606105819), c, a, t[u + 3], 22, -1044525330), l = f(l, c = f(c, a = f(a, s, l, c, t[u + 4], 7, -176418897), s, l, t[u + 5], 12, 1200080426), a, s, t[u + 6], 17, -1473231341), c, a, t[u + 7], 22, -45705983), l = f(l, c = f(c, a = f(a, s, l, c, t[u + 8], 7, 1770035416), s, l, t[u + 9], 12, -1958414417), a, s, t[u + 10], 17, -42063), c, a, t[u + 11], 22, -1990404162), l = f(l, c = f(c, a = f(a, s, l, c, t[u + 12], 7, 1804603682), s, l, t[u + 13], 12, -40341101), a, s, t[u + 14], 17, -1502002290), c, a, t[u + 15], 22, 1236535329), l = p(l, c = p(c, a = p(a, s, l, c, t[u + 1], 5, -165796510), s, l, t[u + 6], 9, -1069501632), a, s, t[u + 11], 14, 643717713), c, a, t[u], 20, -373897302), l = p(l, c = p(c, a = p(a, s, l, c, t[u + 5], 5, -701558691), s, l, t[u + 10], 9, 38016083), a, s, t[u + 15], 14, -660478335), c, a, t[u + 4], 20, -405537848), l = p(l, c = p(c, a = p(a, s, l, c, t[u + 9], 5, 568446438), s, l, t[u + 14], 9, -1019803690), a, s, t[u + 3], 14, -187363961), c, a, t[u + 8], 20, 1163531501), l = p(l, c = p(c, a = p(a, s, l, c, t[u + 13], 5, -1444681467), s, l, t[u + 2], 9, -51403784), a, s, t[u + 7], 14, 1735328473), c, a, t[u + 12], 20, -1926607734), l = d(l, c = d(c, a = d(a, s, l, c, t[u + 5], 4, -378558), s, l, t[u + 8], 11, -2022574463), a, s, t[u + 11], 16, 1839030562), c, a, t[u + 14], 23, -35309556), l = d(l, c = d(c, a = d(a, s, l, c, t[u + 1], 4, -1530992060), s, l, t[u + 4], 11, 1272893353), a, s, t[u + 7], 16, -155497632), c, a, t[u + 10], 23, -1094730640), l = d(l, c = d(c, a = d(a, s, l, c, t[u + 13], 4, 681279174), s, l, t[u], 11, -358537222), a, s, t[u + 3], 16, -722521979), c, a, t[u + 6], 23, 76029189), l = d(l, c = d(c, a = d(a, s, l, c, t[u + 9], 4, -640364487), s, l, t[u + 12], 11, -421815835), a, s, t[u + 15], 16, 530742520), c, a, t[u + 2], 23, -995338651), l = g(l, c = g(c, a = g(a, s, l, c, t[u], 6, -198630844), s, l, t[u + 7], 10, 1126891415), a, s, t[u + 14], 15, -1416354905), c, a, t[u + 5], 21, -57434055), l = g(l, c = g(c, a = g(a, s, l, c, t[u + 12], 6, 1700485571), s, l, t[u + 3], 10, -1894986606), a, s, t[u + 10], 15, -1051523), c, a, t[u + 1], 21, -2054922799), l = g(l, c = g(c, a = g(a, s, l, c, t[u + 8], 6, 1873313359), s, l, t[u + 15], 10, -30611744), a, s, t[u + 6], 15, -1560198380), c, a, t[u + 13], 21, 1309151649), l = g(l, c = g(c, a = g(a, s, l, c, t[u + 4], 6, -145523070), s, l, t[u + 11], 10, -1120210379), a, s, t[u + 2], 15, 718787259), c, a, t[u + 9], 21, -343485551), 
            a = h(a, n), s = h(s, r), l = h(l, i), c = h(c, o);
            return [ a, s, l, c ];
        }
        function l(t) {
            for (var e = "", n = 32 * t.length, r = 0; r < n; r += 8) e += String.fromCharCode(t[r >> 5] >>> r % 32 & 255);
            return e;
        }
        function c(t) {
            var e = [];
            for (e[(t.length >> 2) - 1] = void 0, r = 0; r < e.length; r += 1) e[r] = 0;
            for (var n = 8 * t.length, r = 0; r < n; r += 8) e[r >> 5] |= (255 & t.charCodeAt(r / 8)) << r % 32;
            return e;
        }
        function r(t) {
            for (var e, n = "0123456789abcdef", r = "", i = 0; i < t.length; i += 1) e = t.charCodeAt(i), 
            r += n.charAt(e >>> 4 & 15) + n.charAt(15 & e);
            return r;
        }
        function n(t) {
            return unescape(encodeURIComponent(t));
        }
        function i(t) {
            return l(a(c(t = n(t)), 8 * t.length));
        }
        function o(t, e) {
            return function(t, e) {
                var n, r = c(t), i = [], o = [];
                for (i[15] = o[15] = void 0, 16 < r.length && (r = a(r, 8 * t.length)), n = 0; n < 16; n += 1) i[n] = 909522486 ^ r[n], 
                o[n] = 1549556828 ^ r[n];
                return e = a(i.concat(c(e)), 512 + 8 * e.length), l(a(o.concat(e), 640));
            }(n(t), n(e));
        }
        t.exports = function(t, e, n) {
            return e ? n ? o(e, t) : r(o(e, t)) : n ? i(t) : r(i(t));
        };
    },
    "543d": function(t, e, n) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.createApp = jt, e.createComponent = Xt, e.createPage = Vt, e.createSubpackageApp = Gt, 
        e.default = void 0;
        var r, c = (r = n("66fd")) && r.__esModule ? r : {
            default: r
        };
        function i(e, t) {
            var n, r = Object.keys(e);
            return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(e), t && (n = n.filter(function(t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })), r.push.apply(r, n)), r;
        }
        function o(t, e) {
            return function(t) {
                if (Array.isArray(t)) return t;
            }(t) || function(t, e) {
                if ("undefined" != typeof Symbol && Symbol.iterator in Object(t)) {
                    var n = [], r = !0, i = !1, o = void 0;
                    try {
                        for (var a, s = t[Symbol.iterator](); !(r = (a = s.next()).done) && (n.push(a.value), 
                        !e || n.length !== e); r = !0) ;
                    } catch (t) {
                        i = !0, o = t;
                    } finally {
                        try {
                            r || null == s.return || s.return();
                        } finally {
                            if (i) throw o;
                        }
                    }
                    return n;
                }
            }(t, e) || s(t, e) || function() {
                throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
            }();
        }
        function u(t, e, n) {
            return e in t ? Object.defineProperty(t, e, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[e] = n, t;
        }
        function a(t) {
            return function(t) {
                if (Array.isArray(t)) return l(t);
            }(t) || function(t) {
                if ("undefined" != typeof Symbol && Symbol.iterator in Object(t)) return Array.from(t);
            }(t) || s(t) || function() {
                throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
            }();
        }
        function s(t, e) {
            if (t) {
                if ("string" == typeof t) return l(t, e);
                var n = Object.prototype.toString.call(t).slice(8, -1);
                return "Object" === n && t.constructor && (n = t.constructor.name), "Map" === n || "Set" === n ? Array.from(t) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? l(t, e) : void 0;
            }
        }
        function l(t, e) {
            (null == e || e > t.length) && (e = t.length);
            for (var n = 0, r = new Array(e); n < e; n++) r[n] = t[n];
            return r;
        }
        var h = Object.prototype.toString, f = Object.prototype.hasOwnProperty;
        function p(t) {
            return "function" == typeof t;
        }
        function d(t) {
            return "string" == typeof t;
        }
        function g(t) {
            return "[object Object]" === h.call(t);
        }
        function y(t, e) {
            return f.call(t, e);
        }
        function v() {}
        function x(e) {
            var n = Object.create(null);
            return function(t) {
                return n[t] || (n[t] = e(t));
            };
        }
        var m = /-(\w)/g, _ = x(function(t) {
            return t.replace(m, function(t, e) {
                return e ? e.toUpperCase() : "";
            });
        }), b = [ "invoke", "success", "fail", "complete", "returnValue" ], A = {}, S = {};
        function w(t, e) {
            t = e ? t ? t.concat(e) : Array.isArray(e) ? e : [ e ] : t;
            return t && function(t) {
                for (var e = [], n = 0; n < t.length; n++) -1 === e.indexOf(t[n]) && e.push(t[n]);
                return e;
            }(t);
        }
        function P(e, n) {
            Object.keys(n).forEach(function(t) {
                -1 !== b.indexOf(t) && p(n[t]) && (e[t] = w(e[t], n[t]));
            });
        }
        function T(n, r) {
            n && r && Object.keys(r).forEach(function(t) {
                var e;
                -1 !== b.indexOf(t) && p(r[t]) && (e = n[t], t = r[t], -1 !== (t = e.indexOf(t)) && e.splice(t, 1));
            });
        }
        function k(t) {
            return t && ("object" === (void 0 === t ? "undefined" : _typeof(t)) || "function" == typeof t) && "function" == typeof t.then;
        }
        function O(t, e) {
            for (var n = !1, r = 0; r < t.length; r++) {
                var i = t[r];
                if (n) n = Promise.resolve(function(e) {
                    return function(t) {
                        return e(t) || t;
                    };
                }(i)); else {
                    i = i(e);
                    if (k(i) && (n = Promise.resolve(i)), !1 === i) return {
                        then: function() {}
                    };
                }
            }
            return n || {
                then: function(t) {
                    return t(e);
                }
            };
        }
        function D(r, t) {
            var i = 1 < arguments.length && void 0 !== t ? t : {};
            return [ "success", "fail", "complete" ].forEach(function(e) {
                var n;
                Array.isArray(r[e]) && (n = i[e], i[e] = function(t) {
                    O(r[e], t).then(function(t) {
                        return p(n) && n(t) || t;
                    });
                });
            }), i;
        }
        function M(t, e) {
            var n = [];
            Array.isArray(A.returnValue) && n.push.apply(n, a(A.returnValue));
            t = S[t];
            return t && Array.isArray(t.returnValue) && n.push.apply(n, a(t.returnValue)), n.forEach(function(t) {
                e = t(e) || e;
            }), e;
        }
        function C(t, e, n) {
            for (var r = arguments.length, i = new Array(3 < r ? r - 3 : 0), o = 3; o < r; o++) i[o - 3] = arguments[o];
            var a = function(t) {
                var e = Object.create(null);
                Object.keys(A).forEach(function(t) {
                    "returnValue" !== t && (e[t] = A[t].slice());
                });
                var n = S[t];
                return n && Object.keys(n).forEach(function(t) {
                    "returnValue" !== t && (e[t] = (e[t] || []).concat(n[t]));
                }), e;
            }(t);
            return a && Object.keys(a).length ? Array.isArray(a.invoke) ? O(a.invoke, n).then(function(t) {
                return e.apply(void 0, [ D(a, t) ].concat(i));
            }) : e.apply(void 0, [ D(a, n) ].concat(i)) : e.apply(void 0, [ n ].concat(i));
        }
        var $ = {
            returnValue: function(t) {
                return k(t) ? t.then(function(t) {
                    return t[1];
                }).catch(function(t) {
                    return t[0];
                }) : t;
            }
        }, F = /^\$|Window$|WindowStyle$|sendNativeEvent|restoreGlobal|getCurrentSubNVue|getMenuButtonBoundingClientRect|^report|interceptors|Interceptor$|getSubNVueById|requireNativePlugin|upx2px|hideKeyboard|canIUse|^create|Sync$|Manager$|base64ToArrayBuffer|arrayBufferToBase64/, L = /^create|Manager$/, R = [ "createBLEConnection" ], j = [ "createBLEConnection" ], I = /^on|^off/;
        function E(t) {
            return L.test(t) && -1 === R.indexOf(t);
        }
        function z(t) {
            return F.test(t) && -1 === j.indexOf(t);
        }
        function W(t) {
            return !(E(t) || z(t) || (t = t, I.test(t) && "onPush" !== t));
        }
        function N(i, o) {
            return W(i) ? function() {
                for (var n = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {}, t = arguments.length, r = new Array(1 < t ? t - 1 : 0), e = 1; e < t; e++) r[e - 1] = arguments[e];
                return p(n.success) || p(n.fail) || p(n.complete) ? M(i, C.apply(void 0, [ i, o, n ].concat(r))) : M(i, new Promise(function(t, e) {
                    C.apply(void 0, [ i, o, Object.assign({}, n, {
                        success: t,
                        fail: e
                    }) ].concat(r));
                }).then(function(t) {
                    return [ null, t ];
                }).catch(function(t) {
                    return [ t ];
                }));
            } : o;
        }
        Promise.prototype.finally || (Promise.prototype.finally = function(e) {
            var n = this.constructor;
            return this.then(function(t) {
                return n.resolve(e()).then(function() {
                    return t;
                });
            }, function(t) {
                return n.resolve(e()).then(function() {
                    throw t;
                });
            });
        });
        var B = !1, U = 0, H = 0;
        var $ = {
            promiseInterceptor: $
        }, V = Object.freeze({
            __proto__: null,
            upx2px: function(t, e) {
                return 0 === U && (n = (i = wx.getSystemInfoSync()).platform, r = i.pixelRatio, 
                i = i.windowWidth, U = i, H = r, B = "ios" === n), 0 === (t = Number(t)) ? 0 : ((e = t / 750 * (e || U)) < 0 && (e = -e), 
                0 === (e = Math.floor(e + 1e-4)) && (e = 1 !== H && B ? .5 : 1), t < 0 ? -e : e);
                var n, r, i;
            },
            addInterceptor: function(t, e) {
                "string" == typeof t && g(e) ? P(S[t] || (S[t] = {}), e) : g(t) && P(A, t);
            },
            removeInterceptor: function(t, e) {
                "string" == typeof t ? g(e) ? T(S[t], e) : delete S[t] : g(t) && T(A, t);
            },
            interceptors: $
        });
        var X, G = "__DC_STAT_UUID";
        var $ = {
            returnValue: function(t) {
                var e;
                e = t, (X = X || wx.getStorageSync(G)) || (X = Date.now() + "" + Math.floor(1e7 * Math.random()), 
                wx.setStorage({
                    key: G,
                    data: X
                })), e.deviceId = X, (e = t).safeArea && (t = e.safeArea, e.safeAreaInsets = {
                    top: t.top,
                    left: t.left,
                    right: e.windowWidth - t.right,
                    bottom: e.windowHeight - t.bottom
                });
            }
        }, q = {
            redirectTo: {
                name: function(t) {
                    return "back" === t.exists && t.delta ? "navigateBack" : "redirectTo";
                },
                args: function(t) {
                    var e;
                    "back" === t.exists && t.url && (-1 === (e = function(t) {
                        for (var e = getCurrentPages(), n = e.length; n--; ) {
                            var r = e[n];
                            if (r.$page && r.$page.fullPath === t) return n;
                        }
                        return -1;
                    }(t.url)) || 0 < (e = getCurrentPages().length - 1 - e) && (t.delta = e));
                }
            },
            previewImage: {
                args: function(t) {
                    var n = parseInt(t.current);
                    if (!isNaN(n)) {
                        var r = t.urls;
                        if (Array.isArray(r)) {
                            var e = r.length;
                            if (e) return n < 0 ? n = 0 : e <= n && (n = e - 1), 0 < n ? (t.current = r[n], 
                            t.urls = r.filter(function(t, e) {
                                return !(e < n) || t !== r[n];
                            })) : t.current = r[0], {
                                indicator: !1,
                                loop: !1
                            };
                        }
                    }
                }
            },
            getSystemInfo: $,
            getSystemInfoSync: $
        }, J = [ "success", "fail", "cancel", "complete" ];
        function K(e, n, r) {
            return function(t) {
                return n(Q(e, t, r));
            };
        }
        function Y(t, e, n, r, i) {
            var o = 2 < arguments.length && void 0 !== n ? n : {}, a = 3 < arguments.length && void 0 !== r ? r : {}, s = 4 < arguments.length && void 0 !== i && i;
            if (g(e)) {
                var l, c, u = !0 === s ? e : {};
                for (l in p(o) && (o = o(e, u) || {}), e) y(o, l) ? (p(c = o[l]) && (c = c(e[l], e, u)), 
                c ? d(c) ? u[c] = e[l] : g(c) && (u[c.name || l] = c.value) : console.warn("The '".concat(t, "' method of platform '微信小程序' does not support option '").concat(l, "'"))) : -1 !== J.indexOf(l) ? p(e[l]) && (u[l] = K(t, e[l], a)) : s || (u[l] = e[l]);
                return u;
            }
            return p(e) && (e = K(t, e, a)), e;
        }
        function Q(t, e, n, r) {
            r = 3 < arguments.length && void 0 !== r && r;
            return p(q.returnValue) && (e = q.returnValue(t, e)), Y(t, e, n, {}, r);
        }
        function Z(i, t) {
            if (y(q, i)) {
                var o = q[i];
                return o ? function(t, e) {
                    var n = o;
                    p(o) && (n = o(t));
                    var r = [ t = Y(i, t, n.args, n.returnValue) ];
                    void 0 !== e && r.push(e), p(n.name) ? i = n.name(t) : d(n.name) && (i = n.name);
                    r = wx[i].apply(wx, r);
                    return z(i) ? Q(i, r, n.returnValue, E(i)) : r;
                } : function() {
                    console.error("Platform '微信小程序' does not support '".concat(i, "'."));
                };
            }
            return t;
        }
        var tt = Object.create(null);
        [ "onTabBarMidButtonTap", "subscribePush", "unsubscribePush", "onPush", "offPush", "share" ].forEach(function(t) {
            var r;
            tt[t] = (r = t, function(t) {
                var e = t.fail, n = t.complete, t = {
                    errMsg: "".concat(r, ":fail method '").concat(r, "' not supported")
                };
                p(e) && e(t), p(n) && n(t);
            });
        });
        var et = {
            oauth: [ "weixin" ],
            share: [ "weixin" ],
            payment: [ "wxpay" ],
            push: [ "weixin" ]
        };
        var nt, rt = Object.freeze({
            __proto__: null,
            getProvider: function(t) {
                var e = t.service, n = t.success, r = t.fail, i = t.complete, t = !1;
                et[e] ? (t = {
                    errMsg: "getProvider:ok",
                    service: e,
                    provider: et[e]
                }, p(n) && n(t)) : (t = {
                    errMsg: "getProvider:fail service not found"
                }, p(r) && r(t)), p(i) && i(t);
            }
        }), it = function() {
            return nt = nt || new c.default();
        };
        function ot(t, e, n) {
            return t[e].apply(t, n);
        }
        var at = Object.freeze({
            __proto__: null,
            $on: function() {
                return ot(it(), "$on", Array.prototype.slice.call(arguments));
            },
            $off: function() {
                return ot(it(), "$off", Array.prototype.slice.call(arguments));
            },
            $once: function() {
                return ot(it(), "$once", Array.prototype.slice.call(arguments));
            },
            $emit: function() {
                return ot(it(), "$emit", Array.prototype.slice.call(arguments));
            }
        }), st = Object.freeze({
            __proto__: null
        }), lt = Page, ct = Component, ut = /:/g, ht = x(function(t) {
            return _(t.replace(ut, "-"));
        });
        function ft(i) {
            var o;
            wx.canIUse("nextTick") && (o = i.triggerEvent, i.triggerEvent = function(t) {
                for (var e = arguments.length, n = new Array(1 < e ? e - 1 : 0), r = 1; r < e; r++) n[r - 1] = arguments[r];
                return o.apply(i, [ ht(t) ].concat(n));
            });
        }
        function pt(t, e) {
            var r = e[t];
            e[t] = r ? function() {
                ft(this);
                for (var t = arguments.length, e = new Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                return r.apply(this, e);
            } : function() {
                ft(this);
            };
        }
        lt.__$wrappered || (lt.__$wrappered = !0, Page = function() {
            var t = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {};
            return pt("onLoad", t), lt(t);
        }, Page.after = lt.after, Component = function() {
            var t = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {};
            return pt("created", t), ct(t);
        });
        function dt(t, e, n) {
            e.forEach(function(e) {
                !function e(n, t) {
                    if (!t) return !0;
                    if (c.default.options && Array.isArray(c.default.options[n])) return !0;
                    if (p(t = t.default || t)) return !!p(t.extendOptions[n]) || !!(t.super && t.super.options && Array.isArray(t.super.options[n]));
                    if (p(t[n])) return !0;
                    t = t.mixins;
                    return Array.isArray(t) ? !!t.find(function(t) {
                        return e(n, t);
                    }) : void 0;
                }(e, n) || (t[e] = function(t) {
                    return this.$vm && this.$vm.__call_hook(e, t);
                });
            });
        }
        var gt = [ String, Number, Boolean, Object, Array, null ];
        function yt(n) {
            return function(t, e) {
                this.$vm && (this.$vm[n] = t);
            };
        }
        function vt(t, e) {
            return Array.isArray(e) && 1 === e.length ? e[0] : e;
        }
        function xt(r, t) {
            var i = {};
            return 1 < arguments.length && void 0 !== t && t || (i.vueId = {
                type: String,
                value: ""
            }, i.generic = {
                type: Object,
                value: null
            }, i.vueSlots = {
                type: null,
                value: [],
                observer: function(t, e) {
                    var n = Object.create(null);
                    t.forEach(function(t) {
                        n[t] = !0;
                    }), this.setData({
                        $slots: n
                    });
                }
            }), Array.isArray(r) ? r.forEach(function(t) {
                i[t] = {
                    type: null,
                    observer: yt(t)
                };
            }) : g(r) && Object.keys(r).forEach(function(t) {
                var e, n = r[t];
                g(n) ? (p(e = n.default) && (e = e()), n.type = vt(0, n.type), i[t] = {
                    type: -1 !== gt.indexOf(n.type) ? n.type : null,
                    value: e,
                    observer: yt(t)
                }) : (n = vt(0, n), i[t] = {
                    type: -1 !== gt.indexOf(n) ? n : null,
                    observer: yt(t)
                });
            }), i;
        }
        function mt(n, t, r) {
            var i = {};
            return Array.isArray(t) && t.length && t.forEach(function(t, e) {
                var o, a;
                "string" == typeof t ? t ? "$event" === t ? i["$" + e] = r : "arguments" === t ? r.detail && r.detail.__args__ ? i["$" + e] = r.detail.__args__ : i["$" + e] = [ r ] : 0 === t.indexOf("$event.") ? i["$" + e] = n.__get_value(t.replace("$event.", ""), r) : i["$" + e] = n.__get_value(t) : i["$" + e] = n : i["$" + e] = (a = o = n, 
                t.forEach(function(t) {
                    var e, n, r = t[0], i = t[2];
                    !r && void 0 === i || (n = t[1], t = t[3], Number.isInteger(r) ? e = r : r ? "string" == typeof r && r && (e = 0 === r.indexOf("#s#") ? r.substr(3) : o.__get_value(r, a)) : e = a, 
                    Number.isInteger(e) ? a = i : n ? Array.isArray(e) ? a = e.find(function(t) {
                        return o.__get_value(n, t) === i;
                    }) : g(e) ? a = Object.keys(e).find(function(t) {
                        return o.__get_value(n, e[t]) === i;
                    }) : console.error("v-for 暂不支持循环数据：", e) : a = e[i], t && (a = o.__get_value(t, a)));
                }), a);
            }), i;
        }
        function _t(t, e, n, r, i, o) {
            var n = 2 < arguments.length && void 0 !== n ? n : [], r = 3 < arguments.length && void 0 !== r ? r : [], a = 4 < arguments.length ? i : void 0, s = 5 < arguments.length ? o : void 0, l = !1;
            if (a && (l = e.currentTarget && e.currentTarget.dataset && "wx" === e.currentTarget.dataset.comType, 
            !n.length)) return l ? [ e ] : e.detail.__args__ || e.detail;
            var c = mt(t, r, e), u = [];
            return n.forEach(function(t) {
                "$event" === t ? "__set_model" !== s || a ? a && !l ? u.push(e.detail.__args__[0]) : u.push(e) : u.push(e.target.value) : Array.isArray(t) && "o" === t[0] ? u.push(function(t) {
                    for (var e = {}, n = 1; n < t.length; n++) {
                        var r = t[n];
                        e[r[0]] = r[1];
                    }
                    return e;
                }(t)) : "string" == typeof t && y(c, t) ? u.push(c[t]) : u.push(t);
            }), u;
        }
        var bt = "~", At = "^";
        function St(s) {
            var l = this, t = ((s = function(t) {
                try {
                    t.mp = JSON.parse(JSON.stringify(t));
                } catch (t) {}
                return t.stopPropagation = v, t.preventDefault = v, t.target = t.target || {}, y(t, "detail") || (t.detail = {}), 
                y(t, "markerId") && (t.detail = "object" === _typeof(t.detail) ? t.detail : {}, 
                t.detail.markerId = t.markerId), g(t.detail) && (t.target = Object.assign({}, t.target, t.detail)), 
                t;
            }(s)).currentTarget || s.target).dataset;
            if (!t) return console.warn("事件信息不存在");
            t = t.eventOpts || t["event-opts"];
            if (!t) return console.warn("事件信息不存在");
            var r = s.type, c = [];
            return t.forEach(function(t) {
                var e = t[0], n = t[1], o = e.charAt(0) === At, a = (e = o ? e.slice(1) : e).charAt(0) === bt;
                e = a ? e.slice(1) : e, !n || (t = r) !== (e = e) && ("regionchange" !== e || "begin" !== t && "end" !== t) || n.forEach(function(t) {
                    var e = t[0];
                    if (e) {
                        var n = l.$vm;
                        if (n.$options.generic && (n = function(t) {
                            for (var e = t.$parent; e && e.$parent && (e.$options.generic || e.$parent.$options.generic || e.$scope._$vuePid); ) e = e.$parent;
                            return e && e.$parent;
                        }(n) || n), "$emit" !== e) {
                            var r = n[e];
                            if (!p(r)) throw new Error(" _vm.".concat(e, " is not a function"));
                            if (a) {
                                if (r.once) return;
                                r.once = !0;
                            }
                            var i = _t(l.$vm, s, t[1], t[2], o, e), i = Array.isArray(i) ? i : [];
                            /=\s*\S+\.eventParams\s*\|\|\s*\S+\[['"]event-params['"]\]/.test(r.toString()) && (i = i.concat([ , , , , , , , , , , s ])), 
                            c.push(r.apply(n, i));
                        } else n.$emit.apply(n, _t(l.$vm, s, t[1], t[2], o, e));
                    }
                });
            }), "input" === r && 1 === c.length && void 0 !== c[0] ? c[0] : void 0;
        }
        var wt = {}, Pt = [];
        var Tt = [ "onShow", "onHide", "onError", "onPageNotFound", "onThemeChange", "onUnhandledRejection" ];
        function kt() {
            c.default.prototype.getOpenerEventChannel = function() {
                return this.$scope.getOpenerEventChannel();
            };
            var n = c.default.prototype.__call_hook;
            c.default.prototype.__call_hook = function(t, e) {
                return "onLoad" === t && e && e.__id__ && (this.__eventChannel__ = function(t) {
                    if (t) {
                        var e = wt[t];
                        return delete wt[t], e;
                    }
                    return Pt.shift();
                }(e.__id__), delete e.__id__), n.call(this, t, e);
            };
        }
        function Ot(e, t) {
            var r = t.mocks, i = t.initRefs;
            kt(), e.$options.store && (c.default.prototype.$store = e.$options.store), c.default.prototype.mpHost = "mp-weixin", 
            c.default.mixin({
                beforeCreate: function() {
                    var e, t, n;
                    this.$options.mpType && (this.mpType = this.$options.mpType, this.$mp = u({
                        data: {}
                    }, this.mpType, this.$options.mpInstance), this.$scope = this.$options.mpInstance, 
                    delete this.$options.mpType, delete this.$options.mpInstance, "page" === this.mpType && (t = getApp()).$vm && t.$vm.$i18n && (this._i18n = t.$vm.$i18n), 
                    "app" !== this.mpType && (i(this), t = r, n = (e = this).$mp[e.mpType], t.forEach(function(t) {
                        y(n, t) && (e[t] = n[t]);
                    })));
                }
            });
            var n = {
                onLaunch: function(t) {
                    this.$vm || (wx.canIUse("nextTick") || console.error("当前微信基础库版本过低，请将 微信开发者工具-详情-项目设置-调试基础库版本 更换为`2.3.0`以上"), 
                    this.$vm = e, this.$vm.$mp = {
                        app: this
                    }, (this.$vm.$scope = this).$vm.globalData = this.globalData, this.$vm._isMounted = !0, 
                    this.$vm.__call_hook("mounted", t), this.$vm.__call_hook("onLaunch", t));
                }
            };
            n.globalData = e.$options.globalData || {};
            var o = e.$options.methods;
            return o && Object.keys(o).forEach(function(t) {
                n[t] = o[t];
            }), dt(n, Tt), n;
        }
        var Dt = [ "__route__", "__wxExparserNodeId__", "__wxWebviewId__" ];
        function Mt(t) {
            return Behavior(t);
        }
        function Ct() {
            return !!this.route;
        }
        function $t(t) {
            this.triggerEvent("__l", t);
        }
        function Ft(t) {
            var e = t.$scope;
            Object.defineProperty(t, "$refs", {
                get: function() {
                    var n = {};
                    return function n(t, r, i) {
                        t.selectAllComponents(r).forEach(function(t) {
                            var e = t.dataset.ref;
                            i[e] = t.$vm || t, "scoped" === t.dataset.vueGeneric && t.selectAllComponents(".scoped-ref").forEach(function(t) {
                                n(t, r, i);
                            });
                        });
                    }(e, ".vue-ref", n), e.selectAllComponents(".vue-ref-in-for").forEach(function(t) {
                        var e = t.dataset.ref;
                        n[e] || (n[e] = []), n[e].push(t.$vm || t);
                    }), n;
                }
            });
        }
        function Lt(t) {
            var e, n = t.detail || t.value, t = n.vuePid, n = n.vueOptions;
            t && (e = function t(e, n) {
                for (var r, i = e.$children, o = i.length - 1; 0 <= o; o--) {
                    var a = i[o];
                    if (a.$scope._$vueId === n) return a;
                }
                for (var s = i.length - 1; 0 <= s; s--) if (r = t(i[s], n)) return r;
            }(this.$vm, t)), e = e || this.$vm, n.parent = e;
        }
        function Rt(t) {
            return Ot(t, {
                mocks: Dt,
                initRefs: Ft
            });
        }
        function jt(t) {
            return App(Rt(t)), t;
        }
        function It(t) {
            return "%" + t.charCodeAt(0).toString(16);
        }
        var Et = /[!'()*]/g, zt = /%2C/g, Wt = function(t) {
            return encodeURIComponent(t).replace(Et, It).replace(zt, ",");
        };
        function Nt(t, e) {
            var e = 1 < arguments.length && void 0 !== e ? e : {}, a = e.isPage, s = e.initRelation, e = o((e = c.default, 
            [ e = p(t = (t = t).default || t) ? t : e.extend(t), t = e.options ]), 2), l = e[0], t = e[1], e = function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? i(Object(n), !0).forEach(function(t) {
                        u(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : i(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }({
                multipleSlots: !0,
                addGlobalClass: !0
            }, t.options || {});
            t["mp-weixin"] && t["mp-weixin"].options && Object.assign(e, t["mp-weixin"].options);
            var n = {
                options: e,
                data: function(t, e) {
                    var n = t.data || {}, r = t.methods || {};
                    if ("function" == typeof n) try {
                        n = n.call(e);
                    } catch (t) {
                        Object({
                            VUE_APP_NAME: "微信智慧外链接致富版",
                            VUE_APP_PLATFORM: "mp-weixin",
                            NODE_ENV: "production",
                            BASE_URL: "/"
                        }).VUE_APP_DEBUG && console.warn("根据 Vue 的 data 函数初始化小程序 data 失败，请尽量确保 data 函数中不访问 vm 对象，否则可能影响首次数据渲染速度。", n);
                    } else try {
                        n = JSON.parse(JSON.stringify(n));
                    } catch (t) {}
                    return g(n) || (n = {}), Object.keys(r).forEach(function(t) {
                        -1 !== e.__lifecycle_hooks__.indexOf(t) || y(n, t) || (n[t] = r[t]);
                    }), n;
                }(t, c.default.prototype),
                behaviors: function(t, e) {
                    var n = t.behaviors, r = t.extends, i = t.mixins, o = t.props;
                    o || (t.props = o = []);
                    var a = [];
                    return Array.isArray(n) && n.forEach(function(t) {
                        a.push(t.replace("uni://", "wx".concat("://"))), "uni://form-field" === t && (Array.isArray(o) ? (o.push("name"), 
                        o.push("value")) : (o.name = {
                            type: String,
                            default: ""
                        }, o.value = {
                            type: [ String, Number, Boolean, Array, Object, Date ],
                            default: ""
                        }));
                    }), g(r) && r.props && a.push(e({
                        properties: xt(r.props, !0)
                    })), Array.isArray(i) && i.forEach(function(t) {
                        g(t) && t.props && a.push(e({
                            properties: xt(t.props, !0)
                        }));
                    }), a;
                }(t, Mt),
                properties: xt(t.props, !1, t.__file),
                lifetimes: {
                    attached: function() {
                        var e, t, n, r, i = this.properties, o = {
                            mpType: a.call(this) ? "page" : "component",
                            mpInstance: this,
                            propsData: i
                        };
                        t = i.vueId, n = this, 1 === (r = (t = (t || "").split(",")).length) ? n._$vueId = t[0] : 2 === r && (n._$vueId = t[0], 
                        n._$vuePid = t[1]), s.call(this, {
                            vuePid: this._$vuePid,
                            vueOptions: o
                        }), this.$vm = new l(o), o = this.$vm, i = i.vueSlots, Array.isArray(i) && i.length && (e = Object.create(null), 
                        i.forEach(function(t) {
                            e[t] = !0;
                        }), o.$scopedSlots = o.$slots = e), this.$vm.$mount();
                    },
                    ready: function() {
                        this.$vm && (this.$vm._isMounted = !0, this.$vm.__call_hook("mounted"), this.$vm.__call_hook("onReady"));
                    },
                    detached: function() {
                        this.$vm && this.$vm.$destroy();
                    }
                },
                pageLifetimes: {
                    show: function(t) {
                        this.$vm && this.$vm.__call_hook("onPageShow", t);
                    },
                    hide: function() {
                        this.$vm && this.$vm.__call_hook("onPageHide");
                    },
                    resize: function(t) {
                        this.$vm && this.$vm.__call_hook("onPageResize", t);
                    }
                },
                methods: {
                    __l: Lt,
                    __e: St
                }
            };
            return t.externalClasses && (n.externalClasses = t.externalClasses), Array.isArray(t.wxsCallMethods) && t.wxsCallMethods.forEach(function(e) {
                n.methods[e] = function(t) {
                    return this.$vm[e](t);
                };
            }), a ? n : [ n, l ];
        }
        function Bt(t) {
            return Nt(t, {
                isPage: Ct,
                initRelation: $t
            });
        }
        var Ut = [ "onShow", "onHide", "onUnload" ];
        function Ht(t, e) {
            e.isPage, e.initRelation;
            e = Bt(t);
            return dt(e.methods, Ut, t), e.methods.onLoad = function(t) {
                this.options = t;
                var e = Object.assign({}, t);
                delete e.__id__, this.$page = {
                    fullPath: "/" + (this.route || this.is) + function(r, t) {
                        var i = 1 < arguments.length && void 0 !== t ? t : Wt;
                        return (t = r ? Object.keys(r).map(function(e) {
                            var t = r[e];
                            if (void 0 === t) return "";
                            if (null === t) return i(e);
                            if (Array.isArray(t)) {
                                var n = [];
                                return t.forEach(function(t) {
                                    void 0 !== t && (null === t ? n.push(i(e)) : n.push(i(e) + "=" + i(t)));
                                }), n.join("&");
                            }
                            return i(e) + "=" + i(t);
                        }).filter(function(t) {
                            return 0 < t.length;
                        }).join("&") : null) ? "?".concat(t) : "";
                    }(e)
                }, this.$vm.$mp.query = t, this.$vm.__call_hook("onLoad", t);
            }, e;
        }
        function Vt(t) {
            return Component(Ht(t, {
                isPage: Ct,
                initRelation: $t
            }));
        }
        function Xt(t) {
            return Component(Bt(t));
        }
        function Gt(t) {
            var e, r = Rt(t), i = getApp({
                allowDefault: !0
            }), n = i.globalData;
            return n && Object.keys(r.globalData).forEach(function(t) {
                y(n, t) || (n[t] = r.globalData[t]);
            }), Object.keys(r).forEach(function(t) {
                y(i, t) || (i[t] = r[t]);
            }), p(r.onShow) && wx.onAppShow && wx.onAppShow(function() {
                for (var t = arguments.length, e = new Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                r.onShow.apply(i, e);
            }), p(r.onHide) && wx.onAppHide && wx.onAppHide(function() {
                for (var t = arguments.length, e = new Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                r.onHide.apply(i, e);
            }), p(r.onLaunch) && (e = wx.getLaunchOptionsSync && wx.getLaunchOptionsSync(), 
            r.onLaunch.call(i, e)), t;
        }
        Ut.push.apply(Ut, [ "onPullDownRefresh", "onReachBottom", "onAddToFavorites", "onShareTimeline", "onShareAppMessage", "onPageScroll", "onResize", "onTabItemTap" ]), 
        [ "vibrate", "preloadPage", "unPreloadPage", "loadSubPackage" ].forEach(function(t) {
            q[t] = !1;
        }), [].forEach(function(t) {
            var e = q[t] && q[t].name ? q[t].name : t;
            wx.canIUse(e) || (q[t] = !1);
        });
        var qt = {};
        "undefined" != typeof Proxy ? qt = new Proxy({}, {
            get: function(t, e) {
                return y(t, e) ? t[e] : V[e] || (st[e] ? N(e, st[e]) : rt[e] ? N(e, rt[e]) : tt[e] ? N(e, tt[e]) : at[e] || (y(wx, e) || y(q, e) ? N(e, Z(e, wx[e])) : void 0));
            },
            set: function(t, e, n) {
                return t[e] = n, !0;
            }
        }) : (Object.keys(V).forEach(function(t) {
            qt[t] = V[t];
        }), Object.keys(tt).forEach(function(t) {
            qt[t] = N(t, tt[t]);
        }), Object.keys(rt).forEach(function(t) {
            qt[t] = N(t, tt[t]);
        }), Object.keys(at).forEach(function(t) {
            qt[t] = at[t];
        }), Object.keys(st).forEach(function(t) {
            qt[t] = N(t, st[t]);
        }), Object.keys(wx).forEach(function(t) {
            (y(wx, t) || y(q, t)) && (qt[t] = N(t, Z(t, wx[t])));
        })), wx.createApp = jt, wx.createPage = Vt, wx.createComponent = Xt, wx.createSubpackageApp = Gt, 
        e.default = qt;
    },
    "66fd": function(t, Fn, e) {
        e.r(Fn), function(t) {
            var g = Object.freeze({});
            function y(t) {
                return null == t;
            }
            function v(t) {
                return null != t;
            }
            function x(t) {
                return !0 === t;
            }
            function l(t) {
                return "string" == typeof t || "number" == typeof t || "symbol" === (void 0 === t ? "undefined" : _typeof(t)) || "boolean" == typeof t;
            }
            function m(t) {
                return null !== t && "object" === (void 0 === t ? "undefined" : _typeof(t));
            }
            var r = Object.prototype.toString;
            function c(t) {
                return "[object Object]" === r.call(t);
            }
            function i(t) {
                var e = parseFloat(String(t));
                return 0 <= e && Math.floor(e) === e && isFinite(t);
            }
            function _(t) {
                return v(t) && "function" == typeof t.then && "function" == typeof t.catch;
            }
            function e(t) {
                return null == t ? "" : Array.isArray(t) || c(t) && t.toString === r ? JSON.stringify(t, null, 2) : String(t);
            }
            function n(t) {
                var e = parseFloat(t);
                return isNaN(e) ? t : e;
            }
            function o(t, e) {
                for (var n = Object.create(null), r = t.split(","), i = 0; i < r.length; i++) n[r[i]] = !0;
                return e ? function(t) {
                    return n[t.toLowerCase()];
                } : function(t) {
                    return n[t];
                };
            }
            o("slot,component", !0);
            var u = o("key,ref,slot,slot-scope,is");
            function b(t, e) {
                if (t.length) {
                    e = t.indexOf(e);
                    if (-1 < e) return t.splice(e, 1);
                }
            }
            var a = Object.prototype.hasOwnProperty;
            function h(t, e) {
                return a.call(t, e);
            }
            function s(e) {
                var n = Object.create(null);
                return function(t) {
                    return n[t] || (n[t] = e(t));
                };
            }
            var f = /-(\w)/g, p = s(function(t) {
                return t.replace(f, function(t, e) {
                    return e ? e.toUpperCase() : "";
                });
            }), d = s(function(t) {
                return t.charAt(0).toUpperCase() + t.slice(1);
            }), A = /\B([A-Z])/g, S = s(function(t) {
                return t.replace(A, "-$1").toLowerCase();
            });
            var w = Function.prototype.bind ? function(t, e) {
                return t.bind(e);
            } : function(n, r) {
                function t(t) {
                    var e = arguments.length;
                    return e ? 1 < e ? n.apply(r, arguments) : n.call(r, t) : n.call(r);
                }
                return t._length = n.length, t;
            };
            function P(t, e) {
                e = e || 0;
                for (var n = t.length - e, r = new Array(n); n--; ) r[n] = t[n + e];
                return r;
            }
            function T(t, e) {
                for (var n in e) t[n] = e[n];
                return t;
            }
            function k(t) {
                for (var e = {}, n = 0; n < t.length; n++) t[n] && T(e, t[n]);
                return e;
            }
            function O(t, e, n) {}
            var D = function(t, e, n) {
                return !1;
            }, M = function(t) {
                return t;
            };
            function C(e, n) {
                if (e === n) return !0;
                var t = m(e), r = m(n);
                if (!t || !r) return !t && !r && String(e) === String(n);
                try {
                    var i = Array.isArray(e), o = Array.isArray(n);
                    if (i && o) return e.length === n.length && e.every(function(t, e) {
                        return C(t, n[e]);
                    });
                    if (e instanceof Date && n instanceof Date) return e.getTime() === n.getTime();
                    if (i || o) return !1;
                    i = Object.keys(e), o = Object.keys(n);
                    return i.length === o.length && i.every(function(t) {
                        return C(e[t], n[t]);
                    });
                } catch (t) {
                    return !1;
                }
            }
            function $(t, e) {
                for (var n = 0; n < t.length; n++) if (C(t[n], e)) return n;
                return -1;
            }
            function F(t) {
                var e = !1;
                return function() {
                    e || (e = !0, t.apply(this, arguments));
                };
            }
            var L = [ "component", "directive", "filter" ], R = [ "beforeCreate", "created", "beforeMount", "mounted", "beforeUpdate", "updated", "beforeDestroy", "destroyed", "activated", "deactivated", "errorCaptured", "serverPrefetch" ], j = {
                optionMergeStrategies: Object.create(null),
                silent: !1,
                productionTip: !1,
                devtools: !1,
                performance: !1,
                errorHandler: null,
                warnHandler: null,
                ignoredElements: [],
                keyCodes: Object.create(null),
                isReservedTag: D,
                isReservedAttr: D,
                isUnknownElement: D,
                getTagNamespace: O,
                parsePlatformTagName: M,
                mustUseProp: D,
                async: !0,
                _lifecycleHooks: R
            };
            function I(t, e, n, r) {
                Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !!r,
                    writable: !0,
                    configurable: !0
                });
            }
            var E = new RegExp("[^" + /a-zA-Z\u00B7\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u037D\u037F-\u1FFF\u200C-\u200D\u203F-\u2040\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD/.source + ".$_\\d]");
            var z, W = "__proto__" in {}, N = "undefined" != typeof window, B = "undefined" != typeof WXEnvironment && !!WXEnvironment.platform, U = B && WXEnvironment.platform.toLowerCase(), H = N && window.navigator.userAgent.toLowerCase(), D = H && /msie|trident/.test(H), V = (H && H.indexOf("msie 9.0"), 
            H && H.indexOf("edge/"), H && H.indexOf("android"), H && /iphone|ipad|ipod|ios/.test(H) || "ios" === U), X = (H && /chrome\/\d+/.test(H), 
            H && /phantomjs/.test(H), H && H.match(/firefox\/(\d+)/), {}.watch);
            if (N) try {
                var G = {};
                Object.defineProperty(G, "passive", {
                    get: function() {}
                }), window.addEventListener("test-passive", null, G);
            } catch (t) {}
            var q = function() {
                return void 0 === z && (z = !N && !B && void 0 !== t && t.process && "server" === t.process.env.VUE_ENV), 
                z;
            }, J = N && window.__VUE_DEVTOOLS_GLOBAL_HOOK__;
            function K(t) {
                return "function" == typeof t && /native code/.test(t.toString());
            }
            var Y, Q = "undefined" != typeof Symbol && K(Symbol) && "undefined" != typeof Reflect && K(Reflect.ownKeys);
            function Z() {
                this.set = Object.create(null);
            }
            Y = "undefined" != typeof Set && K(Set) ? Set : (Z.prototype.has = function(t) {
                return !0 === this.set[t];
            }, Z.prototype.add = function(t) {
                this.set[t] = !0;
            }, Z.prototype.clear = function() {
                this.set = Object.create(null);
            }, Z);
            var tt = O, et = 0, nt = function() {
                this.id = et++, this.subs = [];
            };
            function rt(t) {
                nt.SharedObject.targetStack.push(t), nt.SharedObject.target = t, nt.target = t;
            }
            function it() {
                nt.SharedObject.targetStack.pop(), nt.SharedObject.target = nt.SharedObject.targetStack[nt.SharedObject.targetStack.length - 1], 
                nt.target = nt.SharedObject.target;
            }
            nt.prototype.addSub = function(t) {
                this.subs.push(t);
            }, nt.prototype.removeSub = function(t) {
                b(this.subs, t);
            }, nt.prototype.depend = function() {
                nt.SharedObject.target && nt.SharedObject.target.addDep(this);
            }, nt.prototype.notify = function() {
                for (var t = this.subs.slice(), e = 0, n = t.length; e < n; e++) t[e].update();
            }, nt.SharedObject = {}, nt.SharedObject.target = null, nt.SharedObject.targetStack = [];
            var ot = function(t, e, n, r, i, o, a, s) {
                this.tag = t, this.data = e, this.children = n, this.text = r, this.elm = i, this.ns = void 0, 
                this.context = o, this.fnContext = void 0, this.fnOptions = void 0, this.fnScopeId = void 0, 
                this.key = e && e.key, this.componentOptions = a, this.componentInstance = void 0, 
                this.parent = void 0, this.raw = !1, this.isStatic = !1, this.isRootInsert = !0, 
                this.isComment = !1, this.isCloned = !1, this.isOnce = !1, this.asyncFactory = s, 
                this.asyncMeta = void 0, this.isAsyncPlaceholder = !1;
            }, H = {
                child: {
                    configurable: !0
                }
            };
            H.child.get = function() {
                return this.componentInstance;
            }, Object.defineProperties(ot.prototype, H);
            var at = function(t) {
                void 0 === t && (t = "");
                var e = new ot();
                return e.text = t, e.isComment = !0, e;
            };
            function st(t) {
                return new ot(void 0, void 0, void 0, String(t));
            }
            var lt = Array.prototype, ct = Object.create(lt);
            [ "push", "pop", "shift", "unshift", "splice", "sort", "reverse" ].forEach(function(o) {
                var a = lt[o];
                I(ct, o, function() {
                    for (var t = [], e = arguments.length; e--; ) t[e] = arguments[e];
                    var n, r = a.apply(this, t), i = this.__ob__;
                    switch (o) {
                      case "push":
                      case "unshift":
                        n = t;
                        break;

                      case "splice":
                        n = t.slice(2);
                    }
                    return n && i.observeArray(n), i.dep.notify(), r;
                });
            });
            var ut = Object.getOwnPropertyNames(ct), ht = !0;
            function ft(t) {
                ht = t;
            }
            var pt = function(t) {
                var e;
                this.value = t, this.dep = new nt(), this.vmCount = 0, I(t, "__ob__", this), Array.isArray(t) ? (!W || t.push !== t.__proto__.push ? dt(t, ct, ut) : (e = ct, 
                t.__proto__ = e), this.observeArray(t)) : this.walk(t);
            };
            function dt(t, e, n) {
                for (var r = 0, i = n.length; r < i; r++) {
                    var o = n[r];
                    I(t, o, e[o]);
                }
            }
            function gt(t, e) {
                var n;
                if (m(t) && !(t instanceof ot)) return h(t, "__ob__") && t.__ob__ instanceof pt ? n = t.__ob__ : ht && !q() && (Array.isArray(t) || c(t)) && Object.isExtensible(t) && !t._isVue && (n = new pt(t)), 
                e && n && n.vmCount++, n;
            }
            function yt(n, t, r, e, i) {
                var o, a, s, l = new nt(), c = Object.getOwnPropertyDescriptor(n, t);
                c && !1 === c.configurable || (o = c && c.get, a = c && c.set, o && !a || 2 !== arguments.length || (r = n[t]), 
                s = !i && gt(r), Object.defineProperty(n, t, {
                    enumerable: !0,
                    configurable: !0,
                    get: function() {
                        var t = o ? o.call(n) : r;
                        return nt.SharedObject.target && (l.depend(), s && (s.dep.depend(), Array.isArray(t) && function t(e) {
                            for (var n = void 0, r = 0, i = e.length; r < i; r++) (n = e[r]) && n.__ob__ && n.__ob__.dep.depend(), 
                            Array.isArray(n) && t(n);
                        }(t))), t;
                    },
                    set: function(t) {
                        var e = o ? o.call(n) : r;
                        t === e || t != t && e != e || o && !a || (a ? a.call(n, t) : r = t, s = !i && gt(t), 
                        l.notify());
                    }
                }));
            }
            function vt(t, e, n) {
                if (Array.isArray(t) && i(e)) return t.length = Math.max(t.length, e), t.splice(e, 1, n), 
                n;
                if (e in t && !(e in Object.prototype)) return t[e] = n;
                var r = t.__ob__;
                return t._isVue || r && r.vmCount || (r ? (yt(r.value, e, n), r.dep.notify()) : t[e] = n), 
                n;
            }
            function xt(t, e) {
                var n;
                Array.isArray(t) && i(e) ? t.splice(e, 1) : (n = t.__ob__, t._isVue || n && n.vmCount || h(t, e) && (delete t[e], 
                n && n.dep.notify()));
            }
            pt.prototype.walk = function(t) {
                for (var e = Object.keys(t), n = 0; n < e.length; n++) yt(t, e[n]);
            }, pt.prototype.observeArray = function(t) {
                for (var e = 0, n = t.length; e < n; e++) gt(t[e]);
            };
            var mt = j.optionMergeStrategies;
            function _t(t, e) {
                if (!e) return t;
                for (var n, r, i, o = Q ? Reflect.ownKeys(e) : Object.keys(e), a = 0; a < o.length; a++) "__ob__" !== (n = o[a]) && (r = t[n], 
                i = e[n], h(t, n) ? r !== i && c(r) && c(i) && _t(r, i) : vt(t, n, i));
                return t;
            }
            function bt(n, r, i) {
                return i ? function() {
                    var t = "function" == typeof r ? r.call(i, i) : r, e = "function" == typeof n ? n.call(i, i) : n;
                    return t ? _t(t, e) : e;
                } : r ? n ? function() {
                    return _t("function" == typeof r ? r.call(this, this) : r, "function" == typeof n ? n.call(this, this) : n);
                } : r : n;
            }
            function At(t, e) {
                t = e ? t ? t.concat(e) : Array.isArray(e) ? e : [ e ] : t;
                return t && function(t) {
                    for (var e = [], n = 0; n < t.length; n++) -1 === e.indexOf(t[n]) && e.push(t[n]);
                    return e;
                }(t);
            }
            function St(t, e, n, r) {
                t = Object.create(t || null);
                return e ? T(t, e) : t;
            }
            mt.data = function(t, e, n) {
                return n ? bt(t, e, n) : e && "function" != typeof e ? t : bt(t, e);
            }, R.forEach(function(t) {
                mt[t] = At;
            }), L.forEach(function(t) {
                mt[t + "s"] = St;
            }), mt.watch = function(t, e, n, r) {
                if (t === X && (t = void 0), e === X && (e = void 0), !e) return Object.create(t || null);
                if (!t) return e;
                var i, o = {};
                for (i in T(o, t), e) {
                    var a = o[i], s = e[i];
                    a && !Array.isArray(a) && (a = [ a ]), o[i] = a ? a.concat(s) : Array.isArray(s) ? s : [ s ];
                }
                return o;
            }, mt.props = mt.methods = mt.inject = mt.computed = function(t, e, n, r) {
                if (!t) return e;
                var i = Object.create(null);
                return T(i, t), e && T(i, e), i;
            }, mt.provide = bt;
            var wt = function(t, e) {
                return void 0 === e ? t : e;
            };
            function Pt(n, r, i) {
                if ("function" == typeof r && (r = r.options), function(t) {
                    var e = t.props;
                    if (e) {
                        var n, r, i = {};
                        if (Array.isArray(e)) for (n = e.length; n--; ) "string" == typeof (r = e[n]) && (i[p(r)] = {
                            type: null
                        }); else if (c(e)) for (var o in e) r = e[o], i[p(o)] = c(r) ? r : {
                            type: r
                        };
                        t.props = i;
                    }
                }(r), function(t) {
                    var e = t.inject;
                    if (e) {
                        var n = t.inject = {};
                        if (Array.isArray(e)) for (var r = 0; r < e.length; r++) n[e[r]] = {
                            from: e[r]
                        }; else if (c(e)) for (var i in e) {
                            var o = e[i];
                            n[i] = c(o) ? T({
                                from: i
                            }, o) : {
                                from: o
                            };
                        }
                    }
                }(r), function(t) {
                    var e = t.directives;
                    if (e) for (var n in e) {
                        var r = e[n];
                        "function" == typeof r && (e[n] = {
                            bind: r,
                            update: r
                        });
                    }
                }(r), !r._base && (r.extends && (n = Pt(n, r.extends, i)), r.mixins)) for (var t = 0, e = r.mixins.length; t < e; t++) n = Pt(n, r.mixins[t], i);
                var o, a = {};
                for (o in n) s(o);
                for (o in r) h(n, o) || s(o);
                function s(t) {
                    var e = mt[t] || wt;
                    a[t] = e(n[t], r[t], i, t);
                }
                return a;
            }
            function Tt(t, e, n) {
                if ("string" == typeof n) {
                    var r = t[e];
                    if (h(r, n)) return r[n];
                    t = p(n);
                    if (h(r, t)) return r[t];
                    e = d(t);
                    return h(r, e) ? r[e] : r[n] || r[t] || r[e];
                }
            }
            function kt(t, e, n, r) {
                var i = e[t], o = !h(n, t), e = n[t], n = Mt(Boolean, i.type);
                return -1 < n && (o && !h(i, "default") ? e = !1 : "" !== e && e !== S(t) || ((o = Mt(String, i.type)) < 0 || n < o) && (e = !0)), 
                void 0 === e && (e = function(t, e, n) {
                    if (h(e, "default")) {
                        var r = e.default;
                        return t && t.$options.propsData && void 0 === t.$options.propsData[n] && void 0 !== t._props[n] ? t._props[n] : "function" == typeof r && "Function" !== Ot(e.type) ? r.call(t) : r;
                    }
                }(r, i, t), t = ht, ft(!0), gt(e), ft(t)), e;
            }
            function Ot(t) {
                t = t && t.toString().match(/^\s*function (\w+)/);
                return t ? t[1] : "";
            }
            function Dt(t, e) {
                return Ot(t) === Ot(e);
            }
            function Mt(t, e) {
                if (!Array.isArray(e)) return Dt(e, t) ? 0 : -1;
                for (var n = 0, r = e.length; n < r; n++) if (Dt(e[n], t)) return n;
                return -1;
            }
            function Ct(t, e, n) {
                rt();
                try {
                    if (e) for (var r = e; r = r.$parent; ) {
                        var i = r.$options.errorCaptured;
                        if (i) for (var o = 0; o < i.length; o++) try {
                            if (!1 === i[o].call(r, t, e, n)) return;
                        } catch (t) {
                            Ft(t, r, "errorCaptured hook");
                        }
                    }
                    Ft(t, e, n);
                } finally {
                    it();
                }
            }
            function $t(t, e, n, r, i) {
                var o;
                try {
                    (o = n ? t.apply(e, n) : t.call(e)) && !o._isVue && _(o) && !o._handled && (o.catch(function(t) {
                        return Ct(t, r, i + " (Promise/async)");
                    }), o._handled = !0);
                } catch (t) {
                    Ct(t, r, i);
                }
                return o;
            }
            function Ft(e, t, n) {
                if (j.errorHandler) try {
                    return j.errorHandler.call(null, e, t, n);
                } catch (t) {
                    t !== e && Lt(t);
                }
                Lt(e);
            }
            function Lt(t) {
                if (!N && !B || "undefined" == typeof console) throw t;
                console.error(t);
            }
            var Rt, jt, It, Et, zt = [], Wt = !1;
            function Nt() {
                Wt = !1;
                for (var t = zt.slice(0), e = zt.length = 0; e < t.length; e++) t[e]();
            }
            function Bt(t, e) {
                var n;
                if (zt.push(function() {
                    if (t) try {
                        t.call(e);
                    } catch (t) {
                        Ct(t, e, "nextTick");
                    } else n && n(e);
                }), Wt || (Wt = !0, jt()), !t && "undefined" != typeof Promise) return new Promise(function(t) {
                    n = t;
                });
            }
            jt = "undefined" != typeof Promise && K(Promise) ? (Rt = Promise.resolve(), function() {
                Rt.then(Nt), V && setTimeout(O);
            }) : D || "undefined" == typeof MutationObserver || !K(MutationObserver) && "[object MutationObserverConstructor]" !== MutationObserver.toString() ? "undefined" != typeof setImmediate && K(setImmediate) ? function() {
                setImmediate(Nt);
            } : function() {
                setTimeout(Nt, 0);
            } : (It = 1, R = new MutationObserver(Nt), Et = document.createTextNode(String(It)), 
            R.observe(Et, {
                characterData: !0
            }), function() {
                It = (It + 1) % 2, Et.data = String(It);
            });
            var Ut = new Y();
            function Ht(t) {
                (function t(e, n) {
                    var r, i, o = Array.isArray(e);
                    if (!(!o && !m(e) || Object.isFrozen(e) || e instanceof ot)) {
                        if (e.__ob__) {
                            var a = e.__ob__.dep.id;
                            if (n.has(a)) return;
                            n.add(a);
                        }
                        if (o) for (r = e.length; r--; ) t(e[r], n); else for (i = Object.keys(e), r = i.length; r--; ) t(e[i[r]], n);
                    }
                })(t, Ut), Ut.clear();
            }
            var Vt = s(function(t) {
                var e = "&" === t.charAt(0), n = "~" === (t = e ? t.slice(1) : t).charAt(0), r = "!" === (t = n ? t.slice(1) : t).charAt(0);
                return {
                    name: t = r ? t.slice(1) : t,
                    once: n,
                    capture: r,
                    passive: e
                };
            });
            function Xt(t, e, n, r, i, o) {
                var a, s, l, c;
                for (a in t) s = t[a], l = e[a], c = Vt(a), y(s) || (y(l) ? (y(s.fns) && (s = t[a] = function(t, i) {
                    function o() {
                        var t = arguments, e = o.fns;
                        if (!Array.isArray(e)) return $t(e, null, arguments, i, "v-on handler");
                        for (var n = e.slice(), r = 0; r < n.length; r++) $t(n[r], null, t, i, "v-on handler");
                    }
                    return o.fns = t, o;
                }(s, o)), x(c.once) && (s = t[a] = i(c.name, s, c.capture)), n(c.name, s, c.capture, c.passive, c.params)) : s !== l && (l.fns = s, 
                t[a] = l));
                for (a in e) y(t[a]) && r((c = Vt(a)).name, e[a], c.capture);
            }
            function Gt(t, e, n, r) {
                var i = e.options.mpOptions && e.options.mpOptions.properties;
                if (y(i)) return n;
                var o = e.options.mpOptions.externalClasses || [], a = t.attrs, s = t.props;
                if (v(a) || v(s)) for (var l in i) {
                    var c = S(l);
                    (qt(n, s, l, c, !0) || qt(n, a, l, c, !1)) && n[l] && -1 !== o.indexOf(c) && r[p(n[l])] && (n[l] = r[p(n[l])]);
                }
                return n;
            }
            function qt(t, e, n, r, i) {
                if (v(e)) {
                    if (h(e, n)) return t[n] = e[n], i || delete e[n], !0;
                    if (h(e, r)) return t[n] = e[r], i || delete e[r], !0;
                }
                return !1;
            }
            function Jt(t) {
                return l(t) ? [ st(t) ] : Array.isArray(t) ? function t(e, n) {
                    var r, i, o, a, s = [];
                    for (r = 0; r < e.length; r++) y(i = e[r]) || "boolean" == typeof i || (o = s.length - 1, 
                    a = s[o], Array.isArray(i) ? 0 < i.length && (Kt((i = t(i, (n || "") + "_" + r))[0]) && Kt(a) && (s[o] = st(a.text + i[0].text), 
                    i.shift()), s.push.apply(s, i)) : l(i) ? Kt(a) ? s[o] = st(a.text + i) : "" !== i && s.push(st(i)) : Kt(i) && Kt(a) ? s[o] = st(a.text + i.text) : (x(e._isVList) && v(i.tag) && y(i.key) && v(n) && (i.key = "__vlist" + n + "_" + r + "__"), 
                    s.push(i)));
                    return s;
                }(t) : void 0;
            }
            function Kt(t) {
                return v(t) && v(t.text) && !1 === t.isComment;
            }
            function Yt(t) {
                var e = t.$options.provide;
                e && (t._provided = "function" == typeof e ? e.call(t) : e);
            }
            function Qt(e) {
                var n = Zt(e.$options.inject, e);
                n && (ft(!1), Object.keys(n).forEach(function(t) {
                    yt(e, t, n[t]);
                }), ft(!0));
            }
            function Zt(t, e) {
                if (t) {
                    for (var n = Object.create(null), r = Q ? Reflect.ownKeys(t) : Object.keys(t), i = 0; i < r.length; i++) {
                        var o = r[i];
                        if ("__ob__" !== o) {
                            for (var a, s = t[o].from, l = e; l; ) {
                                if (l._provided && h(l._provided, s)) {
                                    n[o] = l._provided[s];
                                    break;
                                }
                                l = l.$parent;
                            }
                            l || "default" in t[o] && (a = t[o].default, n[o] = "function" == typeof a ? a.call(e) : a);
                        }
                    }
                    return n;
                }
            }
            function te(t, e) {
                if (!t || !t.length) return {};
                for (var n, r = {}, i = 0, o = t.length; i < o; i++) {
                    var a = t[i], s = a.data;
                    s && s.attrs && s.attrs.slot && delete s.attrs.slot, a.context !== e && a.fnContext !== e || !s || null == s.slot ? (a.asyncMeta && a.asyncMeta.data && "page" === a.asyncMeta.data.slot ? r.page || (r.page = []) : r.default || (r.default = [])).push(a) : (s = r[s = s.slot] || (r[s] = []), 
                    "template" === a.tag ? s.push.apply(s, a.children || []) : s.push(a));
                }
                for (n in r) r[n].every(ee) && delete r[n];
                return r;
            }
            function ee(t) {
                return t.isComment && !t.asyncFactory || " " === t.text;
            }
            function ne(t, e, n) {
                var r, i, o = 0 < Object.keys(e).length, a = t ? !!t.$stable : !o, s = t && t.$key;
                if (t) {
                    if (t._normalized) return t._normalized;
                    if (a && n && n !== g && s === n.$key && !o && !n.$hasNormal) return n;
                    for (var l in r = {}, t) t[l] && "$" !== l[0] && (r[l] = function(t, e, n) {
                        function r() {
                            var t = arguments.length ? n.apply(null, arguments) : n({});
                            return (t = t && "object" === (void 0 === t ? "undefined" : _typeof(t)) && !Array.isArray(t) ? [ t ] : Jt(t)) && (0 === t.length || 1 === t.length && t[0].isComment) ? void 0 : t;
                        }
                        return n.proxy && Object.defineProperty(t, e, {
                            get: r,
                            enumerable: !0,
                            configurable: !0
                        }), r;
                    }(e, l, t[l]));
                } else r = {};
                for (i in e) i in r || (r[i] = function(t, e) {
                    return function() {
                        return t[e];
                    };
                }(e, i));
                return t && Object.isExtensible(t) && (t._normalized = r), I(r, "$stable", a), I(r, "$key", s), 
                I(r, "$hasNormal", o), r;
            }
            function re(t, e) {
                var n, r, i, o, a;
                if (Array.isArray(t) || "string" == typeof t) for (n = new Array(t.length), r = 0, 
                i = t.length; r < i; r++) n[r] = e(t[r], r, r, r); else if ("number" == typeof t) for (n = new Array(t), 
                r = 0; r < t; r++) n[r] = e(r + 1, r, r, r); else if (m(t)) if (Q && t[Symbol.iterator]) {
                    n = [];
                    for (var s = t[Symbol.iterator](), l = s.next(); !l.done; ) n.push(e(l.value, n.length, r, r++)), 
                    l = s.next();
                } else for (o = Object.keys(t), n = new Array(o.length), r = 0, i = o.length; r < i; r++) a = o[r], 
                n[r] = e(t[a], a, r, r);
                return v(n) || (n = []), n._isVList = !0, n;
            }
            function ie(t, e, n, r) {
                var i = this.$scopedSlots[t], e = i ? (n = n || {}, r && (n = T(T({}, r), n)), i(n, this, n._i) || e) : this.$slots[t] || e, n = n && n.slot;
                return n ? this.$createElement("template", {
                    slot: n
                }, e) : e;
            }
            function oe(t) {
                return Tt(this.$options, "filters", t) || M;
            }
            function ae(t, e) {
                return Array.isArray(t) ? -1 === t.indexOf(e) : t !== e;
            }
            function se(t, e, n, r, i) {
                n = j.keyCodes[e] || n;
                return i && r && !j.keyCodes[e] ? ae(i, r) : n ? ae(n, t) : r ? S(r) !== e : void 0;
            }
            function le(r, i, o, a, s) {
                if (o && m(o)) {
                    var l;
                    Array.isArray(o) && (o = k(o));
                    for (var t in o) !function(e) {
                        l = "class" === e || "style" === e || u(e) ? r : (n = r.attrs && r.attrs.type, a || j.mustUseProp(i, n, e) ? r.domProps || (r.domProps = {}) : r.attrs || (r.attrs = {}));
                        var t = p(e), n = S(e);
                        t in l || n in l || (l[e] = o[e], !s) || ((r.on || (r.on = {}))["update:" + e] = function(t) {
                            o[e] = t;
                        });
                    }(t);
                }
                return r;
            }
            function ce(t, e) {
                var n = this._staticTrees || (this._staticTrees = []), r = n[t];
                return r && !e || he(r = n[t] = this.$options.staticRenderFns[t].call(this._renderProxy, null, this), "__static__" + t, !1), 
                r;
            }
            function ue(t, e, n) {
                return he(t, "__once__" + e + (n ? "_" + n : ""), !0), t;
            }
            function he(t, e, n) {
                if (Array.isArray(t)) for (var r = 0; r < t.length; r++) t[r] && "string" != typeof t[r] && fe(t[r], e + "_" + r, n); else fe(t, e, n);
            }
            function fe(t, e, n) {
                t.isStatic = !0, t.key = e, t.isOnce = n;
            }
            function pe(t, e) {
                if (e && c(e)) {
                    var n, r = t.on = t.on ? T({}, t.on) : {};
                    for (n in e) {
                        var i = r[n], o = e[n];
                        r[n] = i ? [].concat(i, o) : o;
                    }
                }
                return t;
            }
            function de(t, e, n, r) {
                e = e || {
                    $stable: !n
                };
                for (var i = 0; i < t.length; i++) {
                    var o = t[i];
                    Array.isArray(o) ? de(o, e, n) : o && (o.proxy && (o.fn.proxy = !0), e[o.key] = o.fn);
                }
                return r && (e.$key = r), e;
            }
            function ge(t, e) {
                for (var n = 0; n < e.length; n += 2) {
                    var r = e[n];
                    "string" == typeof r && r && (t[e[n]] = e[n + 1]);
                }
                return t;
            }
            function ye(t, e) {
                return "string" == typeof t ? e + t : t;
            }
            function ve(t) {
                t._o = ue, t._n = n, t._s = e, t._l = re, t._t = ie, t._q = C, t._i = $, t._m = ce, 
                t._f = oe, t._k = se, t._b = le, t._v = st, t._e = at, t._u = de, t._g = pe, t._d = ge, 
                t._p = ye;
            }
            function xe(t, e, n, i, r) {
                var o, a = this, s = r.options;
                h(i, "_uid") ? (o = Object.create(i))._original = i : i = (o = i)._original;
                var r = x(s._compiled), l = !r;
                this.data = t, this.props = e, this.children = n, this.parent = i, this.listeners = t.on || g, 
                this.injections = Zt(s.inject, i), this.slots = function() {
                    return a.$slots || ne(t.scopedSlots, a.$slots = te(n, i)), a.$slots;
                }, Object.defineProperty(this, "scopedSlots", {
                    enumerable: !0,
                    get: function() {
                        return ne(t.scopedSlots, this.slots());
                    }
                }), r && (this.$options = s, this.$slots = this.slots(), this.$scopedSlots = ne(t.scopedSlots, this.$slots)), 
                s._scopeId ? this._c = function(t, e, n, r) {
                    r = Te(o, t, e, n, r, l);
                    return r && !Array.isArray(r) && (r.fnScopeId = s._scopeId, r.fnContext = i), r;
                } : this._c = function(t, e, n, r) {
                    return Te(o, t, e, n, r, l);
                };
            }
            function me(t, e, n, r) {
                var i, t = ((t = new ot((i = t).tag, i.data, i.children && i.children.slice(), i.text, i.elm, i.context, i.componentOptions, i.asyncFactory)).ns = i.ns, 
                t.isStatic = i.isStatic, t.key = i.key, t.isComment = i.isComment, t.fnContext = i.fnContext, 
                t.fnOptions = i.fnOptions, t.fnScopeId = i.fnScopeId, t.asyncMeta = i.asyncMeta, 
                t.isCloned = !0, t);
                return t.fnContext = n, t.fnOptions = r, e.slot && ((t.data || (t.data = {})).slot = e.slot), 
                t;
            }
            function _e(t, e) {
                for (var n in e) t[p(n)] = e[n];
            }
            ve(xe.prototype);
            var be = {
                init: function(t, e) {
                    var n, r, i;
                    t.componentInstance && !t.componentInstance._isDestroyed && t.data.keepAlive ? be.prepatch(t, t) : (t.componentInstance = (i = {
                        _isComponent: !0,
                        _parentVnode: n = t,
                        parent: r = Le
                    }, v(r = n.data.inlineTemplate) && (i.render = r.render, i.staticRenderFns = r.staticRenderFns), 
                    new n.componentOptions.Ctor(i))).$mount(e ? t.elm : void 0, e);
                },
                prepatch: function(t, e) {
                    var n = e.componentOptions;
                    !function(t, e, n, r, i) {
                        var o = r.data.scopedSlots, a = t.$scopedSlots, a = !!(o && !o.$stable || a !== g && !a.$stable || o && t.$scopedSlots.$key !== o.$key), o = !!(i || t.$options._renderChildren || a);
                        if (t.$options._parentVnode = r, t.$vnode = r, t._vnode && (t._vnode.parent = r), 
                        t.$options._renderChildren = i, t.$attrs = r.data.attrs || g, t.$listeners = n || g, 
                        e && t.$options.props) {
                            ft(!1);
                            for (var s = t._props, l = t.$options._propKeys || [], c = 0; c < l.length; c++) {
                                var u = l[c], h = t.$options.props;
                                s[u] = kt(u, h, e, t);
                            }
                            ft(!0), t.$options.propsData = e;
                        }
                        t._$updateProperties && t._$updateProperties(t), n = n || g, a = t.$options._parentListeners, 
                        t.$options._parentListeners = n, Fe(t, n, a), o && (t.$slots = te(i, r.context), 
                        t.$forceUpdate());
                    }(e.componentInstance = t.componentInstance, n.propsData, n.listeners, e, n.children);
                },
                insert: function(t) {
                    var e = t.context, n = t.componentInstance;
                    n._isMounted || (Ie(n, "onServiceCreated"), Ie(n, "onServiceAttached"), n._isMounted = !0, 
                    Ie(n, "mounted")), t.data.keepAlive && (e._isMounted ? ((e = n)._inactive = !1, 
                    ze.push(e)) : je(n, !0));
                },
                destroy: function(t) {
                    var e = t.componentInstance;
                    e._isDestroyed || (t.data.keepAlive ? function t(e, n) {
                        if (!(n && (e._directInactive = !0, Re(e)) || e._inactive)) {
                            e._inactive = !0;
                            for (var r = 0; r < e.$children.length; r++) t(e.$children[r]);
                            Ie(e, "deactivated");
                        }
                    }(e, !0) : e.$destroy());
                }
            }, Ae = Object.keys(be);
            function Se(t, e, n, r, i) {
                if (!y(t)) {
                    var o, a = n.$options._base;
                    if (m(t) && (t = a.extend(t)), "function" == typeof t) {
                        if (y(t.cid) && void 0 === (t = function(e, n) {
                            if (x(e.error) && v(e.errorComp)) return e.errorComp;
                            if (v(e.resolved)) return e.resolved;
                            var t = Oe;
                            if (t && v(e.owners) && -1 === e.owners.indexOf(t) && e.owners.push(t), x(e.loading) && v(e.loadingComp)) return e.loadingComp;
                            if (t && !v(e.owners)) {
                                var r = e.owners = [ t ], i = !0, o = null, a = null;
                                t.$on("hook:destroyed", function() {
                                    return b(r, t);
                                });
                                var s = function(t) {
                                    for (var e = 0, n = r.length; e < n; e++) r[e].$forceUpdate();
                                    t && (r.length = 0, null !== o && (clearTimeout(o), o = null), null !== a && (clearTimeout(a), 
                                    a = null));
                                }, l = F(function(t) {
                                    e.resolved = De(t, n), i ? r.length = 0 : s(!0);
                                }), c = F(function(t) {
                                    v(e.errorComp) && (e.error = !0, s(!0));
                                }), u = e(l, c);
                                return m(u) && (_(u) ? y(e.resolved) && u.then(l, c) : _(u.component) && (u.component.then(l, c), 
                                v(u.error) && (e.errorComp = De(u.error, n)), v(u.loading) && (e.loadingComp = De(u.loading, n), 
                                0 === u.delay ? e.loading = !0 : o = setTimeout(function() {
                                    o = null, y(e.resolved) && y(e.error) && (e.loading = !0, s(!1));
                                }, u.delay || 200)), v(u.timeout) && (a = setTimeout(function() {
                                    a = null, y(e.resolved) && c(null);
                                }, u.timeout)))), i = !1, e.loading ? e.loadingComp : e.resolved;
                            }
                        }(o = t, a))) return u = o, h = e, f = n, a = r, p = i, (d = at()).asyncFactory = u, 
                        d.asyncMeta = {
                            data: h,
                            context: f,
                            children: a,
                            tag: p
                        }, d;
                        e = e || {}, un(t), v(e.model) && (p = t.options, l = e, d = p.model && p.model.prop || "value", 
                        c = p.model && p.model.event || "input", (l.attrs || (l.attrs = {}))[d] = l.model.value, 
                        p = l.on || (l.on = {}), d = p[c], l = l.model.callback, void (v(d) ? (Array.isArray(d) ? -1 === d.indexOf(l) : d !== l) && (p[c] = [ l ].concat(d)) : p[c] = l));
                        c = function(t, e, n) {
                            var r = e.options.props;
                            if (y(r)) return Gt(t, e, {}, n);
                            var i = {}, o = t.attrs, a = t.props;
                            if (v(o) || v(a)) for (var s in r) {
                                var l = S(s);
                                qt(i, a, s, l, !0) || qt(i, o, s, l, !1);
                            }
                            return Gt(t, e, i, n);
                        }(e, t, n);
                        if (x(t.options.functional)) return function(t, e, n, r, i) {
                            var o = t.options, a = {}, s = o.props;
                            if (v(s)) for (var l in s) a[l] = kt(l, s, e || g); else v(n.attrs) && _e(a, n.attrs), 
                            v(n.props) && _e(a, n.props);
                            var c = new xe(n, a, i, r, t);
                            if ((t = o.render.call(null, c._c, c)) instanceof ot) return me(t, n, c.parent, o);
                            if (Array.isArray(t)) {
                                for (var u = Jt(t) || [], h = new Array(u.length), f = 0; f < u.length; f++) h[f] = me(u[f], n, c.parent, o);
                                return h;
                            }
                        }(t, c, e, n, r);
                        l = e.on;
                        e.on = e.nativeOn, x(t.options.abstract) && (s = e.slot, e = {}, s && (e.slot = s)), 
                        function(t) {
                            for (var e = t.hook || (t.hook = {}), n = 0; n < Ae.length; n++) {
                                var r = Ae[n], i = e[r], o = be[r];
                                i === o || i && i._merged || (e[r] = i ? function(n, r) {
                                    function t(t, e) {
                                        n(t, e), r(t, e);
                                    }
                                    return t._merged = !0, t;
                                }(o, i) : o);
                            }
                        }(e);
                        var s = t.options.name || i;
                        return new ot("vue-component-" + t.cid + (s ? "-" + s : ""), e, void 0, void 0, void 0, n, {
                            Ctor: t,
                            propsData: c,
                            listeners: l,
                            tag: i,
                            children: r
                        }, o);
                    }
                }
                var l, c, u, h, f, p, d;
            }
            var we = 1, Pe = 2;
            function Te(t, e, n, r, i, o) {
                return (Array.isArray(n) || l(n)) && (i = r, r = n, n = void 0), x(o) && (i = Pe), 
                t = t, e = e, r = r, i = i, v(n = n) && v(n.__ob__) ? at() : (v(n) && v(n.is) && (e = n.is), 
                e ? (Array.isArray(r) && "function" == typeof r[0] && ((n = n || {}).scopedSlots = {
                    default: r[0]
                }, r.length = 0), i === Pe ? r = Jt(r) : i === we && (r = function(t) {
                    for (var e = 0; e < t.length; e++) if (Array.isArray(t[e])) return Array.prototype.concat.apply([], t);
                    return t;
                }(r)), r = "string" == typeof e ? (a = t.$vnode && t.$vnode.ns || j.getTagNamespace(e), 
                j.isReservedTag(e) ? new ot(j.parsePlatformTagName(e), n, r, void 0, void 0, t) : n && n.pre || !v(s = Tt(t.$options, "components", e)) ? new ot(e, n, r, void 0, void 0, t) : Se(s, n, t, r, e)) : Se(e, n, t, r), 
                Array.isArray(r) ? r : v(r) ? (v(a) && function t(e, n, r) {
                    if (e.ns = n, "foreignObject" === e.tag && (n = void 0, r = !0), v(e.children)) for (var i = 0, o = e.children.length; i < o; i++) {
                        var a = e.children[i];
                        v(a.tag) && (y(a.ns) || x(r) && "svg" !== a.tag) && t(a, n, r);
                    }
                }(r, a), v(n) && function(t) {
                    m(t.style) && Ht(t.style), m(t.class) && Ht(t.class);
                }(n), r) : at()) : at());
                var a, s;
            }
            var ke, Oe = null;
            function De(t, e) {
                return (t.__esModule || Q && "Module" === t[Symbol.toStringTag]) && (t = t.default), 
                m(t) ? e.extend(t) : t;
            }
            function Me(t, e) {
                ke.$on(t, e);
            }
            function Ce(t, e) {
                ke.$off(t, e);
            }
            function $e(e, n) {
                var r = ke;
                return function t() {
                    null !== n.apply(null, arguments) && r.$off(e, t);
                };
            }
            function Fe(t, e, n) {
                Xt(e, n || {}, Me, Ce, $e, ke = t), ke = void 0;
            }
            var Le = null;
            function Re(t) {
                for (;t = t && t.$parent; ) if (t._inactive) return 1;
            }
            function je(t, e) {
                if (e) {
                    if (t._directInactive = !1, Re(t)) return;
                } else if (t._directInactive) return;
                if (t._inactive || null === t._inactive) {
                    t._inactive = !1;
                    for (var n = 0; n < t.$children.length; n++) je(t.$children[n]);
                    Ie(t, "activated");
                }
            }
            function Ie(t, e) {
                rt();
                var n = t.$options[e], r = e + " hook";
                if (n) for (var i = 0, o = n.length; i < o; i++) $t(n[i], t, null, t, r);
                t._hasHookEvent && t.$emit("hook:" + e), it();
            }
            var Ee = [], ze = [], We = {}, Ne = !1, Be = !1, Ue = 0;
            var He, Ve = Date.now;
            function Xe() {
                var t, e;
                for (Ve(), Be = !0, Ee.sort(function(t, e) {
                    return t.id - e.id;
                }), Ue = 0; Ue < Ee.length; Ue++) (t = Ee[Ue]).before && t.before(), e = t.id, We[e] = null, 
                t.run();
                var n = ze.slice(), r = Ee.slice();
                Ue = Ee.length = ze.length = 0, Ne = Be = !(We = {}), function(t) {
                    for (var e = 0; e < t.length; e++) t[e]._inactive = !0, je(t[e], !0);
                }(n), function(t) {
                    for (var e = t.length; e--; ) {
                        var n = t[e], r = n.vm;
                        r._watcher === n && r._isMounted && !r._isDestroyed && Ie(r, "updated");
                    }
                }(r), J && j.devtools && J.emit("flush");
            }
            !N || D || (He = window.performance) && "function" == typeof He.now && Ve() > document.createEvent("Event").timeStamp && (Ve = function() {
                return He.now();
            });
            var Ge = 0, qe = function(t, e, n, r, i) {
                this.vm = t, i && (t._watcher = this), t._watchers.push(this), r ? (this.deep = !!r.deep, 
                this.user = !!r.user, this.lazy = !!r.lazy, this.sync = !!r.sync, this.before = r.before) : this.deep = this.user = this.lazy = this.sync = !1, 
                this.cb = n, this.id = ++Ge, this.active = !0, this.dirty = this.lazy, this.deps = [], 
                this.newDeps = [], this.depIds = new Y(), this.newDepIds = new Y(), this.expression = "", 
                "function" == typeof e ? this.getter = e : (this.getter = function(t) {
                    if (!E.test(t)) {
                        var n = t.split(".");
                        return function(t) {
                            for (var e = 0; e < n.length; e++) {
                                if (!t) return;
                                t = t[n[e]];
                            }
                            return t;
                        };
                    }
                }(e), this.getter || (this.getter = O)), this.value = this.lazy ? void 0 : this.get();
            };
            qe.prototype.get = function() {
                var t;
                rt(this);
                var e = this.vm;
                try {
                    t = this.getter.call(e, e);
                } catch (t) {
                    if (!this.user) throw t;
                    Ct(t, e, 'getter for watcher "' + this.expression + '"');
                } finally {
                    this.deep && Ht(t), it(), this.cleanupDeps();
                }
                return t;
            }, qe.prototype.addDep = function(t) {
                var e = t.id;
                this.newDepIds.has(e) || (this.newDepIds.add(e), this.newDeps.push(t), this.depIds.has(e) || t.addSub(this));
            }, qe.prototype.cleanupDeps = function() {
                for (var t = this.deps.length; t--; ) {
                    var e = this.deps[t];
                    this.newDepIds.has(e.id) || e.removeSub(this);
                }
                var n = this.depIds;
                this.depIds = this.newDepIds, this.newDepIds = n, this.newDepIds.clear(), n = this.deps, 
                this.deps = this.newDeps, this.newDeps = n, this.newDeps.length = 0;
            }, qe.prototype.update = function() {
                this.lazy ? this.dirty = !0 : this.sync ? this.run() : function(t) {
                    var e = t.id;
                    if (null == We[e]) {
                        if (We[e] = !0, Be) {
                            for (var n = Ee.length - 1; Ue < n && Ee[n].id > t.id; ) n--;
                            Ee.splice(n + 1, 0, t);
                        } else Ee.push(t);
                        Ne || (Ne = !0, Bt(Xe));
                    }
                }(this);
            }, qe.prototype.run = function() {
                if (this.active) {
                    var t = this.get();
                    if (t !== this.value || m(t) || this.deep) {
                        var e = this.value;
                        if (this.value = t, this.user) try {
                            this.cb.call(this.vm, t, e);
                        } catch (t) {
                            Ct(t, this.vm, 'callback for watcher "' + this.expression + '"');
                        } else this.cb.call(this.vm, t, e);
                    }
                }
            }, qe.prototype.evaluate = function() {
                this.value = this.get(), this.dirty = !1;
            }, qe.prototype.depend = function() {
                for (var t = this.deps.length; t--; ) this.deps[t].depend();
            }, qe.prototype.teardown = function() {
                if (this.active) {
                    this.vm._isBeingDestroyed || b(this.vm._watchers, this);
                    for (var t = this.deps.length; t--; ) this.deps[t].removeSub(this);
                    this.active = !1;
                }
            };
            var Je = {
                enumerable: !0,
                configurable: !0,
                get: O,
                set: O
            };
            function Ke(t, e, n) {
                Je.get = function() {
                    return this[e][n];
                }, Je.set = function(t) {
                    this[e][n] = t;
                }, Object.defineProperty(t, n, Je);
            }
            function Ye(t) {
                t._watchers = [];
                var e = t.$options;
                e.props && function(n, r) {
                    var t, i = n.$options.propsData || {}, o = n._props = {}, a = n.$options._propKeys = [];
                    for (t in n.$parent && ft(!1), r) !function(t) {
                        a.push(t);
                        var e = kt(t, r, i, n);
                        yt(o, t, e), t in n || Ke(n, "_props", t);
                    }(t);
                    ft(!0);
                }(t, e.props), e.methods && function(t, e) {
                    for (var n in t.$options.props, e) t[n] = "function" != typeof e[n] ? O : w(e[n], t);
                }(t, e.methods), e.data ? function(t) {
                    var e = t.$options.data;
                    c(e = t._data = "function" == typeof e ? function(t, e) {
                        rt();
                        try {
                            return t.call(e, e);
                        } catch (t) {
                            return Ct(t, e, "data()"), {};
                        } finally {
                            it();
                        }
                    }(e, t) : e || {}) || (e = {});
                    for (var n = Object.keys(e), r = t.$options.props, i = (t.$options.methods, n.length); i--; ) {
                        var o = n[i];
                        r && h(r, o) || function(t) {
                            return 36 === (t = (t + "").charCodeAt(0)) || 95 === t;
                        }(o) || Ke(t, "_data", o);
                    }
                    gt(e, !0);
                }(t) : gt(t._data = {}, !0), e.computed && function(t, e) {
                    var n, r = t._computedWatchers = Object.create(null), i = q();
                    for (n in e) {
                        var o = e[n], a = "function" == typeof o ? o : o.get;
                        i || (r[n] = new qe(t, a || O, O, Qe)), n in t || Ze(t, n, o);
                    }
                }(t, e.computed), e.watch && e.watch !== X && function(t, e) {
                    for (var n in e) {
                        var r = e[n];
                        if (Array.isArray(r)) for (var i = 0; i < r.length; i++) nn(t, n, r[i]); else nn(t, n, r);
                    }
                }(t, e.watch);
            }
            var Qe = {
                lazy: !0
            };
            function Ze(t, e, n) {
                var r = !q();
                "function" == typeof n ? (Je.get = r ? tn(e) : en(n), Je.set = O) : (Je.get = n.get ? r && !1 !== n.cache ? tn(e) : en(n.get) : O, 
                Je.set = n.set || O), Object.defineProperty(t, e, Je);
            }
            function tn(e) {
                return function() {
                    var t = this._computedWatchers && this._computedWatchers[e];
                    if (t) return t.dirty && t.evaluate(), nt.SharedObject.target && t.depend(), t.value;
                };
            }
            function en(t) {
                return function() {
                    return t.call(this, this);
                };
            }
            function nn(t, e, n, r) {
                return c(n) && (n = (r = n).handler), "string" == typeof n && (n = t[n]), t.$watch(e, n, r);
            }
            var rn, on, an, sn, ln, cn = 0;
            function un(t) {
                var e, n, r = t.options;
                return !t.super || (e = un(t.super)) !== t.superOptions && (t.superOptions = e, 
                (n = function(t) {
                    var e, n, r = t.options, i = t.sealedOptions;
                    for (n in r) r[n] !== i[n] && ((e = e || {})[n] = r[n]);
                    return e;
                }(t)) && T(t.extendOptions, n), (r = t.options = Pt(e, t.extendOptions)).name && (r.components[r.name] = t)), 
                r;
            }
            function hn(t) {
                this._init(t);
            }
            function fn(t) {
                t.cid = 0;
                var a = 1;
                t.extend = function(t) {
                    t = t || {};
                    var e = this, n = e.cid, r = t._Ctor || (t._Ctor = {});
                    if (r[n]) return r[n];
                    function i(t) {
                        this._init(t);
                    }
                    var o = t.name || e.options.name;
                    return ((i.prototype = Object.create(e.prototype)).constructor = i).cid = a++, i.options = Pt(e.options, t), 
                    i.super = e, i.options.props && function(t) {
                        for (var e in t.options.props) Ke(t.prototype, "_props", e);
                    }(i), i.options.computed && function(t) {
                        var e, n = t.options.computed;
                        for (e in n) Ze(t.prototype, e, n[e]);
                    }(i), i.extend = e.extend, i.mixin = e.mixin, i.use = e.use, L.forEach(function(t) {
                        i[t] = e[t];
                    }), o && (i.options.components[o] = i), i.superOptions = e.options, i.extendOptions = t, 
                    i.sealedOptions = T({}, i.options), r[n] = i;
                };
            }
            function pn(t) {
                return t && (t.Ctor.options.name || t.tag);
            }
            function dn(t, e) {
                return Array.isArray(t) ? -1 < t.indexOf(e) : "string" == typeof t ? -1 < t.split(",").indexOf(e) : (n = t, 
                !("[object RegExp]" !== r.call(n)) && t.test(e));
                var n;
            }
            function gn(t, e) {
                var n, r = t.cache, i = t.keys, o = t._vnode;
                for (n in r) {
                    var a = r[n];
                    !a || (a = pn(a.componentOptions)) && !e(a) && yn(r, n, i, o);
                }
            }
            function yn(t, e, n, r) {
                var i = t[e];
                !i || r && i.tag === r.tag || i.componentInstance.$destroy(), t[e] = null, b(n, e);
            }
            hn.prototype._init = function(t) {
                var e, n, r, i = this;
                i._uid = cn++, i._isVue = !0, t && t._isComponent ? (n = t, r = (e = i).$options = Object.create(e.constructor.options), 
                e = n._parentVnode, r.parent = n.parent, e = (r._parentVnode = e).componentOptions, 
                r.propsData = e.propsData, r._parentListeners = e.listeners, r._renderChildren = e.children, 
                r._componentTag = e.tag, n.render && (r.render = n.render, r.staticRenderFns = n.staticRenderFns)) : i.$options = Pt(un(i.constructor), t || {}, i), 
                function(t) {
                    var e = t.$options, n = e.parent;
                    if (n && !e.abstract) {
                        for (;n.$options.abstract && n.$parent; ) n = n.$parent;
                        n.$children.push(t);
                    }
                    t.$parent = n, t.$root = n ? n.$root : t, t.$children = [], t.$refs = {}, t._watcher = null, 
                    t._inactive = null, t._directInactive = !1, t._isMounted = !1, t._isDestroyed = !1, 
                    t._isBeingDestroyed = !1;
                }((i._renderProxy = i)._self = i), function(t) {
                    t._events = Object.create(null), t._hasHookEvent = !1;
                    var e = t.$options._parentListeners;
                    e && Fe(t, e);
                }(i), function(i) {
                    i._vnode = null, i._staticTrees = null;
                    var t = i.$options, e = i.$vnode = t._parentVnode, n = e && e.context;
                    i.$slots = te(t._renderChildren, n), i.$scopedSlots = g, i._c = function(t, e, n, r) {
                        return Te(i, t, e, n, r, !1);
                    }, i.$createElement = function(t, e, n, r) {
                        return Te(i, t, e, n, r, !0);
                    }, e = e && e.data, yt(i, "$attrs", e && e.attrs || g, null, !0), yt(i, "$listeners", t._parentListeners || g, null, !0);
                }(i), Ie(i, "beforeCreate"), i._$fallback || Qt(i), Ye(i), i._$fallback || Yt(i), 
                i._$fallback || Ie(i, "created"), i.$options.el && i.$mount(i.$options.el);
            }, ln = hn, Object.defineProperty(ln.prototype, "$data", {
                get: function() {
                    return this._data;
                }
            }), Object.defineProperty(ln.prototype, "$props", {
                get: function() {
                    return this._props;
                }
            }), ln.prototype.$set = vt, ln.prototype.$delete = xt, ln.prototype.$watch = function(t, e, n) {
                if (c(e)) return nn(this, t, e, n);
                (n = n || {}).user = !0;
                var r = new qe(this, t, e, n);
                if (n.immediate) try {
                    e.call(this, r.value);
                } catch (t) {
                    Ct(t, this, 'callback for immediate watcher "' + r.expression + '"');
                }
                return function() {
                    r.teardown();
                };
            }, sn = /^hook:/, (an = hn).prototype.$on = function(t, e) {
                var n = this;
                if (Array.isArray(t)) for (var r = 0, i = t.length; r < i; r++) n.$on(t[r], e); else (n._events[t] || (n._events[t] = [])).push(e), 
                sn.test(t) && (n._hasHookEvent = !0);
                return n;
            }, an.prototype.$once = function(t, e) {
                var n = this;
                function r() {
                    n.$off(t, r), e.apply(n, arguments);
                }
                return r.fn = e, n.$on(t, r), n;
            }, an.prototype.$off = function(t, e) {
                var n = this;
                if (!arguments.length) return n._events = Object.create(null), n;
                if (Array.isArray(t)) {
                    for (var r = 0, i = t.length; r < i; r++) n.$off(t[r], e);
                    return n;
                }
                var o, a = n._events[t];
                if (!a) return n;
                if (!e) return n._events[t] = null, n;
                for (var s = a.length; s--; ) if ((o = a[s]) === e || o.fn === e) {
                    a.splice(s, 1);
                    break;
                }
                return n;
            }, an.prototype.$emit = function(t) {
                var e = this._events[t];
                if (e) {
                    e = 1 < e.length ? P(e) : e;
                    for (var n = P(arguments, 1), r = 'event handler for "' + t + '"', i = 0, o = e.length; i < o; i++) $t(e[i], this, n, this, r);
                }
                return this;
            }, (on = hn).prototype._update = function(t, e) {
                var n, r = this, i = r.$el, o = r._vnode, a = (n = Le, function() {
                    Le = n;
                });
                (Le = r)._vnode = t, r.$el = o ? r.__patch__(o, t) : r.__patch__(r.$el, t, e, !1), 
                a(), i && (i.__vue__ = null), r.$el && (r.$el.__vue__ = r), r.$vnode && r.$parent && r.$vnode === r.$parent._vnode && (r.$parent.$el = r.$el);
            }, on.prototype.$forceUpdate = function() {
                this._watcher && this._watcher.update();
            }, on.prototype.$destroy = function() {
                var t = this;
                if (!t._isBeingDestroyed) {
                    Ie(t, "beforeDestroy"), t._isBeingDestroyed = !0;
                    var e = t.$parent;
                    !e || e._isBeingDestroyed || t.$options.abstract || b(e.$children, t), t._watcher && t._watcher.teardown();
                    for (var n = t._watchers.length; n--; ) t._watchers[n].teardown();
                    t._data.__ob__ && t._data.__ob__.vmCount--, t._isDestroyed = !0, t.__patch__(t._vnode, null), 
                    Ie(t, "destroyed"), t.$off(), t.$el && (t.$el.__vue__ = null), t.$vnode && (t.$vnode.parent = null);
                }
            }, ve((rn = hn).prototype), rn.prototype.$nextTick = function(t) {
                return Bt(t, this);
            }, rn.prototype._render = function() {
                var e, n = this, t = n.$options, r = t.render, t = t._parentVnode;
                t && (n.$scopedSlots = ne(t.data.scopedSlots, n.$slots, n.$scopedSlots)), n.$vnode = t;
                try {
                    Oe = n, e = r.call(n._renderProxy, n.$createElement);
                } catch (t) {
                    Ct(t, n, "render"), e = n._vnode;
                } finally {
                    Oe = null;
                }
                return Array.isArray(e) && 1 === e.length && (e = e[0]), e instanceof ot || (e = at()), 
                e.parent = t, e;
            };
            var vn, xn, mn, D = [ String, RegExp, Array ], _n = {
                KeepAlive: {
                    name: "keep-alive",
                    abstract: !0,
                    props: {
                        include: D,
                        exclude: D,
                        max: [ String, Number ]
                    },
                    created: function() {
                        this.cache = Object.create(null), this.keys = [];
                    },
                    destroyed: function() {
                        for (var t in this.cache) yn(this.cache, t, this.keys);
                    },
                    mounted: function() {
                        var t = this;
                        this.$watch("include", function(e) {
                            gn(t, function(t) {
                                return dn(e, t);
                            });
                        }), this.$watch("exclude", function(e) {
                            gn(t, function(t) {
                                return !dn(e, t);
                            });
                        });
                    },
                    render: function() {
                        var t = this.$slots.default, e = function(t) {
                            if (Array.isArray(t)) for (var e = 0; e < t.length; e++) {
                                var n = t[e];
                                if (v(n) && (v(n.componentOptions) || (r = n).isComment && r.asyncFactory)) return n;
                            }
                            var r;
                        }(t), n = e && e.componentOptions;
                        if (n) {
                            var r = pn(n), i = this.include, o = this.exclude;
                            if (i && (!r || !dn(i, r)) || o && r && dn(o, r)) return e;
                            o = this.cache, r = this.keys, n = null == e.key ? n.Ctor.cid + (n.tag ? "::" + n.tag : "") : e.key;
                            o[n] ? (e.componentInstance = o[n].componentInstance, b(r, n), r.push(n)) : (o[n] = e, 
                            r.push(n), this.max && r.length > parseInt(this.max) && yn(o, r[0], r, this._vnode)), 
                            e.data.keepAlive = !0;
                        }
                        return e || t && t[0];
                    }
                }
            };
            vn = hn, mn = {
                get: function() {
                    return j;
                }
            }, Object.defineProperty(vn, "config", mn), vn.util = {
                warn: tt,
                extend: T,
                mergeOptions: Pt,
                defineReactive: yt
            }, vn.set = vt, vn.delete = xt, vn.nextTick = Bt, vn.observable = function(t) {
                return gt(t), t;
            }, vn.options = Object.create(null), L.forEach(function(t) {
                vn.options[t + "s"] = Object.create(null);
            }), T((vn.options._base = vn).options.components, _n), vn.use = function(t) {
                var e = this._installedPlugins || (this._installedPlugins = []);
                if (-1 < e.indexOf(t)) return this;
                var n = P(arguments, 1);
                return n.unshift(this), "function" == typeof t.install ? t.install.apply(t, n) : "function" == typeof t && t.apply(null, n), 
                e.push(t), this;
            }, vn.mixin = function(t) {
                return this.options = Pt(this.options, t), this;
            }, fn(vn), xn = vn, L.forEach(function(n) {
                xn[n] = function(t, e) {
                    return e ? ("component" === n && c(e) && (e.name = e.name || t, e = this.options._base.extend(e)), 
                    "directive" === n && "function" == typeof e && (e = {
                        bind: e,
                        update: e
                    }), this.options[n + "s"][t] = e) : this.options[n + "s"][t];
                };
            }), Object.defineProperty(hn.prototype, "$isServer", {
                get: q
            }), Object.defineProperty(hn.prototype, "$ssrContext", {
                get: function() {
                    return this.$vnode && this.$vnode.ssrContext;
                }
            }), Object.defineProperty(hn, "FunctionalRenderContext", {
                value: xe
            }), hn.version = "2.6.11";
            var bn = "[object Array]", An = "[object Object]";
            function Sn(t, e) {
                var n = {};
                return function n(r, t) {
                    if (r !== t) {
                        var e = Pn(r), i = Pn(t);
                        if (e == An && i == An) {
                            if (Object.keys(r).length >= Object.keys(t).length) for (var o in t) {
                                var a = r[o];
                                void 0 === a ? r[o] = null : n(a, t[o]);
                            }
                        } else e == bn && i == bn && r.length >= t.length && t.forEach(function(t, e) {
                            n(r[e], t);
                        });
                    }
                }(t, e), function a(s, l, c, u) {
                    if (s !== l) {
                        var t = Pn(s), e = Pn(l);
                        if (t == An) if (e != An || Object.keys(s).length < Object.keys(l).length) wn(u, c, s); else {
                            var n, r = function(n) {
                                var t = s[n], r = l[n], e = Pn(t), i = Pn(r);
                                if (e != bn && e != An) t != l[n] && wn(u, ("" == c ? "" : c + ".") + n, t); else if (e == bn) i != bn || t.length < r.length ? wn(u, ("" == c ? "" : c + ".") + n, t) : t.forEach(function(t, e) {
                                    a(t, r[e], ("" == c ? "" : c + ".") + n + "[" + e + "]", u);
                                }); else if (e == An) if (i != An || Object.keys(t).length < Object.keys(r).length) wn(u, ("" == c ? "" : c + ".") + n, t); else for (var o in t) a(t[o], r[o], ("" == c ? "" : c + ".") + n + "." + o, u);
                            };
                            for (n in s) r(n);
                        } else t != bn || e != bn || s.length < l.length ? wn(u, c, s) : s.forEach(function(t, e) {
                            a(t, l[e], c + "[" + e + "]", u);
                        });
                    }
                }(t, e, "", n), n;
            }
            function wn(t, e, n) {
                t[e] = n;
            }
            function Pn(t) {
                return Object.prototype.toString.call(t);
            }
            function Tn(t) {
                if (t.__next_tick_callbacks && t.__next_tick_callbacks.length) {
                    var e;
                    Object({
                        VUE_APP_NAME: "微信智慧外链接致富版",
                        VUE_APP_PLATFORM: "mp-weixin",
                        NODE_ENV: "production",
                        BASE_URL: "/"
                    }).VUE_APP_DEBUG && (e = t.$scope, console.log("[" + +new Date() + "][" + (e.is || e.route) + "][" + t._uid + "]:flushCallbacks[" + t.__next_tick_callbacks.length + "]"));
                    for (var n = t.__next_tick_callbacks.slice(0), r = t.__next_tick_callbacks.length = 0; r < n.length; r++) n[r]();
                }
            }
            function kn(e, t) {
                var n, r, i;
                return e.__next_tick_pending || (n = e, Ee.find(function(t) {
                    return n._watcher === t;
                })) ? (Object({
                    VUE_APP_NAME: "微信智慧外链接致富版",
                    VUE_APP_PLATFORM: "mp-weixin",
                    NODE_ENV: "production",
                    BASE_URL: "/"
                }).VUE_APP_DEBUG && (r = e.$scope, console.log("[" + +new Date() + "][" + (r.is || r.route) + "][" + e._uid + "]:nextMPTick")), 
                e.__next_tick_callbacks || (e.__next_tick_callbacks = []), e.__next_tick_callbacks.push(function() {
                    if (t) try {
                        t.call(e);
                    } catch (t) {
                        Ct(t, e, "nextTick");
                    } else i && i(e);
                }), t || "undefined" == typeof Promise ? void 0 : new Promise(function(t) {
                    i = t;
                })) : (Object({
                    VUE_APP_NAME: "微信智慧外链接致富版",
                    VUE_APP_PLATFORM: "mp-weixin",
                    NODE_ENV: "production",
                    BASE_URL: "/"
                }).VUE_APP_DEBUG && (r = e.$scope, console.log("[" + +new Date() + "][" + (r.is || r.route) + "][" + e._uid + "]:nextVueTick")), 
                Bt(t, e));
            }
            function On() {}
            function Dn(t) {
                return Array.isArray(t) ? function(t) {
                    for (var e, n = "", r = 0, i = t.length; r < i; r++) v(e = Dn(t[r])) && "" !== e && (n && (n += " "), 
                    n += e);
                    return n;
                }(t) : m(t) ? function(t) {
                    var e, n = "";
                    for (e in t) t[e] && (n && (n += " "), n += e);
                    return n;
                }(t) : "string" == typeof t ? t : "";
            }
            var Mn = s(function(t) {
                var e = {}, n = /:(.+)/;
                return t.split(/;(?![^(]*\))/g).forEach(function(t) {
                    !t || 1 < (t = t.split(n)).length && (e[t[0].trim()] = t[1].trim());
                }), e;
            });
            var Cn = [ "createSelectorQuery", "createIntersectionObserver", "selectAllComponents", "selectComponent" ];
            var $n = [ "onLaunch", "onShow", "onHide", "onUniNViewMessage", "onPageNotFound", "onThemeChange", "onError", "onUnhandledRejection", "onInit", "onLoad", "onReady", "onUnload", "onPullDownRefresh", "onReachBottom", "onTabItemTap", "onAddToFavorites", "onShareTimeline", "onShareAppMessage", "onResize", "onPageScroll", "onNavigationBarButtonTap", "onBackPress", "onNavigationBarSearchInputChanged", "onNavigationBarSearchInputConfirmed", "onNavigationBarSearchInputClicked", "onPageShow", "onPageHide", "onPageResize" ];
            hn.prototype.__patch__ = function(t, e) {
                var n = this;
                if (null !== e && ("page" === this.mpType || "component" === this.mpType)) {
                    var r = this.$scope, i = Object.create(null);
                    try {
                        i = function(n) {
                            var e = Object.create(null);
                            [].concat(Object.keys(n._data || {}), Object.keys(n._computedWatchers || {})).reduce(function(t, e) {
                                return t[e] = n[e], t;
                            }, e);
                            var t = n.__composition_api_state__ || n.__secret_vfa_state__;
                            return (t = t && t.rawBindings) && Object.keys(t).forEach(function(t) {
                                e[t] = n[t];
                            }), Object.assign(e, n.$mp.data || {}), Array.isArray(n.$options.behaviors) && -1 !== n.$options.behaviors.indexOf("uni://form-field") && (e.name = n.name, 
                            e.value = n.value), JSON.parse(JSON.stringify(e));
                        }(this);
                    } catch (t) {
                        console.error(t);
                    }
                    i.__webviewId__ = r.data.__webviewId__;
                    var o = Object.create(null);
                    Object.keys(i).forEach(function(t) {
                        o[t] = r.data[t];
                    });
                    e = !1 === this.$shouldDiffData ? i : Sn(i, o);
                    Object.keys(e).length ? (Object({
                        VUE_APP_NAME: "微信智慧外链接致富版",
                        VUE_APP_PLATFORM: "mp-weixin",
                        NODE_ENV: "production",
                        BASE_URL: "/"
                    }).VUE_APP_DEBUG && console.log("[" + +new Date() + "][" + (r.is || r.route) + "][" + this._uid + "]差量更新", JSON.stringify(e)), 
                    this.__next_tick_pending = !0, r.setData(e, function() {
                        n.__next_tick_pending = !1, Tn(n);
                    })) : Tn(this);
                }
            }, hn.prototype.$mount = function(t, e) {
                return r = e, (n = this).mpType && ("app" === n.mpType && (n.$options.render = On), 
                n.$options.render || (n.$options.render = On), n._$fallback || Ie(n, "beforeMount"), 
                new qe(n, function() {
                    n._update(n._render(), r);
                }, O, {
                    before: function() {
                        n._isMounted && !n._isDestroyed && Ie(n, "beforeUpdate");
                    }
                }, !0), r = !1), n;
                var n, r;
            }, function(t) {
                var r = t.extend;
                t.extend = function(e) {
                    var n = (e = e || {}).methods;
                    return n && Object.keys(n).forEach(function(t) {
                        -1 !== $n.indexOf(t) && (e[t] = n[t], delete n[t]);
                    }), r.call(this, e);
                };
                var e = t.config.optionMergeStrategies, n = e.created;
                $n.forEach(function(t) {
                    e[t] = n;
                }), t.prototype.__lifecycle_hooks__ = $n;
            }(hn), function(r) {
                r.config.errorHandler = function(t, e, n) {
                    r.util.warn("Error in " + n + ': "' + t.toString() + '"', e), console.error(t);
                    e = getApp();
                    e && e.onError && e.onError(t);
                };
                var e = r.prototype.$emit;
                r.prototype.$emit = function(t) {
                    return this.$scope && t && this.$scope.triggerEvent(t, {
                        __args__: P(arguments, 1)
                    }), e.apply(this, arguments);
                }, r.prototype.$nextTick = function(t) {
                    return kn(this, t);
                }, Cn.forEach(function(e) {
                    r.prototype[e] = function(t) {
                        return this.$scope && this.$scope[e] ? this.$scope[e](t) : "undefined" != typeof my ? "createSelectorQuery" === e ? my.createSelectorQuery(t) : "createIntersectionObserver" === e ? my.createIntersectionObserver(t) : void 0 : void 0;
                    };
                }), r.prototype.__init_provide = Yt, r.prototype.__init_injections = Qt, r.prototype.__call_hook = function(t, e) {
                    var n = this;
                    rt();
                    var r, i = n.$options[t], o = t + " hook";
                    if (i) for (var a = 0, s = i.length; a < s; a++) r = $t(i[a], n, e ? [ e ] : null, n, o);
                    return n._hasHookEvent && n.$emit("hook:" + t, e), it(), r;
                }, r.prototype.__set_model = function(t, e, n, r) {
                    Array.isArray(r) && (-1 !== r.indexOf("trim") && (n = n.trim()), -1 !== r.indexOf("number") && (n = this._n(n))), 
                    (t = t || this)[e] = n;
                }, r.prototype.__set_sync = function(t, e, n) {
                    (t = t || this)[e] = n;
                }, r.prototype.__get_orig = function(t) {
                    return c(t) && t.$orig || t;
                }, r.prototype.__get_value = function(t, e) {
                    return function t(e, n) {
                        var r = n.split("."), n = r[0];
                        return 0 === n.indexOf("__$n") && (n = parseInt(n.replace("__$n", ""))), 1 === r.length ? e[n] : t(e[n], r.slice(1).join("."));
                    }(e || this, t);
                }, r.prototype.__get_class = function(t, e) {
                    return t = t, v(e = e) || v(t) ? (e = e, t = Dn(t), e ? t ? e + " " + t : e : t || "") : "";
                }, r.prototype.__get_style = function(t, e) {
                    if (!t && !e) return "";
                    var t = (t = t, Array.isArray(t) ? k(t) : "string" == typeof t ? Mn(t) : t), n = e ? T(e, t) : t;
                    return Object.keys(n).map(function(t) {
                        return S(t) + ":" + n[t];
                    }).join(";");
                }, r.prototype.__map = function(t, e) {
                    var n, r, i, o, a;
                    if (Array.isArray(t)) {
                        for (n = new Array(t.length), r = 0, i = t.length; r < i; r++) n[r] = e(t[r], r);
                        return n;
                    }
                    if (m(t)) {
                        for (o = Object.keys(t), n = Object.create(null), r = 0, i = o.length; r < i; r++) n[a = o[r]] = e(t[a], a, r);
                        return n;
                    }
                    if ("number" != typeof t) return [];
                    for (n = new Array(t), r = 0, i = t; r < i; r++) n[r] = e(r, r);
                    return n;
                };
            }(hn), Fn.default = hn;
        }.call(this, e("c8ba"));
    },
    "6b50": function(e, t, n) {
        (function(o) {
            var a = {
                yAxisWidth: 15,
                yAxisSplit: 5,
                xAxisHeight: 15,
                xAxisLineHeight: 15,
                legendHeight: 15,
                yAxisTitleWidth: 15,
                padding: [ 10, 10, 10, 10 ],
                pixelRatio: 1,
                rotate: !1,
                columePadding: 3,
                fontSize: 13,
                dataPointShape: [ "circle", "circle", "circle", "circle" ],
                colors: [ "#1890ff", "#2fc25b", "#facc14", "#f04864", "#8543e0", "#90ed7d" ],
                pieChartLinePadding: 15,
                pieChartTextPadding: 5,
                xAxisTextPadding: 3,
                titleColor: "#333333",
                titleFontSize: 20,
                subtitleColor: "#999999",
                subtitleFontSize: 15,
                toolTipPadding: 3,
                toolTipBackground: "#000000",
                toolTipOpacity: .7,
                toolTipLineHeight: 20,
                radarLabelTextMargin: 15,
                gaugeLabelTextMargin: 15
            }, z = function(e) {
                for (var t = arguments.length, n = new Array(1 < t ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
                if (null == e) throw new TypeError("Cannot convert undefined or null to object");
                return !n || n.length <= 0 || n.forEach(function(t) {
                    e = function t(e, n) {
                        for (var r in n) e[r] = e[r] && "[object Object]" === e[r].toString() ? t(e[r], n[r]) : e[r] = n[r];
                        return e;
                    }(e, t);
                }), e;
            }, k = {
                toFixed: function(t, e) {
                    return e = e || 2, this.isFloat(t) && (t = t.toFixed(e)), t;
                },
                isFloat: function(t) {
                    return t % 1 != 0;
                },
                approximatelyEqual: function(t, e) {
                    return Math.abs(t - e) < 1e-10;
                },
                isSameSign: function(t, e) {
                    return Math.abs(t) === t && Math.abs(e) === e || Math.abs(t) !== t && Math.abs(e) !== e;
                },
                isSameXCoordinateArea: function(t, e) {
                    return this.isSameSign(t.x, e.x);
                },
                isCollision: function(t, e) {
                    return t.end = {}, t.end.x = t.start.x + t.width, t.end.y = t.start.y - t.height, 
                    e.end = {}, e.end.x = e.start.x + e.width, e.end.y = e.start.y - e.height, !(e.start.x > t.end.x || e.end.x < t.start.x || e.end.y > t.start.y || e.start.y < t.end.y);
                }
            };
            function W(t, e) {
                t = t.replace(/^#?([a-f\d])([a-f\d])([a-f\d])$/i, function(t, e, n, r) {
                    return e + e + n + n + r + r;
                }), t = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(t);
                return "rgba(" + parseInt(t[1], 16) + "," + parseInt(t[2], 16) + "," + parseInt(t[3], 16) + "," + e + ")";
            }
            function u(t, e, n) {
                if (isNaN(t)) throw new Error("[uCharts] unvalid series data!");
                n = n || 10, e = e || "upper";
                for (var r = 1; n < 1; ) n *= 10, r *= 10;
                for (t = "upper" === e ? Math.ceil(t * r) : Math.floor(t * r); t % n != 0; ) "upper" === e ? t++ : t--;
                return t / r;
            }
            function F(t, e) {
                function n(t, e) {
                    return t[e - 1] && t[e + 1] && (t[e].y >= Math.max(t[e - 1].y, t[e + 1].y) || t[e].y <= Math.min(t[e - 1].y, t[e + 1].y));
                }
                function r(t, e) {
                    return t[e - 1] && t[e + 1] && (t[e].x >= Math.max(t[e - 1].x, t[e + 1].x) || t[e].x <= Math.min(t[e - 1].x, t[e + 1].x));
                }
                var i, o = null, a = null, s = null, l = null, a = e < 1 ? (o = t[0].x + .2 * (t[1].x - t[0].x), 
                t[0].y + .2 * (t[1].y - t[0].y)) : (o = t[e].x + .2 * (t[e + 1].x - t[e - 1].x), 
                t[e].y + .2 * (t[e + 1].y - t[e - 1].y));
                return l = e > t.length - 3 ? (s = t[i = t.length - 1].x - .2 * (t[i].x - t[i - 1].x), 
                t[i].y - .2 * (t[i].y - t[i - 1].y)) : (s = t[e + 1].x - .2 * (t[e + 2].x - t[e].x), 
                t[e + 1].y - .2 * (t[e + 2].y - t[e].y)), n(t, e + 1) && (l = t[e + 1].y), n(t, e) && (a = t[e].y), 
                r(t, e + 1) && (s = t[e + 1].x), r(t, e) && (o = t[e].x), (a >= Math.max(t[e].y, t[e + 1].y) || a <= Math.min(t[e].y, t[e + 1].y)) && (a = t[e].y), 
                (l >= Math.max(t[e].y, t[e + 1].y) || l <= Math.min(t[e].y, t[e + 1].y)) && (l = t[e + 1].y), 
                (o >= Math.max(t[e].x, t[e + 1].x) || o <= Math.min(t[e].x, t[e + 1].x)) && (o = t[e].x), 
                (s >= Math.max(t[e].x, t[e + 1].x) || s <= Math.min(t[e].x, t[e + 1].x)) && (s = t[e + 1].x), 
                {
                    ctrA: {
                        x: o,
                        y: a
                    },
                    ctrB: {
                        x: s,
                        y: l
                    }
                };
            }
            function O(t, e, n) {
                return {
                    x: n.x + t,
                    y: n.y - e
                };
            }
            function P(t, e, n) {
                var r = 0;
                return t.map(function(t) {
                    if (t.color || (t.color = n.colors[r], r = (r + 1) % n.colors.length), t.index || (t.index = 0), 
                    t.type || (t.type = e.type), void 0 === t.show && (t.show = !0), t.type || (t.type = e.type), 
                    t.pointShape || (t.pointShape = "circle"), !t.legendShape) switch (t.type) {
                      case "line":
                        t.legendShape = "line";
                        break;

                      case "column":
                        t.legendShape = "rect";
                        break;

                      case "area":
                        t.legendShape = "triangle";
                        break;

                      default:
                        t.legendShape = "circle";
                    }
                    return t;
                });
            }
            function $(t, e) {
                e = 1 < arguments.length && void 0 !== e ? e : a.fontSize;
                t = (t = String(t)).split("");
                for (var n = 0, r = 0; r < t.length; r++) {
                    var i = t[r];
                    /[a-zA-Z]/.test(i) ? n += 7 : /[0-9]/.test(i) ? n += 5.5 : /\./.test(i) ? n += 2.7 : /-/.test(i) ? n += 3.25 : /[\u4e00-\u9fa5]/.test(i) ? n += 10 : /\(|\)/.test(i) ? n += 3.73 : /\s/.test(i) ? n += 2.5 : /%/.test(i) ? n += 8 : n += 10;
                }
                return n * e / 10;
            }
            function h(t) {
                return t.reduce(function(t, e) {
                    return (t.data || t).concat(e.data);
                }, []);
            }
            function f(t, e, n) {
                var r, i;
                return t.clientX ? e.rotate ? (i = e.height - t.clientX * e.pixelRatio, r = (t.pageY - n.currentTarget.offsetTop - e.height / e.pixelRatio / 2 * (e.pixelRatio - 1)) * e.pixelRatio) : (r = t.clientX * e.pixelRatio, 
                i = (t.pageY - n.currentTarget.offsetTop - e.height / e.pixelRatio / 2 * (e.pixelRatio - 1)) * e.pixelRatio) : e.rotate ? (i = e.height - t.x * e.pixelRatio, 
                r = t.y * e.pixelRatio) : (r = t.x * e.pixelRatio, i = t.y * e.pixelRatio), {
                    x: r,
                    y: i
                };
            }
            function p(t, e) {
                for (var n = [], r = 0; r < t.length; r++) {
                    var i, o = t[r];
                    null !== o.data[e] && void 0 !== o.data[e] && o.show && ((i = {}).color = o.color, 
                    i.type = o.type, i.style = o.style, i.pointShape = o.pointShape, i.disableLegend = o.disableLegend, 
                    i.name = o.name, i.show = o.show, i.data = o.format ? o.format(o.data[e]) : o.data[e], 
                    n.push(i));
                }
                return n;
            }
            function l(t, e) {
                for (var n, r, i, o = -1, a = e.chartData.mapData, s = e.series, e = (n = t.y, r = t.x, 
                i = a.bounds, e = a.scale, t = a.xoffset, a = a.yoffset, {
                    x: (r - t) / e + i.xMin,
                    y: i.yMax - (n - a) / e
                }), l = [ e.x, e.y ], c = 0, u = s.length; c < u; c++) if (function(t, e) {
                    for (var n = 0, r = 0; r < e.length; r++) {
                        var i = e[r][0];
                        1 == e.length && (i = e[r][0]);
                        for (var o = 0; o < i.length - 1; o++) {
                            var a = i[o], s = i[o + 1];
                            !function(t, e, n) {
                                return e[1] != n[1] && (!(e[1] > t[1] && n[1] > t[1]) && (!(e[1] < t[1] && n[1] < t[1]) && (!(e[1] == t[1] && n[1] > t[1]) && (!(n[1] == t[1] && e[1] > t[1]) && (!(e[0] < t[0] && n[1] < t[1]) && !(n[0] - (n[0] - e[0]) * (n[1] - t[1]) / (n[1] - e[1]) < t[0]))))));
                            }(t, a, s) || (n += 1);
                        }
                    }
                    return n % 2 == 1;
                }(l, s[c].geometry.coordinates)) {
                    o = c;
                    break;
                }
                return o;
            }
            function c(t, e) {
                var n, r, i = -1;
                if (d(t, e.center, e.radius)) for (var o = -(o = Math.atan2(e.center.y - t.y, t.x - e.center.x)), a = 0, s = e.series.length; a < s; a++) {
                    var l = e.series[a];
                    if (n = o, r = l._start_, l = l._start_ + 2 * l._proportion_ * Math.PI, n = c(n), 
                    r = c(r), (l = c(l)) < r && (l += 2 * Math.PI, n < r && (n += 2 * Math.PI)), r <= n && n <= l) {
                        i = a;
                        break;
                    }
                }
                function c(t) {
                    for (;t < 0; ) t += 2 * Math.PI;
                    for (;t > 2 * Math.PI; ) t -= 2 * Math.PI;
                    return t;
                }
                return i;
            }
            function d(t, e, n) {
                return Math.pow(t.x - e.x, 2) + Math.pow(t.y - e.y, 2) <= Math.pow(n, 2);
            }
            function L(t) {
                var n = [], r = [];
                return t.forEach(function(t, e) {
                    null !== t ? r.push(t) : (r.length && n.push(r), r = []);
                }), r.length && n.push(r), n;
            }
            function T(t, e, n, r) {
                var i = {
                    angle: 0,
                    xAxisHeight: n.xAxisHeight
                }, t = t.map(function(t) {
                    return $(t, e.xAxis.fontSize || n.fontSize);
                }), t = Math.max.apply(this, t);
                return 1 == e.xAxis.rotateLabel && t + 2 * n.xAxisTextPadding > r && (i.angle = 45 * Math.PI / 180, 
                i.xAxisHeight = 2 * n.xAxisTextPadding + t * Math.sin(i.angle)), i;
            }
            function D(t, e, n) {
                var r = {
                    angle: 0,
                    xAxisHeight: n.xAxisHeight
                };
                r.ranges = function(t, e, n, r, i) {
                    var o = 4 < arguments.length && void 0 !== i ? i : -1, i = h(t), a = [];
                    (i = i.filter(function(t) {
                        return "object" !== (void 0 === t ? "undefined" : _typeof(t)) || null === t || -1 < t.constructor.toString().indexOf("Array") ? null !== t : null !== t.value;
                    })).map(function(t) {
                        "object" === (void 0 === t ? "undefined" : _typeof(t)) ? -1 < t.constructor.toString().indexOf("Array") ? "candle" == e.type ? t.map(function(t) {
                            a.push(t);
                        }) : a.push(t[0]) : a.push(t.value) : a.push(t);
                    }), (i = t = 0) < a.length && (t = Math.min.apply(this, a), i = Math.max.apply(this, a)), 
                    -1 < o ? ("number" == typeof e.xAxis.data[o].min && (t = Math.min(e.xAxis.data[o].min, t)), 
                    "number" == typeof e.xAxis.data[o].max && (i = Math.max(e.xAxis.data[o].max, i))) : ("number" == typeof e.xAxis.min && (t = Math.min(e.xAxis.min, t)), 
                    "number" == typeof e.xAxis.max && (i = Math.max(e.xAxis.max, i))), t === i && (i += i || 10);
                    for (var s = t, l = [], c = (i - s) / e.xAxis.splitNumber, u = 0; u <= e.xAxis.splitNumber; u++) l.push(s + c * u);
                    return l;
                }(t, e, n), r.rangesFormat = r.ranges.map(function(t) {
                    return t = e.xAxis.format ? e.xAxis.format(t) : k.toFixed(t, 2);
                });
                var i = r.ranges.map(function(t) {
                    return t = k.toFixed(t, 2), t = e.xAxis.format ? e.xAxis.format(Number(t)) : t;
                }), t = (r = Object.assign(r, R(i, e))).eachSpacing, i = i.map(function(t) {
                    return $(t);
                }), i = Math.max.apply(this, i);
                return i + 2 * n.xAxisTextPadding > t && (r.angle = 45 * Math.PI / 180, r.xAxisHeight = 2 * n.xAxisTextPadding + i * Math.sin(r.angle)), 
                !0 === e.xAxis.disabled && (r.xAxisHeight = 0), r;
            }
            function v(i, o, a, e, t, n) {
                var s = 5 < arguments.length && void 0 !== n ? n : 1, t = t.extra.radar || {};
                t.max = t.max || 0;
                for (var l = Math.max(t.max, Math.max.apply(null, h(e))), c = [], r = 0; r < e.length; r++) !function(t) {
                    var t = e[t], r = {};
                    r.color = t.color, r.legendShape = t.legendShape, r.pointShape = t.pointShape, r.data = [], 
                    t.data.forEach(function(t, e) {
                        var n = {};
                        n.angle = i[e], n.proportion = t / l, n.position = O(a * n.proportion * s * Math.cos(n.angle), a * n.proportion * s * Math.sin(n.angle), o), 
                        r.data.push(n);
                    }), c.push(r);
                }(r);
                return c;
            }
            function M(t, e, n) {
                for (var r = 2 < arguments.length && void 0 !== n ? n : 1, i = 0, o = 0, a = 0; a < t.length; a++) {
                    var s = t[a];
                    s.data = null === s.data ? 0 : s.data, i += s.data;
                }
                for (var l = 0; l < t.length; l++) {
                    var c = t[l];
                    c.data = null === c.data ? 0 : c.data, c._proportion_ = 0 === i ? 1 / t.length * r : c.data / i * r, 
                    c._radius_ = e;
                }
                for (var u = 0; u < t.length; u++) {
                    var h = t[u];
                    h._start_ = o, o += 2 * h._proportion_ * Math.PI;
                }
                return t;
            }
            function C(t, e, n) {
                var r = 2 < arguments.length && void 0 !== n ? n : 1;
                1 == r && (r = .999999);
                for (var i = 0; i < t.length; i++) {
                    var o = t[i];
                    o.data = null === o.data ? 0 : o.data;
                    var a = "circle" == e.type ? 2 : e.endAngle < e.startAngle ? 2 + e.endAngle - e.startAngle : e.startAngle - e.endAngle;
                    o._proportion_ = a * o.data * r + e.startAngle, 2 <= o._proportion_ && (o._proportion_ = o._proportion_ % 2);
                }
                return t;
            }
            function N(t, e, n, r, i, o) {
                return t.map(function(t) {
                    return null === t ? null : (t.width = Math.ceil((e - 2 * i.columePadding) / n), 
                    o.extra.column && o.extra.column.width && 0 < +o.extra.column.width && (t.width = Math.min(t.width, +o.extra.column.width)), 
                    t.width <= 0 && (t.width = 1), t.x += (r + .5 - n / 2) * t.width, t);
                });
            }
            function R(t, e) {
                var n = e.width - e.area[1] - e.area[3], r = e.enableScroll ? Math.min(e.xAxis.itemCount, t.length) : t.length;
                ("line" == e.type || "area" == e.type) && 1 < r && "justify" == e.xAxis.boundaryGap && --r;
                var i = n / r, o = [], a = e.area[3], r = e.width - e.area[1];
                return t.forEach(function(t, e) {
                    o.push(a + e * i);
                }), "justify" !== e.xAxis.boundaryGap && (!0 === e.enableScroll ? o.push(a + t.length * i) : o.push(r)), 
                {
                    xAxisPoints: o,
                    startX: a,
                    endX: r,
                    eachSpacing: i
                };
            }
            function B(t, o, a, s, l, c, e, n) {
                var u = 7 < arguments.length && void 0 !== n ? n : 1, h = "center";
                "line" != c.type && "area" != c.type || (h = c.xAxis.boundaryGap);
                var f = [], p = c.height - c.area[0] - c.area[2], d = c.width - c.area[1] - c.area[3];
                return t.forEach(function(t, e) {
                    var n, r, i;
                    null === t ? f.push(null) : ((n = {}).color = t.color, n.x = s[e], "object" === (void 0 === (i = t) ? "undefined" : _typeof(t)) && null !== t && (-1 < t.constructor.toString().indexOf("Array") ? (e = (r = [].concat(c.chartData.xAxisData.ranges)).shift(), 
                    r = r.pop(), i = t[1], n.x = c.area[3] + d * (t[0] - e) / (r - e)) : i = t.value), 
                    "center" == h && (n.x += Math.round(l / 2)), i = p * (i - o) / (a - o), i *= u, 
                    n.y = c.height - Math.round(i) - c.area[2], f.push(n));
                }), f;
            }
            function U(t, s, l, c, u, h, e, f, p, n) {
                var d = 9 < arguments.length && void 0 !== n ? n : 1, g = [], y = h.height - h.area[0] - h.area[2];
                return t.forEach(function(t, e) {
                    if (null === t) g.push(null); else {
                        var n = {};
                        if (n.color = t.color, n.x = c[e] + Math.round(u / 2), 0 < f) {
                            for (var r = 0, i = 0; i <= f; i++) r += p[i].data[e];
                            var o = y * (r - s) / (l - s), a = y * (r - t - s) / (l - s);
                        } else o = y * ((r = t) - s) / (l - s), a = 0;
                        a = a;
                        o *= d, a *= d, n.y = h.height - Math.round(o) - h.area[2], n.y0 = h.height - Math.round(a) - h.area[2], 
                        g.push(n);
                    }
                }), g;
            }
            function g(t, e, n, r, i) {
                var i = 4 < arguments.length && void 0 !== i ? i : -1, r = "stack" == r ? function(t, e) {
                    for (var n = new Array(e), r = 0; r < n.length; r++) n[r] = 0;
                    for (var i = 0; i < t.length; i++) for (r = 0; r < n.length; r++) n[r] += t[i].data[r];
                    return t.reduce(function(t, e) {
                        return (t.data || t).concat(e.data).concat(n);
                    }, []);
                }(t, e.categories.length) : h(t), o = [];
                (r = r.filter(function(t) {
                    return "object" !== (void 0 === t ? "undefined" : _typeof(t)) || null === t || -1 < t.constructor.toString().indexOf("Array") ? null !== t : null !== t.value;
                })).map(function(t) {
                    "object" === (void 0 === t ? "undefined" : _typeof(t)) ? -1 < t.constructor.toString().indexOf("Array") ? "candle" == e.type ? t.map(function(t) {
                        o.push(t);
                    }) : o.push(t[1]) : o.push(t.value) : o.push(t);
                });
                t = 0, r = 0;
                0 < o.length && (t = Math.min.apply(this, o), r = Math.max.apply(this, o)), -1 < i ? ("number" == typeof e.yAxis.data[i].min && (t = Math.min(e.yAxis.data[i].min, t)), 
                "number" == typeof e.yAxis.data[i].max && (r = Math.max(e.yAxis.data[i].max, r))) : ("number" == typeof e.yAxis.min && (t = Math.min(e.yAxis.min, t)), 
                "number" == typeof e.yAxis.max && (r = Math.max(e.yAxis.max, r))), t === r && (r += r || 10);
                for (var i = (i = 0, {
                    minRange: u(t = t, "lower", i = 1e4 <= (t = (r = r) - t) ? 1e3 : 1e3 <= t ? 100 : 100 <= t ? 10 : 10 <= t ? 5 : 1 <= t ? 1 : .1 <= t ? .1 : .01 <= t ? .01 : .001 <= t ? .001 : 1e-4 <= t ? 1e-4 : 1e-5 <= t ? 1e-5 : 1e-6),
                    maxRange: u(r, "upper", i)
                }), a = i.minRange, s = [], l = (i.maxRange - a) / e.yAxis.splitNumber, c = 0; c <= e.yAxis.splitNumber; c++) s.push(a + l * c);
                return s.reverse();
            }
            function j(t, i, o) {
                var a = z({}, {
                    type: ""
                }, i.extra.column), e = i.yAxis.data.length, s = new Array(e);
                if (0 < e) {
                    for (var n = 0; n < e; n++) {
                        s[n] = [];
                        for (var r = 0; r < t.length; r++) t[r].index == n && s[n].push(t[r]);
                    }
                    for (var l = new Array(e), c = new Array(e), u = new Array(e), h = 0; h < e; h++) !function(e) {
                        var n = i.yAxis.data[e];
                        1 == i.yAxis.disabled && (n.disabled = !0), l[e] = g(s[e], i, o, a.type, e);
                        var r = n.fontSize || o.fontSize;
                        u[e] = {
                            position: n.position || "left",
                            width: 0
                        }, c[e] = l[e].map(function(t) {
                            return t = k.toFixed(t, 6), t = n.format ? n.format(Number(t)) : t, u[e].width = Math.max(u[e].width, $(t, r) + 5), 
                            t;
                        });
                        var t = n.calibration ? 4 * i.pixelRatio : 0;
                        u[e].width += t + 3 * i.pixelRatio, !0 === n.disabled && (u[e].width = 0);
                    }(h);
                } else {
                    l = new Array(1), c = new Array(1), u = new Array(1), l[0] = g(t, i, o, a.type), 
                    u[0] = {
                        position: "left",
                        width: 0
                    };
                    var f = i.yAxis.fontSize || o.fontSize;
                    c[0] = l[0].map(function(t) {
                        return t = k.toFixed(t, 6), t = i.yAxis.format ? i.yAxis.format(Number(t)) : t, 
                        u[0].width = Math.max(u[0].width, $(t, f) + 5), t;
                    }), u[0].width += 3 * i.pixelRatio, !0 === i.yAxis.disabled ? (u[0] = {
                        position: "left",
                        width: 0
                    }, i.yAxis.data[0] = {
                        disabled: !0
                    }) : i.yAxis.data[0] = {
                        disabled: !1,
                        position: "left",
                        max: i.yAxis.max,
                        min: i.yAxis.min,
                        format: i.yAxis.format
                    };
                }
                return {
                    rangesFormat: c,
                    ranges: l,
                    yAxisWidth: u
                };
            }
            function I(t, e) {
                !0 !== e.rotateLock ? (t.translate(e.height, 0), t.rotate(90 * Math.PI / 180)) : !0 !== e._rotate_ && (t.translate(e.height, 0), 
                t.rotate(90 * Math.PI / 180), e._rotate_ = !0);
            }
            function E(t, e, n, r, i) {
                r.beginPath(), "hollow" == i.dataPointShapeType ? (r.setStrokeStyle(e), r.setFillStyle(i.background), 
                r.setLineWidth(2 * i.pixelRatio)) : (r.setStrokeStyle("#ffffff"), r.setFillStyle(e), 
                r.setLineWidth(+i.pixelRatio)), "diamond" === n ? t.forEach(function(t, e) {
                    null !== t && (r.moveTo(t.x, t.y - 4.5), r.lineTo(t.x - 4.5, t.y), r.lineTo(t.x, t.y + 4.5), 
                    r.lineTo(t.x + 4.5, t.y), r.lineTo(t.x, t.y - 4.5));
                }) : "circle" === n ? t.forEach(function(t, e) {
                    null !== t && (r.moveTo(t.x + 2.5 * i.pixelRatio, t.y), r.arc(t.x, t.y, 3 * i.pixelRatio, 0, 2 * Math.PI, !1));
                }) : "rect" === n ? t.forEach(function(t, e) {
                    null !== t && (r.moveTo(t.x - 3.5, t.y - 3.5), r.rect(t.x - 3.5, t.y - 3.5, 7, 7));
                }) : "triangle" === n && t.forEach(function(t, e) {
                    null !== t && (r.moveTo(t.x, t.y - 4.5), r.lineTo(t.x - 4.5, t.y + 4.5), r.lineTo(t.x + 4.5, t.y + 4.5), 
                    r.lineTo(t.x, t.y - 4.5));
                }), r.closePath(), r.fill(), r.stroke();
            }
            function H(t, e, n, r) {
                var i, o = t.title.fontSize || e.titleFontSize, a = t.subtitle.fontSize || e.subtitleFontSize, s = t.title.name || "", l = t.subtitle.name || "", c = t.title.color || e.titleColor, u = t.subtitle.color || e.subtitleColor, h = s ? o : 0, f = l ? a : 0;
                l && (i = $(l, a), e = r.x - i / 2 + (t.subtitle.offsetX || 0), i = r.y + a / 2 + (t.subtitle.offsetY || 0), 
                s && (i += (h + 5) / 2), n.beginPath(), n.setFontSize(a), n.setFillStyle(u), n.fillText(l, e, i), 
                n.closePath(), n.stroke()), s && (i = $(s, o), i = r.x - i / 2 + (t.title.offsetX || 0), 
                t = r.y + o / 2 + (t.title.offsetY || 0), l && (t -= (f + 5) / 2), n.beginPath(), 
                n.setFontSize(o), n.setFillStyle(c), n.fillText(s, i, t), n.closePath(), n.stroke());
            }
            function V(t, r, i, o) {
                var a = r.data;
                t.forEach(function(t, e) {
                    var n;
                    null !== t && (o.beginPath(), o.setFontSize(r.textSize || i.fontSize), o.setFillStyle(r.textColor || "#666666"), 
                    n = a[e], "object" === _typeof(a[e]) && null !== a[e] && (n = a[e].constructor == Array ? a[e][1] : a[e].value), 
                    n = r.format ? r.format(n) : n, o.fillText(String(n), t.x - $(n, r.textSize || i.fontSize) / 2, t.y - 4), 
                    o.closePath(), o.stroke());
                });
            }
            function X(t, e, n, r, i, o) {
                for (var a = n.pieChartLinePadding, s = [], l = null, c = t.map(function(t) {
                    var e = t.format ? t.format(+t._proportion_.toFixed(2)) : k.toFixed(100 * t._proportion_.toFixed(4)) + "%";
                    return t._rose_proportion_ && (t._proportion_ = t._rose_proportion_), {
                        arc: 2 * Math.PI - (t._start_ + 2 * Math.PI * t._proportion_ / 2),
                        text: e,
                        color: t.color,
                        radius: t._radius_,
                        textColor: t.textColor,
                        textSize: t.textSize
                    };
                }), u = 0; u < c.length; u++) {
                    var h = c[u], f = Math.cos(h.arc) * (h.radius + a), p = Math.sin(h.arc) * (h.radius + a), d = Math.cos(h.arc) * h.radius, g = Math.sin(h.arc) * h.radius, y = 0 <= f ? f + n.pieChartTextPadding : f - n.pieChartTextPadding, v = p, x = $(h.text, h.textSize || n.fontSize), m = v;
                    l && k.isSameXCoordinateArea(l.start, {
                        x: y
                    }) && (m = !(0 < y) && (f < 0 || 0 < v) ? Math.max(v, l.start.y) : Math.min(v, l.start.y)), 
                    y < 0 && (y -= x);
                    l = function(t, e) {
                        if (e) for (;k.isCollision(t, e); ) !(0 < t.start.x) && (t.start.x < 0 || 0 < t.start.y) ? t.start.y++ : t.start.y--;
                        return t;
                    }({
                        lineStart: {
                            x: d,
                            y: g
                        },
                        lineEnd: {
                            x: f,
                            y: p
                        },
                        start: {
                            x: y,
                            y: m
                        },
                        width: x,
                        height: n.fontSize,
                        text: h.text,
                        color: h.color,
                        textColor: h.textColor,
                        textSize: h.textSize
                    }, l);
                    s.push(l);
                }
                for (var _ = 0; _ < s.length; _++) {
                    var b = s[_], A = O(b.lineStart.x, b.lineStart.y, o), S = O(b.lineEnd.x, b.lineEnd.y, o), w = O(b.start.x, b.start.y, o);
                    r.setLineWidth(+e.pixelRatio), r.setFontSize(n.fontSize), r.beginPath(), r.setStrokeStyle(b.color), 
                    r.setFillStyle(b.color), r.moveTo(A.x, A.y);
                    var P = b.start.x < 0 ? w.x + b.width : w.x, T = b.start.x < 0 ? w.x - 5 : w.x + 5;
                    r.quadraticCurveTo(S.x, S.y, P, w.y), r.moveTo(A.x, A.y), r.stroke(), r.closePath(), 
                    r.beginPath(), r.moveTo(w.x + b.width, w.y), r.arc(P, w.y, 2, 0, 2 * Math.PI), r.closePath(), 
                    r.fill(), r.beginPath(), r.setFontSize(b.textSize || n.fontSize), r.setFillStyle(b.textColor || "#666666"), 
                    r.fillText(b.text, T, w.y + 3), r.closePath(), r.stroke(), r.closePath();
                }
            }
            function G(t, e, n) {
                for (var r = z({}, {
                    type: "solid",
                    dashLength: 4,
                    data: []
                }, t.extra.markLine), i = t.area[3], o = t.width - t.area[1], a = function(t, e) {
                    for (var n = e.height - e.area[0] - e.area[2], r = 0; r < t.length; r++) {
                        t[r].yAxisIndex = t[r].yAxisIndex || 0;
                        var i = [].concat(e.chartData.yAxisData.ranges[t[r].yAxisIndex]), o = i.pop(), i = i.shift(), o = n * (t[r].value - o) / (i - o);
                        t[r].y = e.height - Math.round(o) - e.area[2];
                    }
                    return t;
                }(r.data, t), s = 0; s < a.length; s++) {
                    var l, c, u, h, f, p = z({}, {
                        lineColor: "#DE4A42",
                        showLabel: !1,
                        labelFontColor: "#666666",
                        labelBgColor: "#DFE8FF",
                        labelBgOpacity: .8,
                        yAxisIndex: 0
                    }, a[s]);
                    "dash" == r.type && n.setLineDash([ r.dashLength, r.dashLength ]), n.setStrokeStyle(p.lineColor), 
                    n.setLineWidth(+t.pixelRatio), n.beginPath(), n.moveTo(i, p.y), n.lineTo(o, p.y), 
                    n.stroke(), n.setLineDash([]), p.showLabel && (l = t.yAxis.format ? t.yAxis.format(Number(p.value)) : p.value, 
                    n.setFontSize(e.fontSize), f = $(l, e.fontSize), h = (c = t.padding[3] + e.yAxisTitleWidth - e.toolTipPadding) + ((u = Math.max(t.area[3], f + 2 * e.toolTipPadding) - c) - f) / 2, 
                    f = p.y, n.setFillStyle(W(p.labelBgColor, p.labelBgOpacity)), n.setStrokeStyle(p.labelBgColor), 
                    n.setLineWidth(+t.pixelRatio), n.beginPath(), n.rect(c, f - .5 * e.fontSize - e.toolTipPadding, u, e.fontSize + 2 * e.toolTipPadding), 
                    n.closePath(), n.stroke(), n.fill(), n.beginPath(), n.setFontSize(e.fontSize), n.setFillStyle(p.labelFontColor), 
                    n.fillText(String(l), h, f + .5 * e.fontSize), n.stroke());
                }
            }
            function i(t, e, n) {
                var r = z({}, {
                    gridType: "solid",
                    dashLength: 4
                }, t.extra.tooltip), i = t.area[3], o = t.width - t.area[1];
                if ("dash" == r.gridType && n.setLineDash([ r.dashLength, r.dashLength ]), n.setStrokeStyle(r.gridColor || "#cccccc"), 
                n.setLineWidth(+t.pixelRatio), n.beginPath(), n.moveTo(i, t.tooltip.offset.y), n.lineTo(o, t.tooltip.offset.y), 
                n.stroke(), n.setLineDash([]), r.yAxisLabel) for (var a = function(t, e) {
                    for (var n = [].concat(e.chartData.yAxisData.ranges), r = e.height - e.area[0] - e.area[2], i = e.area[0], o = [], a = 0; a < n.length; a++) {
                        var s = n[a].shift(), s = s - (s - n[a].pop()) * (t - i) / r, s = e.yAxis.data[a].format ? e.yAxis.data[a].format(Number(s)) : s.toFixed(0);
                        o.push(String(s));
                    }
                    return o;
                }(t.tooltip.offset.y, (t.series, t)), s = t.chartData.yAxisData.yAxisWidth, l = t.area[3], c = t.width - t.area[1], u = 0; u < a.length; u++) {
                    n.setFontSize(e.fontSize);
                    var h = $(a[u], e.fontSize), f = void 0, p = void 0, d = void 0, p = "left" == s[u].position ? (f = l - s[u].width, 
                    Math.max(f, f + h + 2 * e.toolTipPadding)) : (f = c, Math.max(f + s[u].width, f + h + 2 * e.toolTipPadding)), p = f + ((d = p - f) - h) / 2, h = t.tooltip.offset.y;
                    n.beginPath(), n.setFillStyle(W(r.labelBgColor || e.toolTipBackground, r.labelBgOpacity || e.toolTipOpacity)), 
                    n.setStrokeStyle(r.labelBgColor || e.toolTipBackground), n.setLineWidth(+t.pixelRatio), 
                    n.rect(f, h - .5 * e.fontSize - e.toolTipPadding, d, e.fontSize + 2 * e.toolTipPadding), 
                    n.closePath(), n.stroke(), n.fill(), n.beginPath(), n.setFontSize(e.fontSize), n.setFillStyle(r.labelFontColor || e.fontColor), 
                    n.fillText(a[u], p, h + .5 * e.fontSize), n.closePath(), n.stroke(), "left" == s[u].position ? l -= s[u].width + t.yAxis.padding : c += s[u].width + t.yAxis.padding;
                }
            }
            function s(t, r, e, i, o) {
                var a = z({}, {
                    showBox: !0,
                    bgColor: "#000000",
                    bgOpacity: .7,
                    fontColor: "#FFFFFF"
                }, e.extra.tooltip), s = 4 * e.pixelRatio, l = 5 * e.pixelRatio, c = 8 * e.pixelRatio, u = !1;
                "line" != e.type && "area" != e.type && "candle" != e.type && "mix" != e.type || function(t, e, n, r) {
                    var i = e.extra.tooltip || {};
                    i.gridType = null == i.gridType ? "solid" : i.gridType, i.dashLength = null == i.dashLength ? 4 : i.dashLength;
                    var o, a = e.area[0], s = e.height - e.area[2];
                    "dash" == i.gridType && r.setLineDash([ i.dashLength, i.dashLength ]), r.setStrokeStyle(i.gridColor || "#cccccc"), 
                    r.setLineWidth(+e.pixelRatio), r.beginPath(), r.moveTo(t, a), r.lineTo(t, s), r.stroke(), 
                    r.setLineDash([]), i.xAxisLabel && (o = e.categories[e.tooltip.index], r.setFontSize(n.fontSize), 
                    t = t - .5 * (a = $(o, n.fontSize)), s = s, r.beginPath(), r.setFillStyle(W(i.labelBgColor || n.toolTipBackground, i.labelBgOpacity || n.toolTipOpacity)), 
                    r.setStrokeStyle(i.labelBgColor || n.toolTipBackground), r.setLineWidth(+e.pixelRatio), 
                    r.rect(t - n.toolTipPadding, s, a + 2 * n.toolTipPadding, n.fontSize + 2 * n.toolTipPadding), 
                    r.closePath(), r.stroke(), r.fill(), r.beginPath(), r.setFontSize(n.fontSize), r.setFillStyle(i.labelFontColor || n.fontColor), 
                    r.fillText(String(o), t, s + n.toolTipPadding + n.fontSize), r.closePath(), r.stroke());
                }(e.tooltip.offset.x, e, i, o), (r = z({
                    x: 0,
                    y: 0
                }, r)).y -= 8 * e.pixelRatio;
                var n = t.map(function(t) {
                    return $(t.text, i.fontSize);
                }), h = s + l + 4 * i.toolTipPadding + Math.max.apply(null, n), n = 2 * i.toolTipPadding + t.length * i.toolTipLineHeight;
                0 != a.showBox && (r.x - Math.abs(e._scrollDistance_) + c + h > e.width && (u = !0), 
                n + r.y > e.height && (r.y = e.height - n), o.beginPath(), o.setFillStyle(W(a.bgColor || i.toolTipBackground, a.bgOpacity || i.toolTipOpacity)), 
                u ? (o.moveTo(r.x, r.y + 10 * e.pixelRatio), o.lineTo(r.x - c, r.y + 10 * e.pixelRatio - 5 * e.pixelRatio), 
                o.lineTo(r.x - c, r.y), o.lineTo(r.x - c - Math.round(h), r.y), o.lineTo(r.x - c - Math.round(h), r.y + n), 
                o.lineTo(r.x - c, r.y + n), o.lineTo(r.x - c, r.y + 10 * e.pixelRatio + 5 * e.pixelRatio)) : (o.moveTo(r.x, r.y + 10 * e.pixelRatio), 
                o.lineTo(r.x + c, r.y + 10 * e.pixelRatio - 5 * e.pixelRatio), o.lineTo(r.x + c, r.y), 
                o.lineTo(r.x + c + Math.round(h), r.y), o.lineTo(r.x + c + Math.round(h), r.y + n), 
                o.lineTo(r.x + c, r.y + n), o.lineTo(r.x + c, r.y + 10 * e.pixelRatio + 5 * e.pixelRatio)), 
                o.lineTo(r.x, r.y + 10 * e.pixelRatio), o.closePath(), o.fill(), t.forEach(function(t, e) {
                    null !== t.color && (o.beginPath(), o.setFillStyle(t.color), t = r.x + c + 2 * i.toolTipPadding, 
                    e = r.y + (i.toolTipLineHeight - i.fontSize) / 2 + i.toolTipLineHeight * e + i.toolTipPadding + 1, 
                    u && (t = r.x - h - c + 2 * i.toolTipPadding), o.fillRect(t, e, s, i.fontSize), 
                    o.closePath());
                }), t.forEach(function(t, e) {
                    var n = r.x + c + 2 * i.toolTipPadding + s + l;
                    u && (n = r.x - h - c + 2 * i.toolTipPadding + +s + l);
                    e = r.y + (i.toolTipLineHeight - i.fontSize) / 2 + i.toolTipLineHeight * e + i.toolTipPadding;
                    o.beginPath(), o.setFontSize(i.fontSize), o.setFillStyle(a.fontColor), o.fillText(t.text, n, e + i.fontSize), 
                    o.closePath(), o.stroke();
                }));
            }
            function q(O, D, M, C, t) {
                var $ = 4 < arguments.length && void 0 !== t ? t : 1, e = D.chartData.xAxisData, F = e.xAxisPoints, L = e.eachSpacing, R = z({}, {
                    type: "group",
                    width: L / 2,
                    meter: {
                        border: 4,
                        fillColor: "#FFFFFF"
                    }
                }, D.extra.column), j = [];
                C.save();
                var n, r, i, o, I = -2, E = F.length + 2;
                return D._scrollDistance_ && 0 !== D._scrollDistance_ && !0 === D.enableScroll && (C.translate(D._scrollDistance_, 0), 
                I = Math.floor(-D._scrollDistance_ / L) - 2, E = I + D.xAxis.itemCount + 4), D.tooltip && D.tooltip.textList && D.tooltip.textList.length && 1 === $ && (n = D.tooltip.offset.x, 
                i = C, o = L, t = z({}, {
                    activeBgColor: "#000000",
                    activeBgOpacity: .08
                }, (r = D).extra.tooltip), e = r.area[0], r = r.height - r.area[2], i.beginPath(), 
                i.setFillStyle(W(t.activeBgColor, t.activeBgOpacity)), i.rect(n - o / 2, e, o, r - e), 
                i.closePath(), i.fill()), O.forEach(function(t, e) {
                    var n, r, i, o, a, s, l, c, u, h = [].concat(D.chartData.yAxisData.ranges[t.index]), f = h.pop(), p = h.shift(), d = t.data;
                    switch (R.type) {
                      case "group":
                        var g = B(d, f, p, F, L, D, M, $), y = U(d, f, p, F, L, D, M, e, O, $);
                        j.push(y), g = N(g, L, O.length, e, M, D);
                        for (var v = 0; v < g.length; v++) {
                            var x, m, _ = g[v];
                            null !== _ && I < v && v < E && (C.beginPath(), C.setStrokeStyle(_.color || t.color), 
                            C.setLineWidth(1), C.setFillStyle(_.color || t.color), x = _.x - _.width / 2, m = D.height - _.y - D.area[2], 
                            C.moveTo(x, _.y), C.lineTo(x + _.width - 2, _.y), C.lineTo(x + _.width - 2, D.height - D.area[2]), 
                            C.lineTo(x, D.height - D.area[2]), C.lineTo(x, _.y), C.closePath(), C.stroke(), 
                            C.fill());
                        }
                        break;

                      case "stack":
                        g = U(d, f, p, F, L, D, M, e, O, $), j.push(g), s = g, l = L, O.length, c = M, u = D, 
                        g = s.map(function(t, e) {
                            return null === t ? null : (t.width = Math.ceil((l - 2 * c.columePadding) / 2), 
                            u.extra.column && u.extra.column.width && 0 < +u.extra.column.width && (t.width = Math.min(t.width, +u.extra.column.width)), 
                            t);
                        });
                        for (var b = 0; b < g.length; b++) {
                            var A, S = g[b];
                            null !== S && I < b && b < E && (C.beginPath(), C.setFillStyle(S.color || t.color), 
                            x = S.x - S.width / 2 + 1, m = D.height - S.y - D.area[2], A = D.height - S.y0 - D.area[2], 
                            0 < e && (m -= A), C.moveTo(x, S.y), C.fillRect(x, S.y, S.width - 2, m), C.closePath(), 
                            C.fill());
                        }
                        break;

                      case "meter":
                        if (g = B(d, f, p, F, L, D, M, $), j.push(g), s = g, n = L, O.length, r = e, i = M, 
                        o = D, a = R.meter.border, g = s.map(function(t) {
                            return null === t ? null : (t.width = Math.ceil((n - 2 * i.columePadding) / 2), 
                            o.extra.column && o.extra.column.width && 0 < +o.extra.column.width && (t.width = Math.min(t.width, +o.extra.column.width)), 
                            0 < r && (t.width -= 2 * a), t);
                        }), 0 == e) for (var w = 0; w < g.length; w++) {
                            var P = g[w];
                            null !== P && I < w && w < E && (C.beginPath(), C.setFillStyle(R.meter.fillColor), 
                            x = P.x - P.width / 2, m = D.height - P.y - D.area[2], C.moveTo(x, P.y), C.fillRect(x, P.y, P.width, m), 
                            C.closePath(), C.fill(), 0 < R.meter.border && (C.beginPath(), C.setStrokeStyle(t.color), 
                            C.setLineWidth(R.meter.border * D.pixelRatio), C.moveTo(x + .5 * R.meter.border, P.y + m), 
                            C.lineTo(x + .5 * R.meter.border, P.y + .5 * R.meter.border), C.lineTo(x + P.width - .5 * R.meter.border, P.y + .5 * R.meter.border), 
                            C.lineTo(x + P.width - .5 * R.meter.border, P.y + m), C.stroke()));
                        } else for (var T = 0; T < g.length; T++) {
                            var k = g[T];
                            null !== k && I < T && T < E && (C.beginPath(), C.setFillStyle(k.color || t.color), 
                            x = k.x - k.width / 2, m = D.height - k.y - D.area[2], C.moveTo(x, k.y), C.fillRect(x, k.y, k.width, m), 
                            C.closePath(), C.fill());
                        }
                    }
                }), !1 !== D.dataLabel && 1 === $ && O.forEach(function(t, e) {
                    var n = [].concat(D.chartData.yAxisData.ranges[t.index]), r = n.pop(), i = n.shift(), o = t.data;
                    switch (R.type) {
                      case "group":
                        var a = B(o, r, i, F, L, D, M, $);
                        V(a = N(a, L, O.length, e, M, D), t, M, C);
                        break;

                      case "stack":
                        V(a = U(o, r, i, F, L, D, M, e, O, $), t, M, C);
                        break;

                      case "meter":
                        V(a = B(o, r, i, F, L, D, M, $), t, M, C);
                    }
                }), C.restore(), {
                    xAxisPoints: F,
                    calPoints: j,
                    eachSpacing: L
                };
            }
            function J(t, e, h, f, p, n) {
                var d = 5 < arguments.length && void 0 !== n ? n : 1, l = z({}, {
                    color: {},
                    average: {}
                }, h.extra.candle);
                l.color = z({}, {
                    upLine: "#f04864",
                    upFill: "#f04864",
                    downLine: "#2fc25b",
                    downFill: "#2fc25b"
                }, l.color), l.average = z({}, {
                    show: !1,
                    name: [],
                    day: [],
                    color: f.colors
                }, l.average), h.extra.candle = l;
                var n = h.chartData.xAxisData, g = n.xAxisPoints, y = n.eachSpacing, c = [];
                p.save();
                var u = -2, v = g.length + 2, x = 0, m = h.width + y;
                return h._scrollDistance_ && 0 !== h._scrollDistance_ && !0 === h.enableScroll && (p.translate(h._scrollDistance_, 0), 
                u = Math.floor(-h._scrollDistance_ / y) - 2, v = u + h.xAxis.itemCount + 4, x = -h._scrollDistance_ - y + h.area[3], 
                m = x + (h.xAxis.itemCount + 4) * y), (l.average.show || e) && e.forEach(function(t, e) {
                    for (var n = [].concat(h.chartData.yAxisData.ranges[t.index]), r = n.pop(), n = n.shift(), i = L(B(t.data, r, n, g, y, h, f, d)), o = 0; o < i.length; o++) {
                        var a = i[o];
                        if (p.beginPath(), p.setStrokeStyle(t.color), p.setLineWidth(1), 1 === a.length) p.moveTo(a[0].x, a[0].y), 
                        p.arc(a[0].x, a[0].y, 1, 0, 2 * Math.PI); else {
                            p.moveTo(a[0].x, a[0].y);
                            for (var s = 0, l = 0; l < a.length; l++) {
                                var c, u = a[l];
                                0 == s && u.x > x && (p.moveTo(u.x, u.y), s = 1), 0 < l && u.x > x && u.x < m && (c = F(a, l - 1), 
                                p.bezierCurveTo(c.ctrA.x, c.ctrA.y, c.ctrB.x, c.ctrB.y, u.x, u.y));
                            }
                            p.moveTo(a[0].x, a[0].y);
                        }
                        p.closePath(), p.stroke();
                    }
                }), t.forEach(function(t, e) {
                    var n = [].concat(h.chartData.yAxisData.ranges[t.index]), r = n.pop(), n = n.shift(), i = t.data, n = function(t, o, a, s, l, c, e, n) {
                        var u = 7 < arguments.length && void 0 !== n ? n : 1, h = [], f = c.height - c.area[0] - c.area[2];
                        return t.forEach(function(t, r) {
                            var i;
                            null === t ? h.push(null) : (i = [], t.forEach(function(t, e) {
                                var n = {};
                                n.x = s[r] + Math.round(l / 2);
                                t = t.value || t, t = f * (t - o) / (a - o);
                                t *= u, n.y = c.height - Math.round(t) - c.area[2], i.push(n);
                            }), h.push(i));
                        }), h;
                    }(i, r, n, g, y, h, f, d);
                    c.push(n);
                    for (var o, a = L(n), s = 0; s < a[0].length; s++) u < s && s < v && (o = a[0][s], 
                    p.beginPath(), 0 < i[s][1] - i[s][0] ? (p.setStrokeStyle(l.color.upLine), p.setFillStyle(l.color.upFill), 
                    p.setLineWidth(+h.pixelRatio), p.moveTo(o[3].x, o[3].y), p.lineTo(o[1].x, o[1].y), 
                    p.lineTo(o[1].x - y / 4, o[1].y), p.lineTo(o[0].x - y / 4, o[0].y), p.lineTo(o[0].x, o[0].y), 
                    p.lineTo(o[2].x, o[2].y), p.lineTo(o[0].x, o[0].y), p.lineTo(o[0].x + y / 4, o[0].y), 
                    p.lineTo(o[1].x + y / 4, o[1].y), p.lineTo(o[1].x, o[1].y)) : (p.setStrokeStyle(l.color.downLine), 
                    p.setFillStyle(l.color.downFill), p.setLineWidth(+h.pixelRatio), p.moveTo(o[3].x, o[3].y), 
                    p.lineTo(o[0].x, o[0].y), p.lineTo(o[0].x - y / 4, o[0].y), p.lineTo(o[1].x - y / 4, o[1].y), 
                    p.lineTo(o[1].x, o[1].y), p.lineTo(o[2].x, o[2].y), p.lineTo(o[1].x, o[1].y), p.lineTo(o[1].x + y / 4, o[1].y), 
                    p.lineTo(o[0].x + y / 4, o[0].y), p.lineTo(o[0].x, o[0].y)), p.moveTo(o[3].x, o[3].y), 
                    p.closePath(), p.fill(), p.stroke());
                }), p.restore(), {
                    xAxisPoints: g,
                    calPoints: c,
                    eachSpacing: y
                };
            }
            function K(t, e, n, r) {
                (t.extra.tooltip || {}).horizentalLine && t.tooltip && 1 === r && ("line" == t.type || "area" == t.type || "column" == t.type || "candle" == t.type || "mix" == t.type) && i(t, e, n), 
                n.save(), t._scrollDistance_ && 0 !== t._scrollDistance_ && !0 === t.enableScroll && n.translate(t._scrollDistance_, 0), 
                t.tooltip && t.tooltip.textList && t.tooltip.textList.length && 1 === r && s(t.tooltip.textList, t.tooltip.offset, t, e, n), 
                n.restore();
            }
            function Y(t, s, l, c) {
                var e = s.chartData.xAxisData, u = e.xAxisPoints, n = e.startX, r = e.endX, h = e.eachSpacing, f = "center";
                "line" != s.type && "area" != s.type || (f = s.xAxis.boundaryGap);
                var i, o, a, p = s.height - s.area[2], d = s.area[0];
                if (s.enableScroll && s.xAxis.scrollShow && (g = s.height - s.area[2] + l.xAxisHeight, 
                a = (i = r - n) * i / (o = h * (u.length - 1)), e = 0, s._scrollDistance_ && (e = -s._scrollDistance_ * i / o), 
                c.beginPath(), c.setLineCap("round"), c.setLineWidth(6 * s.pixelRatio), c.setStrokeStyle(s.xAxis.scrollBackgroundColor || "#EFEBEF"), 
                c.moveTo(n, g), c.lineTo(r, g), c.stroke(), c.closePath(), c.beginPath(), c.setLineCap("round"), 
                c.setLineWidth(6 * s.pixelRatio), c.setStrokeStyle(s.xAxis.scrollColor || "#A6A6A6"), 
                c.moveTo(n + e, g), c.lineTo(n + e + a, g), c.stroke(), c.closePath(), c.setLineCap("butt")), 
                c.save(), s._scrollDistance_ && 0 !== s._scrollDistance_ && c.translate(s._scrollDistance_, 0), 
                !0 === s.xAxis.calibration && (c.setStrokeStyle(s.xAxis.gridColor || "#cccccc"), 
                c.setLineCap("butt"), c.setLineWidth(+s.pixelRatio), u.forEach(function(t, e) {
                    0 < e && (c.beginPath(), c.moveTo(t - h / 2, p), c.lineTo(t - h / 2, p + 3 * s.pixelRatio), 
                    c.closePath(), c.stroke());
                })), !0 !== s.xAxis.disableGrid && (c.setStrokeStyle(s.xAxis.gridColor || "#cccccc"), 
                c.setLineCap("butt"), c.setLineWidth(+s.pixelRatio), "dash" == s.xAxis.gridType && c.setLineDash([ s.xAxis.dashLength, s.xAxis.dashLength ]), 
                s.xAxis.gridEval = s.xAxis.gridEval || 1, u.forEach(function(t, e) {
                    e % s.xAxis.gridEval == 0 && (c.beginPath(), c.moveTo(t, p), c.lineTo(t, d), c.stroke());
                }), c.setLineDash([])), !0 !== s.xAxis.disabled) {
                    var g = t.length;
                    s.xAxis.labelCount && (g = s.xAxis.itemCount ? Math.ceil(t.length / s.xAxis.itemCount * s.xAxis.labelCount) : s.xAxis.labelCount, 
                    --g);
                    for (var y = Math.ceil(t.length / g), v = [], x = t.length, m = 0; m < x; m++) m % y != 0 ? v.push("") : v.push(t[m]);
                    v[x - 1] = t[x - 1];
                    var _ = s.xAxis.fontSize || l.fontSize;
                    0 === l._xAxisTextAngle_ ? v.forEach(function(t, e) {
                        var n = -$(String(t), _) / 2;
                        "center" == f && (n += h / 2);
                        var r = 0;
                        s.xAxis.scrollShow && (r = 6 * s.pixelRatio), c.beginPath(), c.setFontSize(_), c.setFillStyle(s.xAxis.fontColor || "#666666"), 
                        c.fillText(String(t), u[e] + n, p + _ + (l.xAxisHeight - r - _) / 2), c.closePath(), 
                        c.stroke();
                    }) : v.forEach(function(t, e) {
                        c.save(), c.beginPath(), c.setFontSize(_), c.setFillStyle(s.xAxis.fontColor || "#666666");
                        var n = -$(String(t), _);
                        "center" == f && (n += h / 2);
                        var r, i, o, a, r = (r = u[e] + h / 2, i = p + _ / 2 + 5, o = s.height, i = (a = r) + (o - (r = o - i) - a) / Math.sqrt(2), 
                        {
                            transX: i *= -1,
                            transY: (o - r) * (Math.sqrt(2) - 1) - (o - r - a) / Math.sqrt(2)
                        }), a = r.transX, r = r.transY;
                        c.rotate(-1 * l._xAxisTextAngle_), c.translate(a, r), c.fillText(String(t), u[e] + n, p + _ + 5), 
                        c.closePath(), c.stroke(), c.restore();
                    });
                }
                c.restore(), s.xAxis.axisLine && (c.beginPath(), c.setStrokeStyle(s.xAxis.axisLineColor), 
                c.setLineWidth(+s.pixelRatio), c.moveTo(n, s.height - s.area[2]), c.lineTo(r, s.height - s.area[2]), 
                c.stroke());
            }
            function Q(t, e, n, r) {
                if (!0 !== e.yAxis.disableGrid) {
                    for (var i = (e.height - e.area[0] - e.area[2]) / e.yAxis.splitNumber, o = e.area[3], a = e.chartData.xAxisData.xAxisPoints, a = e.chartData.xAxisData.eachSpacing * (a.length - 1), s = o + a, l = [], c = 0; c < e.yAxis.splitNumber + 1; c++) l.push(e.height - e.area[2] - i * c);
                    r.save(), e._scrollDistance_ && 0 !== e._scrollDistance_ && r.translate(e._scrollDistance_, 0), 
                    "dash" == e.yAxis.gridType && r.setLineDash([ e.yAxis.dashLength, e.yAxis.dashLength ]), 
                    r.setStrokeStyle(e.yAxis.gridColor), r.setLineWidth(+e.pixelRatio), l.forEach(function(t, e) {
                        r.beginPath(), r.moveTo(o, t), r.lineTo(s, t), r.stroke();
                    }), r.setLineDash([]), r.restore();
                }
            }
            function Z(t, o, a, s) {
                if (!0 !== o.yAxis.disabled) {
                    var e = (o.height - o.area[0] - o.area[2]) / o.yAxis.splitNumber, n = o.area[3], r = o.width - o.area[1], l = o.height - o.area[2], i = l + a.xAxisHeight;
                    o.xAxis.scrollShow && (i -= 3 * o.pixelRatio), o.xAxis.rotateLabel && (i = o.height - o.area[2] + 3), 
                    s.beginPath(), s.setFillStyle(o.background || "#ffffff"), o._scrollDistance_ < 0 && s.fillRect(0, 0, n, i), 
                    1 == o.enableScroll && s.fillRect(r, 0, o.width, i), s.closePath(), s.stroke();
                    for (var c = [], u = 0; u <= o.yAxis.splitNumber; u++) c.push(o.area[0] + e * u);
                    for (var h = o.area[3], f = o.width - o.area[1], p = 0; p < o.yAxis.data.length; p++) !function(t) {
                        var n, r, e, i = o.yAxis.data[t];
                        !0 !== i.disabled && (e = o.chartData.yAxisData.rangesFormat[t], n = i.fontSize || a.fontSize, 
                        r = o.chartData.yAxisData.yAxisWidth[t], e.forEach(function(t, e) {
                            e = c[e] || l;
                            s.beginPath(), s.setFontSize(n), s.setLineWidth(+o.pixelRatio), s.setStrokeStyle(i.axisLineColor || "#cccccc"), 
                            s.setFillStyle(i.fontColor || "#666666"), "left" == r.position ? (s.fillText(String(t), h - r.width, e + n / 2), 
                            1 == i.calibration && (s.moveTo(h, e), s.lineTo(h - 3 * o.pixelRatio, e))) : (s.fillText(String(t), f + 4 * o.pixelRatio, e + n / 2), 
                            1 == i.calibration && (s.moveTo(f, e), s.lineTo(f + 3 * o.pixelRatio, e))), s.closePath(), 
                            s.stroke();
                        }), !1 !== i.axisLine && (s.beginPath(), s.setStrokeStyle(i.axisLineColor || "#cccccc"), 
                        s.setLineWidth(+o.pixelRatio), "left" == r.position ? (s.moveTo(h, o.height - o.area[2]), 
                        s.lineTo(h, o.area[0])) : (s.moveTo(f, o.height - o.area[2]), s.lineTo(f, o.area[0])), 
                        s.stroke()), o.yAxis.showTitle && (t = i.titleFontSize || a.fontSize, e = i.title, 
                        s.beginPath(), s.setFontSize(t), s.setFillStyle(i.titleFontColor || "#666666"), 
                        "left" == r.position ? s.fillText(e, h - $(e, t) / 2, o.area[0] - 10 * o.pixelRatio) : s.fillText(e, f - $(e, t) / 2, o.area[0] - 10 * o.pixelRatio), 
                        s.closePath(), s.stroke()), "left" == r.position ? h -= r.width + o.yAxis.padding : f += r.width + o.yAxis.padding);
                    }(p);
                }
            }
            function tt(t, c, u, h, e) {
                var f, p, d, g, y, v, x, m;
                !1 !== c.legend.show && (e = (f = e.legendData).points, p = f.area, d = c.legend.padding, 
                g = c.legend.fontSize, y = 15 * c.pixelRatio, v = 5 * c.pixelRatio, x = c.legend.itemGap, 
                m = Math.max(c.legend.lineHeight * c.pixelRatio, g), h.beginPath(), h.setLineWidth(c.legend.borderWidth), 
                h.setStrokeStyle(c.legend.borderColor), h.setFillStyle(c.legend.backgroundColor), 
                h.moveTo(p.start.x, p.start.y), h.rect(p.start.x, p.start.y, p.width, p.height), 
                h.closePath(), h.fill(), h.stroke(), e.forEach(function(t, e) {
                    var n = 0, n = f.widthArr[e], r = f.heightArr[e], i = 0, o = 0, o = "top" == c.legend.position || "bottom" == c.legend.position ? (i = p.start.x + (p.width - n) / 2, 
                    p.start.y + d + e * m) : (n = 0 == e ? 0 : f.widthArr[e - 1], i = p.start.x + d + n, 
                    p.start.y + d + (p.height - r) / 2);
                    h.setFontSize(u.fontSize);
                    for (var a = 0; a < t.length; a++) {
                        var s = t[a];
                        switch (s.area = [ 0, 0, 0, 0 ], s.area[0] = i, s.area[1] = o, s.area[3] = o + m, 
                        h.beginPath(), h.setLineWidth(+c.pixelRatio), h.setStrokeStyle(s.show ? s.color : c.legend.hiddenColor), 
                        h.setFillStyle(s.show ? s.color : c.legend.hiddenColor), s.legendShape) {
                          case "line":
                            h.moveTo(i, o + .5 * m - 2 * c.pixelRatio), h.fillRect(i, o + .5 * m - 2 * c.pixelRatio, 15 * c.pixelRatio, 4 * c.pixelRatio);
                            break;

                          case "triangle":
                            h.moveTo(i + 7.5 * c.pixelRatio, o + .5 * m - 5 * c.pixelRatio), h.lineTo(i + 2.5 * c.pixelRatio, o + .5 * m + 5 * c.pixelRatio), 
                            h.lineTo(i + 12.5 * c.pixelRatio, o + .5 * m + 5 * c.pixelRatio), h.lineTo(i + 7.5 * c.pixelRatio, o + .5 * m - 5 * c.pixelRatio);
                            break;

                          case "diamond":
                            h.moveTo(i + 7.5 * c.pixelRatio, o + .5 * m - 5 * c.pixelRatio), h.lineTo(i + 2.5 * c.pixelRatio, o + .5 * m), 
                            h.lineTo(i + 7.5 * c.pixelRatio, o + .5 * m + 5 * c.pixelRatio), h.lineTo(i + 12.5 * c.pixelRatio, o + .5 * m), 
                            h.lineTo(i + 7.5 * c.pixelRatio, o + .5 * m - 5 * c.pixelRatio);
                            break;

                          case "circle":
                            h.moveTo(i + 7.5 * c.pixelRatio, o + .5 * m), h.arc(i + 7.5 * c.pixelRatio, o + .5 * m, 5 * c.pixelRatio, 0, 2 * Math.PI);
                            break;

                          case "rect":
                            h.moveTo(i, o + .5 * m - 5 * c.pixelRatio), h.fillRect(i, o + .5 * m - 5 * c.pixelRatio, 15 * c.pixelRatio, 10 * c.pixelRatio);
                            break;

                          default:
                            h.moveTo(i, o + .5 * m - 5 * c.pixelRatio), h.fillRect(i, o + .5 * m - 5 * c.pixelRatio, 15 * c.pixelRatio, 10 * c.pixelRatio);
                        }
                        h.closePath(), h.fill(), h.stroke(), i += y + v;
                        var l = .5 * m + .5 * g - 2;
                        h.beginPath(), h.setFontSize(g), h.setFillStyle(s.show ? c.legend.fontColor : c.legend.hiddenColor), 
                        h.fillText(s.name, i, o + l), h.closePath(), h.stroke(), "top" == c.legend.position || "bottom" == c.legend.position ? (i += $(s.name, g) + x, 
                        s.area[2] = i) : (s.area[2] = i + $(s.name, g) + x, i -= y + v, o += m);
                    }
                }));
            }
            function et(t, n, e, r, i) {
                var o = 4 < arguments.length && void 0 !== i ? i : 1, a = z({}, {
                    type: "area",
                    activeOpacity: .5,
                    activeRadius: 10 * n.pixelRatio,
                    offsetAngle: 0,
                    labelWidth: 15 * n.pixelRatio,
                    border: !1,
                    borderWidth: 2,
                    borderColor: "#FFFFFF"
                }, n.extra.rose);
                0 == e.pieChartLinePadding && (e.pieChartLinePadding = a.activeRadius);
                var s = {
                    x: n.area[3] + (n.width - n.area[1] - n.area[3]) / 2,
                    y: n.area[0] + (n.height - n.area[0] - n.area[2]) / 2
                }, l = Math.min((n.width - n.area[1] - n.area[3]) / 2 - e.pieChartLinePadding - e.pieChartTextPadding - e._pieTextMaxLength_, (n.height - n.area[0] - n.area[2]) / 2 - e.pieChartLinePadding - e.pieChartTextPadding), i = a.minRadius || .5 * l;
                t = function(t, e, n, r, i) {
                    for (var o = 4 < arguments.length && void 0 !== i ? i : 1, a = 0, s = 0, l = [], c = 0; c < t.length; c++) {
                        var u = t[c];
                        u.data = null === u.data ? 0 : u.data, a += u.data, l.push(u.data);
                    }
                    for (var h = Math.min.apply(null, l), f = Math.max.apply(null, l), p = r - n, d = 0; d < t.length; d++) {
                        var g = t[d];
                        g.data = null === g.data ? 0 : g.data, 0 === a || "area" == e ? (g._proportion_ = g.data / a * o, 
                        g._rose_proportion_ = 1 / t.length * o) : (g._proportion_ = g.data / a * o, g._rose_proportion_ = g.data / a * o), 
                        g._radius_ = n + p * ((g.data - h) / (f - h));
                    }
                    for (var y = 0; y < t.length; y++) {
                        var v = t[y];
                        v._start_ = s, s += 2 * v._rose_proportion_ * Math.PI;
                    }
                    return t;
                }(t, a.type, i, l, o);
                var c = a.activeRadius;
                if ((t = t.map(function(t) {
                    return t._start_ += (a.offsetAngle || 0) * Math.PI / 180, t;
                })).forEach(function(t, e) {
                    n.tooltip && n.tooltip.index == e && (r.beginPath(), r.setFillStyle(W(t.color, a.activeOpacity || .5)), 
                    r.moveTo(s.x, s.y), r.arc(s.x, s.y, c + t._radius_, t._start_, t._start_ + 2 * t._rose_proportion_ * Math.PI), 
                    r.closePath(), r.fill()), r.beginPath(), r.setLineWidth(a.borderWidth * n.pixelRatio), 
                    r.lineJoin = "round", r.setStrokeStyle(a.borderColor), r.setFillStyle(t.color), 
                    r.moveTo(s.x, s.y), r.arc(s.x, s.y, t._radius_, t._start_, t._start_ + 2 * t._rose_proportion_ * Math.PI), 
                    r.closePath(), r.fill(), 1 == a.border && r.stroke();
                }), !1 !== n.dataLabel && 1 === o) {
                    for (var u = !1, h = 0, f = t.length; h < f; h++) if (0 < t[h].data) {
                        u = !0;
                        break;
                    }
                    u && X(t, n, e, r, 0, s);
                }
                return {
                    center: s,
                    radius: l,
                    series: t
                };
            }
            function nt(t, e, n, r, i, o) {
                var a = 5 < arguments.length && void 0 !== o ? o : 1, s = z({}, {
                    type: "default",
                    startAngle: .75,
                    endAngle: .25,
                    width: 15,
                    splitLine: {
                        fixRadius: 0,
                        splitNumber: 10,
                        width: 15,
                        color: "#FFFFFF",
                        childNumber: 5,
                        childWidth: 5
                    },
                    pointer: {
                        width: 15,
                        color: "auto"
                    }
                }, n.extra.gauge);
                null == s.oldAngle && (s.oldAngle = s.startAngle), null == s.oldData && (s.oldData = 0), 
                t = function(t, e, n) {
                    for (var r = e - n + 1, i = e, o = 0; o < t.length; o++) t[o].value = null === t[o].value ? 0 : t[o].value, 
                    t[o]._startAngle_ = i, t[o]._endAngle_ = r * t[o].value + e, 2 <= t[o]._endAngle_ && (t[o]._endAngle_ = t[o]._endAngle_ % 2), 
                    i = t[o]._endAngle_;
                    return t;
                }(t, s.startAngle, s.endAngle);
                var l = {
                    x: n.width / 2,
                    y: n.height / 2
                }, c = Math.min(l.x, l.y);
                c -= 5 * n.pixelRatio;
                var u = (c -= s.width / 2) - s.width, h = 0;
                if ("progress" == s.type) {
                    var f = c - 3 * s.width;
                    i.beginPath();
                    o = i.createLinearGradient(l.x, l.y - f, l.x, l.y + f);
                    o.addColorStop("0", W(e[0].color, .3)), o.addColorStop("1.0", W("#FFFFFF", .1)), 
                    i.setFillStyle(o), i.arc(l.x, l.y, f, 0, 2 * Math.PI, !1), i.fill(), i.setLineWidth(s.width), 
                    i.setStrokeStyle(W(e[0].color, .3)), i.setLineCap("round"), i.beginPath(), i.arc(l.x, l.y, u, s.startAngle * Math.PI, s.endAngle * Math.PI, !1), 
                    i.stroke(), h = s.startAngle - s.endAngle + 1, s.splitLine.splitNumber;
                    var p = h / s.splitLine.splitNumber / s.splitLine.childNumber, d = -c - .5 * s.width - s.splitLine.fixRadius, g = -c - s.width - s.splitLine.fixRadius + s.splitLine.width;
                    i.save(), i.translate(l.x, l.y), i.rotate((s.startAngle - 1) * Math.PI);
                    for (var y = s.splitLine.splitNumber * s.splitLine.childNumber + 1, v = e[0].data * a, x = 0; x < y; x++) i.beginPath(), 
                    x / y < v ? i.setStrokeStyle(W(e[0].color, 1)) : i.setStrokeStyle(W(e[0].color, .3)), 
                    i.setLineWidth(3 * n.pixelRatio), i.moveTo(d, 0), i.lineTo(g, 0), i.stroke(), i.rotate(p * Math.PI);
                    i.restore(), e = C(e, s, a), i.setLineWidth(s.width), i.setStrokeStyle(e[0].color), 
                    i.setLineCap("round"), i.beginPath(), i.arc(l.x, l.y, u, s.startAngle * Math.PI, e[0]._proportion_ * Math.PI, !1), 
                    i.stroke();
                    o = c - 2.5 * s.width;
                    i.save(), i.translate(l.x, l.y), i.rotate((e[0]._proportion_ - 1) * Math.PI), i.beginPath(), 
                    i.setLineWidth(s.width / 3);
                    f = i.createLinearGradient(0, .6 * -o, 0, .6 * o);
                    f.addColorStop("0", W("#FFFFFF", 0)), f.addColorStop("0.5", W(e[0].color, 1)), f.addColorStop("1.0", W("#FFFFFF", 0)), 
                    i.setStrokeStyle(f), i.arc(0, 0, o, .85 * Math.PI, 1.15 * Math.PI, !1), i.stroke(), 
                    i.beginPath(), i.setLineWidth(1), i.setStrokeStyle(e[0].color), i.setFillStyle(e[0].color), 
                    i.moveTo(-o - s.width / 3 / 2, -4), i.lineTo(-o - s.width / 3 / 2 - 4, 0), i.lineTo(-o - s.width / 3 / 2, 4), 
                    i.lineTo(-o - s.width / 3 / 2, -4), i.stroke(), i.fill(), i.restore();
                } else {
                    i.setLineWidth(s.width), i.setLineCap("butt");
                    for (var m = 0; m < t.length; m++) {
                        var _ = t[m];
                        i.beginPath(), i.setStrokeStyle(_.color), i.arc(l.x, l.y, c, _._startAngle_ * Math.PI, _._endAngle_ * Math.PI, !1), 
                        i.stroke();
                    }
                    i.save();
                    var b = (h = s.startAngle - s.endAngle + 1) / s.splitLine.splitNumber, A = h / s.splitLine.splitNumber / s.splitLine.childNumber, S = -c - .5 * s.width - s.splitLine.fixRadius, w = -c - .5 * s.width - s.splitLine.fixRadius + s.splitLine.width, P = -c - .5 * s.width - s.splitLine.fixRadius + s.splitLine.childWidth;
                    i.translate(l.x, l.y), i.rotate((s.startAngle - 1) * Math.PI);
                    for (var T = 0; T < s.splitLine.splitNumber + 1; T++) i.beginPath(), i.setStrokeStyle(s.splitLine.color), 
                    i.setLineWidth(2 * n.pixelRatio), i.moveTo(S, 0), i.lineTo(w, 0), i.stroke(), i.rotate(b * Math.PI);
                    i.restore(), i.save(), i.translate(l.x, l.y), i.rotate((s.startAngle - 1) * Math.PI);
                    for (var k = 0; k < s.splitLine.splitNumber * s.splitLine.childNumber + 1; k++) i.beginPath(), 
                    i.setStrokeStyle(s.splitLine.color), i.setLineWidth(+n.pixelRatio), i.moveTo(S, 0), 
                    i.lineTo(P, 0), i.stroke(), i.rotate(A * Math.PI);
                    i.restore(), e = function(t, e, n, r) {
                        for (var i = 3 < arguments.length && void 0 !== r ? r : 1, o = 0; o < t.length; o++) {
                            var a = t[o];
                            if (a.data = null === a.data ? 0 : a.data, "auto" == n.pointer.color) {
                                for (var s = 0; s < e.length; s++) if (a.data <= e[s].value) {
                                    a.color = e[s].color;
                                    break;
                                }
                            } else a.color = n.pointer.color;
                            var l = n.startAngle - n.endAngle + 1;
                            a._endAngle_ = l * a.data + n.startAngle, a._oldAngle_ = n.oldAngle, n.oldAngle < n.endAngle && (a._oldAngle_ += 2), 
                            a.data >= n.oldData ? a._proportion_ = (a._endAngle_ - a._oldAngle_) * i + n.oldAngle : a._proportion_ = a._oldAngle_ - (a._oldAngle_ - a._endAngle_) * i, 
                            2 <= a._proportion_ && (a._proportion_ = a._proportion_ % 2);
                        }
                        return t;
                    }(e, t, s, a);
                    for (var O = 0; O < e.length; O++) {
                        var D = e[O];
                        i.save(), i.translate(l.x, l.y), i.rotate((D._proportion_ - 1) * Math.PI), i.beginPath(), 
                        i.setFillStyle(D.color), i.moveTo(s.pointer.width, 0), i.lineTo(0, -s.pointer.width / 2), 
                        i.lineTo(-u, 0), i.lineTo(0, s.pointer.width / 2), i.lineTo(s.pointer.width, 0), 
                        i.closePath(), i.fill(), i.beginPath(), i.setFillStyle("#FFFFFF"), i.arc(0, 0, s.pointer.width / 6, 0, 2 * Math.PI, !1), 
                        i.fill(), i.restore();
                    }
                    !1 !== n.dataLabel && function(t, e, n, r, i) {
                        e -= t.width / 2 + r.gaugeLabelTextMargin;
                        for (var o = (t.startAngle - t.endAngle + 1) / t.splitLine.splitNumber, a = (t.endNumber - t.startNumber) / t.splitLine.splitNumber, s = t.startAngle, l = t.startNumber, c = 0; c < t.splitLine.splitNumber + 1; c++) {
                            var u = {
                                x: e * Math.cos(s * Math.PI),
                                y: e * Math.sin(s * Math.PI)
                            }, h = t.labelFormat ? t.labelFormat(l) : l;
                            u.x += n.x - $(h) / 2, u.y += n.y;
                            var f = u.x, u = u.y;
                            i.beginPath(), i.setFontSize(r.fontSize), i.setFillStyle(t.labelColor || "#666666"), 
                            i.fillText(h, f, u + r.fontSize / 2), i.closePath(), i.stroke(), 2 <= (s += o) && (s %= 2), 
                            l += a;
                        }
                    }(s, c, l, r, i);
                }
                return H(n, r, i, l), 1 === a && "gauge" === n.type && (n.extra.gauge.oldAngle = e[0]._proportion_, 
                n.extra.gauge.oldData = e[0].data), {
                    center: l,
                    radius: c,
                    innerRadius: u,
                    categories: t,
                    totalAngle: h
                };
            }
            function rt(t, i, e, o, n) {
                var r = 4 < arguments.length && void 0 !== n ? n : 1, a = z({}, {
                    gridColor: "#cccccc",
                    labelColor: "#666666",
                    opacity: .2,
                    gridCount: 3
                }, i.extra.radar), s = function(t) {
                    for (var e = 2 * Math.PI / t, n = [], r = 0; r < t; r++) n.push(e * r);
                    return n.map(function(t) {
                        return -1 * t + Math.PI / 2;
                    });
                }(i.categories.length), l = {
                    x: i.area[3] + (i.width - i.area[1] - i.area[3]) / 2,
                    y: i.area[0] + (i.height - i.area[0] - i.area[2]) / 2
                }, c = Math.min(l.x - (n = (n = i.categories).map(function(t) {
                    return $(t);
                }), Math.max.apply(null, n) + e.radarLabelTextMargin), l.y - e.radarLabelTextMargin);
                c -= i.padding[1], o.beginPath(), o.setLineWidth(+i.pixelRatio), o.setStrokeStyle(a.gridColor), 
                s.forEach(function(t) {
                    t = O(c * Math.cos(t), c * Math.sin(t), l);
                    o.moveTo(l.x, l.y), o.lineTo(t.x, t.y);
                }), o.stroke(), o.closePath();
                for (var u, h, f, p, d, g, y = 1; y <= a.gridCount; y++) !function(n) {
                    var r = {};
                    o.beginPath(), o.setLineWidth(+i.pixelRatio), o.setStrokeStyle(a.gridColor), s.forEach(function(t, e) {
                        t = O(c / a.gridCount * n * Math.cos(t), c / a.gridCount * n * Math.sin(t), l);
                        0 === e ? (r = t, o.moveTo(t.x, t.y)) : o.lineTo(t.x, t.y);
                    }), o.lineTo(r.x, r.y), o.stroke(), o.closePath();
                }(y);
                return v(s, l, c, t, i, r).forEach(function(t, e) {
                    o.beginPath(), o.setFillStyle(W(t.color, a.opacity)), t.data.forEach(function(t, e) {
                        0 === e ? o.moveTo(t.position.x, t.position.y) : o.lineTo(t.position.x, t.position.y);
                    }), o.closePath(), o.fill(), !1 !== i.dataPointShape && E(t.data.map(function(t) {
                        return t.position;
                    }), t.color, t.pointShape, o, i);
                }), r = s, u = c, h = l, p = e, d = o, g = (f = i).extra.radar || {}, u += p.radarLabelTextMargin, 
                r.forEach(function(t, e) {
                    var n = {
                        x: u * Math.cos(t),
                        y: u * Math.sin(t)
                    }, r = O(n.x, n.y, h), t = r.x, r = r.y;
                    k.approximatelyEqual(n.x, 0) ? t -= $(f.categories[e] || "") / 2 : n.x < 0 && (t -= $(f.categories[e] || "")), 
                    d.beginPath(), d.setFontSize(p.fontSize), d.setFillStyle(g.labelColor || "#666666"), 
                    d.fillText(f.categories[e] || "", t, r + p.fontSize / 2), d.closePath(), d.stroke();
                }), {
                    center: l,
                    radius: c,
                    angleList: s
                };
            }
            function b(t, e, n) {
                n = 0 == n ? 1 : n;
                for (var r = [], i = 0; i < n; i++) r[i] = Math.random();
                return Math.floor(r.reduce(function(t, e) {
                    return t + e;
                }) / n * (e - t)) + t;
            }
            function A(t, e, n, r) {
                for (var i = !1, o = 0; o < e.length; o++) if (e[o].area) {
                    if (!(t[3] < e[o].area[1] || t[0] > e[o].area[2] || t[1] > e[o].area[3] || t[2] < e[o].area[0])) {
                        i = !0;
                        break;
                    }
                    if (t[0] < 0 || t[1] < 0 || t[2] > n || t[3] > r) {
                        i = !0;
                        break;
                    }
                    i = !1;
                }
                return i;
            }
            function _(t, e, n, r, i, o) {
                return {
                    x: (e - n.xMin) * r + i,
                    y: (n.yMax - t) * r + o
                };
            }
            function it(t, e, n, r) {
                var i, o, a = z({}, {
                    border: !0,
                    borderWidth: 1,
                    borderColor: "#666666",
                    fillOpacity: .6,
                    activeBorderColor: "#f04864",
                    activeFillColor: "#facc14",
                    activeFillOpacity: 1
                }, e.extra.map), s = t, l = function(t) {
                    for (var e, n = {
                        xMin: 180,
                        xMax: 0,
                        yMin: 90,
                        yMax: 0
                    }, r = 0; r < t.length; r++) for (var i = t[r].geometry.coordinates, o = 0; o < i.length; o++) {
                        1 == (e = i[o]).length && (e = e[0]);
                        for (var a = 0; a < e.length; a++) {
                            var s = {
                                x: e[a][0],
                                y: e[a][1]
                            };
                            n.xMin = n.xMin < s.x ? n.xMin : s.x, n.xMax = n.xMax > s.x ? n.xMax : s.x, n.yMin = n.yMin < s.y ? n.yMin : s.y, 
                            n.yMax = n.yMax > s.y ? n.yMax : s.y;
                        }
                    }
                    return n;
                }(s), c = e.width / Math.abs(l.xMax - l.xMin), u = e.height / Math.abs(l.yMax - l.yMin), h = c < u ? c : u, f = e.width / 2 - Math.abs(l.xMax - l.xMin) / 2 * h, p = e.height / 2 - Math.abs(l.yMax - l.yMin) / 2 * h;
                r.beginPath(), r.clearRect(0, 0, e.width, e.height), r.setFillStyle(e.background || "#FFFFFF"), 
                r.rect(0, 0, e.width, e.height), r.fill();
                for (var d = 0; d < s.length; d++) {
                    r.beginPath(), r.setLineWidth(a.borderWidth * e.pixelRatio), r.setStrokeStyle(a.borderColor), 
                    r.setFillStyle(W(t[d].color, a.fillOpacity)), e.tooltip && e.tooltip.index == d && (r.setStrokeStyle(a.activeBorderColor), 
                    r.setFillStyle(W(a.activeFillColor, a.activeFillOpacity)));
                    for (var g, y, v = s[d].geometry.coordinates, x = 0; x < v.length; x++) {
                        1 == (i = v[x]).length && (i = i[0]);
                        for (var m = 0; m < i.length; m++) o = _(i[m][1], i[m][0], l, h, f, p), 0 === m ? (r.beginPath(), 
                        r.moveTo(o.x, o.y)) : r.lineTo(o.x, o.y);
                        r.fill(), 1 == a.border && r.stroke();
                    }
                    1 != e.dataLabel || (y = s[d].properties.centroid) && (o = _(y[1], y[0], l, h, f, p), 
                    g = s[d].textSize || n.fontSize, y = s[d].properties.name, r.beginPath(), r.setFontSize(g), 
                    r.setFillStyle(s[d].textColor || "#666666"), r.fillText(y, o.x - $(y, g) / 2, o.y + g / 2), 
                    r.closePath(), r.stroke());
                }
                e.chartData.mapData = {
                    bounds: l,
                    scale: h,
                    xoffset: f,
                    yoffset: p
                }, K(e, n, r, 1), r.draw();
            }
            function ot(t, e) {
                var n = t.series.sort(function(t, e) {
                    return parseInt(e.textSize) - parseInt(t.textSize);
                });
                switch (e) {
                  case "normal":
                    for (var r = 0; r < n.length; r++) {
                        for (var i, o, a = n[r].name, s = n[r].textSize, l = $(a, s), c = void 0, u = 0; ;) {
                            if (u++, i = b(-t.width / 2, t.width / 2, 5) - l / 2, o = b(-t.height / 2, t.height / 2, 5) + s / 2, 
                            !A(c = [ i - 5 + t.width / 2, o - 5 - s + t.height / 2, i + l + 5 + t.width / 2, o + 5 + t.height / 2 ], n, t.width, t.height)) break;
                            if (1e3 == u) {
                                c = [ -100, -100, -100, -100 ];
                                break;
                            }
                        }
                        n[r].area = c;
                    }
                    break;

                  case "vertical":
                    for (var h = 0; h < n.length; h++) {
                        for (var f = n[h].name, p = n[h].textSize, d = $(f, p), g = .7 < Math.random(), y = void 0, v = void 0, x = void 0, m = void 0, _ = 0; ;) {
                            _++;
                            if (!(g ? (y = b(-t.width / 2, t.width / 2, 5) - d / 2, x = [ (v = b(-t.height / 2, t.height / 2, 5) + p / 2) - 5 - d + t.width / 2, -y - 5 + t.height / 2, v + 5 + t.width / 2, -y + p + 5 + t.height / 2 ], 
                            A(m = [ t.width - (t.width / 2 - t.height / 2) - (-y + p + 5 + t.height / 2) - 5, t.height / 2 - t.width / 2 + (v - 5 - d + t.width / 2) - 5, t.width - (t.width / 2 - t.height / 2) - (-y + p + 5 + t.height / 2) + p, t.height / 2 - t.width / 2 + (v - 5 - d + t.width / 2) + d + 5 ], n, t.height, t.width)) : (y = b(-t.width / 2, t.width / 2, 5) - d / 2, 
                            v = b(-t.height / 2, t.height / 2, 5) + p / 2, A(x = [ y - 5 + t.width / 2, v - 5 - p + t.height / 2, y + d + 5 + t.width / 2, v + 5 + t.height / 2 ], n, t.width, t.height)))) break;
                            if (1e3 == _) {
                                x = [ -1e3, -1e3, -1e3, -1e3 ];
                                break;
                            }
                        }
                        g ? (n[h].area = m, n[h].areav = x) : n[h].area = x, n[h].rotate = g;
                    }
                }
                return n;
            }
            function at(t, e, n, r, i) {
                var o = 4 < arguments.length && void 0 !== i ? i : 1, a = z({}, {
                    activeWidth: 10,
                    activeOpacity: .3,
                    border: !1,
                    borderWidth: 2,
                    borderColor: "#FFFFFF",
                    fillOpacity: 1,
                    labelAlign: "right"
                }, e.extra.funnel), s = (e.height - e.area[0] - e.area[2]) / t.length, l = {
                    x: e.area[3] + (e.width - e.area[1] - e.area[3]) / 2,
                    y: e.height - e.area[2]
                }, c = a.activeWidth, i = Math.min((e.width - e.area[1] - e.area[3]) / 2 - c, (e.height - e.area[0] - e.area[2]) / 2 - c);
                t = function(t, e, n) {
                    var r = 2 < arguments.length && void 0 !== n ? n : 1;
                    t = t.sort(function(t, e) {
                        return parseInt(e.data) - parseInt(t.data);
                    });
                    for (var i = 0; i < t.length; i++) t[i].radius = t[i].data / t[0].data * e * r, 
                    t[i]._proportion_ = t[i].data / t[0].data;
                    return t.reverse();
                }(t, i, o), r.save(), r.translate(l.x, l.y);
                for (var u = 0; u < t.length; u++) 0 == u ? (e.tooltip && e.tooltip.index == u && (r.beginPath(), 
                r.setFillStyle(W(t[u].color, a.activeOpacity)), r.moveTo(-c, 0), r.lineTo(-t[u].radius - c, -s), 
                r.lineTo(t[u].radius + c, -s), r.lineTo(c, 0), r.lineTo(-c, 0), r.closePath(), r.fill()), 
                t[u].funnelArea = [ l.x - t[u].radius, l.y - s, l.x + t[u].radius, l.y ], r.beginPath(), 
                r.setLineWidth(a.borderWidth * e.pixelRatio), r.setStrokeStyle(a.borderColor), r.setFillStyle(W(t[u].color, a.fillOpacity)), 
                r.moveTo(0, 0), r.lineTo(-t[u].radius, -s), r.lineTo(t[u].radius, -s)) : (e.tooltip && e.tooltip.index == u && (r.beginPath(), 
                r.setFillStyle(W(t[u].color, a.activeOpacity)), r.moveTo(0, 0), r.lineTo(-t[u - 1].radius - c, 0), 
                r.lineTo(-t[u].radius - c, -s), r.lineTo(t[u].radius + c, -s), r.lineTo(t[u - 1].radius + c, 0), 
                r.lineTo(0, 0), r.closePath(), r.fill()), t[u].funnelArea = [ l.x - t[u].radius, l.y - s * (u + 1), l.x + t[u].radius, l.y - s * u ], 
                r.beginPath(), r.setLineWidth(a.borderWidth * e.pixelRatio), r.setStrokeStyle(a.borderColor), 
                r.setFillStyle(W(t[u].color, a.fillOpacity)), r.moveTo(0, 0), r.lineTo(-t[u - 1].radius, 0), 
                r.lineTo(-t[u].radius, -s), r.lineTo(t[u].radius, -s), r.lineTo(t[u - 1].radius, 0)), 
                r.lineTo(0, 0), r.closePath(), r.fill(), 1 == a.border && r.stroke(), r.translate(0, -s);
                return r.restore(), !1 !== e.dataLabel && 1 === o && function(t, e, n, r, i, o, a) {
                    for (var s = 0; s < t.length; s++) {
                        var l = t[s], c = void 0, u = void 0, h = void 0, f = void 0, p = l.format ? l.format(+l._proportion_.toFixed(2)) : k.toFixed(100 * l._proportion_) + "%";
                        "right" == i ? (c = 0 == s ? (l.funnelArea[2] + a.x) / 2 : (l.funnelArea[2] + t[s - 1].funnelArea[2]) / 2, 
                        u = c + 2 * o, h = l.funnelArea[1] + r / 2, f = l.textSize || e.fontSize, n.setLineWidth(+e.pixelRatio), 
                        n.setStrokeStyle(l.color), n.setFillStyle(l.color), n.beginPath(), n.moveTo(c, h), 
                        n.lineTo(u, h), n.stroke(), n.closePath(), n.beginPath(), n.moveTo(u, h), n.arc(u, h, 2, 0, 2 * Math.PI), 
                        n.closePath(), n.fill(), n.beginPath(), n.setFontSize(f), n.setFillStyle(l.textColor || "#666666"), 
                        n.fillText(p, u + 5, h + f / 2 - 2)) : (c = 0 == s ? (l.funnelArea[0] + a.x) / 2 : (l.funnelArea[0] + t[s - 1].funnelArea[0]) / 2, 
                        u = c - 2 * o, h = l.funnelArea[1] + r / 2, f = l.textSize || e.fontSize, n.setLineWidth(+e.pixelRatio), 
                        n.setStrokeStyle(l.color), n.setFillStyle(l.color), n.beginPath(), n.moveTo(c, h), 
                        n.lineTo(u, h), n.stroke(), n.closePath(), n.beginPath(), n.moveTo(u, h), n.arc(u, h, 2, 0, 2 * Math.PI), 
                        n.closePath(), n.fill(), n.beginPath(), n.setFontSize(f), n.setFillStyle(l.textColor || "#666666"), 
                        n.fillText(p, u - 5 - $(p), h + f / 2 - 2)), n.closePath(), n.stroke(), n.closePath();
                    }
                }(t, e, r, s, a.labelAlign, c, l), {
                    center: l,
                    radius: i,
                    series: t
                };
            }
            function st(t, e) {
                e.draw();
            }
            var y = {
                easeIn: function(t) {
                    return Math.pow(t, 3);
                },
                easeOut: function(t) {
                    return Math.pow(t - 1, 3) + 1;
                },
                easeInOut: function(t) {
                    return (t /= .5) < 1 ? .5 * Math.pow(t, 3) : .5 * (Math.pow(t - 2, 3) + 2);
                },
                linear: function(t) {
                    return t;
                }
            };
            function lt(e) {
                this.isStop = !1, e.duration = void 0 === e.duration ? 1e3 : e.duration, e.timing = e.timing || "linear";
                var n = "undefined" != typeof setTimeout ? function(e, t) {
                    setTimeout(function() {
                        var t = +new Date();
                        e(t);
                    }, t);
                } : "undefined" != typeof requestAnimationFrame ? requestAnimationFrame : function(t) {
                    t(null);
                }, r = null, i = (i = function(t) {
                    if (null === t || !0 === this.isStop) return e.onProcess && e.onProcess(1), void (e.onAnimationFinish && e.onAnimationFinish());
                    null === r && (r = t), t - r < e.duration ? (t = (t - r) / e.duration, t = (0, y[e.timing])(t), 
                    e.onProcess && e.onProcess(t), n(i, 17)) : (e.onProcess && e.onProcess(1), e.onAnimationFinish && e.onAnimationFinish());
                }).bind(this);
                n(i, 17);
            }
            function x(t, i, o, a) {
                var e = this, s = i.series, l = i.categories, s = P(s, i, o), n = i.animation ? i.duration : 0;
                e.animationInstance && e.animationInstance.stop();
                var c = null;
                "candle" == t ? (p = z({}, i.extra.candle.average)).show ? (c = P(c = function(t, e, n, r) {
                    for (var i = [], o = 0; o < t.length; o++) {
                        for (var a = {
                            data: [],
                            name: e[o],
                            color: n[o]
                        }, s = 0, l = r.length; s < l; s++) if (s < t[o]) a.data.push(null); else {
                            for (var c = 0, u = 0; u < t[o]; u++) c += r[s - u][1];
                            a.data.push(+(c / t[o]).toFixed(3));
                        }
                        i.push(a);
                    }
                    return i;
                }(p.day, p.name, p.color, s[0].data), i, o), i.seriesMA = c) : c = i.seriesMA ? i.seriesMA = P(i.seriesMA, i, o) : s : c = s, 
                i._series_ = s = function(t) {
                    for (var e = [], n = 0; n < t.length; n++) 1 == t[n].show && e.push(t[n]);
                    return e;
                }(s), i.area = new Array(4);
                for (var r = 0; r < 4; r++) i.area[r] = i.padding[r];
                var u = function(t, e, n) {
                    var r = {
                        area: {
                            start: {
                                x: 0,
                                y: 0
                            },
                            end: {
                                x: 0,
                                y: 0
                            },
                            width: 0,
                            height: 0,
                            wholeWidth: 0,
                            wholeHeight: 0
                        },
                        points: [],
                        widthArr: [],
                        heightArr: []
                    };
                    if (!1 === e.legend.show) return n.legendData = r;
                    var i = e.legend.padding, o = e.legend.margin, a = e.legend.fontSize, s = 15 * e.pixelRatio, l = 5 * e.pixelRatio, c = Math.max(e.legend.lineHeight * e.pixelRatio, a);
                    if ("top" == e.legend.position || "bottom" == e.legend.position) {
                        for (var u = [], h = 0, f = [], p = [], d = 0; d < t.length; d++) {
                            var g = t[d], y = s + l + $(g.name || "undefined", a) + e.legend.itemGap;
                            h + y > e.width - e.padding[1] - e.padding[3] ? (u.push(p), f.push(h - e.legend.itemGap), 
                            h = y, p = [ g ]) : (h += y, p.push(g));
                        }
                        if (p.length) {
                            u.push(p), f.push(h - e.legend.itemGap), r.widthArr = f;
                            var v = Math.max.apply(null, f);
                            switch (e.legend.float) {
                              case "left":
                                r.area.start.x = e.padding[3], r.area.end.x = e.padding[3] + 2 * i;
                                break;

                              case "right":
                                r.area.start.x = e.width - e.padding[1] - v - 2 * i, r.area.end.x = e.width - e.padding[1];
                                break;

                              default:
                                r.area.start.x = (e.width - v) / 2 - i, r.area.end.x = (e.width + v) / 2 + i;
                            }
                            r.area.width = v + 2 * i, r.area.wholeWidth = v + 2 * i, r.area.height = u.length * c + 2 * i, 
                            r.area.wholeHeight = u.length * c + 2 * i + 2 * o, r.points = u;
                        }
                    } else {
                        var x = t.length, m = e.height - e.padding[0] - e.padding[2] - 2 * o - 2 * i, _ = Math.min(Math.floor(m / c), x);
                        switch (r.area.height = _ * c + 2 * i, r.area.wholeHeight = _ * c + 2 * i, e.legend.float) {
                          case "top":
                            r.area.start.y = e.padding[0] + o, r.area.end.y = e.padding[0] + o + r.area.height;
                            break;

                          case "bottom":
                            r.area.start.y = e.height - e.padding[2] - o - r.area.height, r.area.end.y = e.height - e.padding[2] - o;
                            break;

                          default:
                            r.area.start.y = (e.height - r.area.height) / 2, r.area.end.y = (e.height + r.area.height) / 2;
                        }
                        for (var b = x % _ == 0 ? x / _ : Math.floor(x / _ + 1), A = [], S = 0; S < b; S++) {
                            var w = t.slice(S * _, S * _ + _);
                            A.push(w);
                        }
                        if ((r.points = A).length) {
                            for (var P = 0; P < A.length; P++) {
                                for (var T = A[P], k = 0, O = 0; O < T.length; O++) {
                                    var D = s + l + $(T[O].name || "undefined", a) + e.legend.itemGap;
                                    k < D && (k = D);
                                }
                                r.widthArr.push(k), r.heightArr.push(T.length * c + 2 * i);
                            }
                            for (var M = 0, C = 0; C < r.widthArr.length; C++) M += r.widthArr[C];
                            r.area.width = M - e.legend.itemGap + 2 * i, r.area.wholeWidth = r.area.width + i;
                        }
                    }
                    switch (e.legend.position) {
                      case "top":
                        r.area.start.y = e.padding[0] + o, r.area.end.y = e.padding[0] + o + r.area.height;
                        break;

                      case "bottom":
                        r.area.start.y = e.height - e.padding[2] - r.area.height - o, r.area.end.y = e.height - e.padding[2] - o;
                        break;

                      case "left":
                        r.area.start.x = e.padding[3], r.area.end.x = e.padding[3] + r.area.width;
                        break;

                      case "right":
                        r.area.start.x = e.width - e.padding[1] - r.area.width, r.area.end.x = e.width - e.padding[1];
                    }
                    return n.legendData = r;
                }(c, i, i.chartData), h = u.area.wholeHeight, f = u.area.wholeWidth;
                switch (i.legend.position) {
                  case "top":
                    i.area[0] += h;
                    break;

                  case "bottom":
                    i.area[2] += h;
                    break;

                  case "left":
                    i.area[3] += f;
                    break;

                  case "right":
                    i.area[1] += f;
                }
                var p, d, g, y, v = {}, x = 0;
                if ("line" === i.type || "column" === i.type || "area" === i.type || "mix" === i.type || "candle" === i.type) {
                    if (x = (v = j(s, i, o)).yAxisWidth, i.yAxis.showTitle) {
                        for (var m = 0, _ = 0; _ < i.yAxis.data.length; _++) m = Math.max(m, i.yAxis.data[_].titleFontSize || o.fontSize);
                        i.area[0] += (m + 6) * i.pixelRatio;
                    }
                    for (var b = 0, A = 0, S = 0; S < x.length; S++) "left" == x[S].position ? (i.area[3] += 0 < A ? x[S].width + i.yAxis.padding : x[S].width, 
                    A += 1) : (i.area[1] += 0 < b ? x[S].width + i.yAxis.padding : x[S].width, b += 1);
                } else o.yAxisWidth = x;
                switch (i.chartData.yAxisData = v, i.categories && i.categories.length ? (i.chartData.xAxisData = R(i.categories, i), 
                u = (p = T(i.categories, i, o, i.chartData.xAxisData.eachSpacing)).xAxisHeight, 
                v = p.angle, o.xAxisHeight = u, o._xAxisTextAngle_ = v, i.area[2] += u, i.chartData.categoriesData = p) : "line" === i.type || "area" === i.type || "points" === i.type ? (i.chartData.xAxisData = D(s, i, o), 
                d = (g = T(l = i.chartData.xAxisData.rangesFormat, i, o, i.chartData.xAxisData.eachSpacing)).xAxisHeight, 
                y = g.angle, o.xAxisHeight = d, o._xAxisTextAngle_ = y, i.area[2] += d, i.chartData.categoriesData = g) : i.chartData.xAxisData = {
                    xAxisPoints: []
                }, i.enableScroll && "right" == i.xAxis.scrollAlign && void 0 === i._scrollDistance_ && (y = 0, 
                d = i.chartData.xAxisData.xAxisPoints, g = i.chartData.xAxisData.startX, y = i.chartData.xAxisData.endX - g - i.chartData.xAxisData.eachSpacing * (d.length - 1), 
                e.scrollOption = {
                    currentOffset: y,
                    startTouchX: y,
                    distance: 0,
                    lastMoveTime: 0
                }, i._scrollDistance_ = y), "pie" !== t && "ring" !== t && "rose" !== t || (o._pieTextMaxLength_ = !1 === i.dataLabel ? 0 : function(t) {
                    t = M(t);
                    for (var e = 0, n = 0; n < t.length; n++) var r = (r = t[n]).format ? r.format(+r._proportion_.toFixed(2)) : k.toFixed(100 * r._proportion_) + "%", e = Math.max(e, $(r));
                    return e;
                }(c)), t) {
                  case "word":
                    var w = z({}, {
                        type: "normal",
                        autoColors: !0
                    }, i.extra.word);
                    1 != i.updateData && null != i.updateData || (i.chartData.wordCloudData = ot(i, w.type)), 
                    this.animationInstance = new lt({
                        timing: "easeInOut",
                        duration: n,
                        onProcess: function(t) {
                            a.clearRect(0, 0, i.width, i.height), i.rotate && I(a, i), function(t, e, n, r, i) {
                                var o = 4 < arguments.length && void 0 !== i ? i : 1;
                                z({}, {
                                    type: "normal",
                                    autoColors: !0
                                }, e.extra.word), r.beginPath(), r.setFillStyle(e.background || "#FFFFFF"), r.rect(0, 0, e.width, e.height), 
                                r.fill(), r.save();
                                var a = e.chartData.wordCloudData;
                                r.translate(e.width / 2, e.height / 2);
                                for (var s = 0; s < a.length; s++) {
                                    r.save(), a[s].rotate && r.rotate(90 * Math.PI / 180);
                                    var l = a[s].name, c = a[s].textSize, u = $(l, c);
                                    r.beginPath(), r.setStrokeStyle(a[s].color), r.setFillStyle(a[s].color), r.setFontSize(c), 
                                    a[s].rotate ? 0 < a[s].areav[0] && (e.tooltip && e.tooltip.index == s ? r.strokeText(l, (a[s].areav[0] + 5 - e.width / 2) * o - u * (1 - o) / 2, (a[s].areav[1] + 5 + c - e.height / 2) * o) : r.fillText(l, (a[s].areav[0] + 5 - e.width / 2) * o - u * (1 - o) / 2, (a[s].areav[1] + 5 + c - e.height / 2) * o)) : 0 < a[s].area[0] && (e.tooltip && e.tooltip.index == s ? r.strokeText(l, (a[s].area[0] + 5 - e.width / 2) * o - u * (1 - o) / 2, (a[s].area[1] + 5 + c - e.height / 2) * o) : r.fillText(l, (a[s].area[0] + 5 - e.width / 2) * o - u * (1 - o) / 2, (a[s].area[1] + 5 + c - e.height / 2) * o)), 
                                    r.stroke(), r.restore();
                                }
                                r.restore();
                            }(s, i, o, a, t), st(0, a);
                        },
                        onAnimationFinish: function() {
                            e.event.trigger("renderComplete");
                        }
                    });
                    break;

                  case "map":
                    a.clearRect(0, 0, i.width, i.height), it(s, i, o, a);
                    break;

                  case "funnel":
                    this.animationInstance = new lt({
                        timing: "easeInOut",
                        duration: n,
                        onProcess: function(t) {
                            a.clearRect(0, 0, i.width, i.height), i.rotate && I(a, i), i.chartData.funnelData = at(s, i, o, a, t), 
                            tt(i.series, i, o, a, i.chartData), K(i, o, a, t), st(0, a);
                        },
                        onAnimationFinish: function() {
                            e.event.trigger("renderComplete");
                        }
                    });
                    break;

                  case "line":
                    this.animationInstance = new lt({
                        timing: "easeIn",
                        duration: n,
                        onProcess: function(t) {
                            a.clearRect(0, 0, i.width, i.height), i.rotate && I(a, i), Q(0, i, 0, a), Y(l, i, o, a);
                            var e = function(t, o, a, l, e) {
                                var s = 4 < arguments.length && void 0 !== e ? e : 1, c = z({}, {
                                    type: "straight",
                                    width: 2
                                }, o.extra.line);
                                c.width *= o.pixelRatio;
                                var u = (e = o.chartData.xAxisData).xAxisPoints, h = e.eachSpacing, f = [];
                                l.save();
                                var p = 0, d = o.width + h;
                                return o._scrollDistance_ && 0 !== o._scrollDistance_ && !0 === o.enableScroll && (l.translate(o._scrollDistance_, 0), 
                                p = -o._scrollDistance_ - h + o.area[3], d = p + (o.xAxis.itemCount + 4) * h), t.forEach(function(t, e) {
                                    var n = [].concat(o.chartData.yAxisData.ranges[t.index]), r = n.pop(), i = n.shift(), n = B(t.data, r, i, u, h, o, a, s);
                                    f.push(n);
                                    r = L(n);
                                    "dash" == t.lineType && (i = t.dashLength || 8, i *= o.pixelRatio, l.setLineDash([ i, i ])), 
                                    l.beginPath(), l.setStrokeStyle(t.color), l.setLineWidth(c.width), r.forEach(function(t, e) {
                                        if (1 === t.length) l.moveTo(t[0].x, t[0].y), l.arc(t[0].x, t[0].y, 1, 0, 2 * Math.PI); else {
                                            l.moveTo(t[0].x, t[0].y);
                                            var n = 0;
                                            if ("curve" === c.type) for (var r = 0; r < t.length; r++) {
                                                var i, o = t[r];
                                                0 == n && o.x > p && (l.moveTo(o.x, o.y), n = 1), 0 < r && o.x > p && o.x < d && (i = F(t, r - 1), 
                                                l.bezierCurveTo(i.ctrA.x, i.ctrA.y, i.ctrB.x, i.ctrB.y, o.x, o.y));
                                            } else for (var a = 0; a < t.length; a++) {
                                                var s = t[a];
                                                0 == n && s.x > p && (l.moveTo(s.x, s.y), n = 1), 0 < a && s.x > p && s.x < d && l.lineTo(s.x, s.y);
                                            }
                                            l.moveTo(t[0].x, t[0].y);
                                        }
                                    }), l.stroke(), l.setLineDash([]), !1 !== o.dataPointShape && E(n, t.color, t.pointShape, l, o);
                                }), !1 !== o.dataLabel && 1 === s && t.forEach(function(t, e) {
                                    var n = [].concat(o.chartData.yAxisData.ranges[t.index]), r = n.pop(), n = n.shift();
                                    V(B(t.data, r, n, u, h, o, a, s), t, a, l);
                                }), l.restore(), {
                                    xAxisPoints: u,
                                    calPoints: f,
                                    eachSpacing: h
                                };
                            }(s, i, o, a, t), n = e.xAxisPoints, r = e.calPoints, e = e.eachSpacing;
                            i.chartData.xAxisPoints = n, i.chartData.calPoints = r, i.chartData.eachSpacing = e, 
                            Z(0, i, o, a), !1 !== i.enableMarkLine && 1 === t && G(i, o, a), tt(i.series, i, o, a, i.chartData), 
                            K(i, o, a, t), st(0, a);
                        },
                        onAnimationFinish: function() {
                            e.event.trigger("renderComplete");
                        }
                    });
                    break;

                  case "mix":
                    this.animationInstance = new lt({
                        timing: "easeIn",
                        duration: n,
                        onProcess: function(t) {
                            a.clearRect(0, 0, i.width, i.height), i.rotate && I(a, i), Q(0, i, 0, a), Y(l, i, o, a);
                            var e = function(t, m, _, b, e) {
                                var A = 4 < arguments.length && void 0 !== e ? e : 1, S = (e = m.chartData.xAxisData).xAxisPoints, w = e.eachSpacing, P = m.height - m.area[2], T = [], k = 0, O = 0;
                                t.forEach(function(t, e) {
                                    "column" == t.type && (O += 1);
                                }), b.save();
                                var D = -2, M = S.length + 2, C = 0, $ = m.width + w;
                                return m._scrollDistance_ && 0 !== m._scrollDistance_ && !0 === m.enableScroll && (b.translate(m._scrollDistance_, 0), 
                                D = Math.floor(-m._scrollDistance_ / w) - 2, M = D + m.xAxis.itemCount + 4, C = -m._scrollDistance_ - w + m.area[3], 
                                $ = C + (m.xAxis.itemCount + 4) * w), t.forEach(function(c, t) {
                                    var e = [].concat(m.chartData.yAxisData.ranges[c.index]), n = e.pop(), e = e.shift(), r = B(c.data, n, e, S, w, m, _, A);
                                    if (T.push(r), "column" == c.type) {
                                        r = N(r, w, O, k, _, m);
                                        for (var i = 0; i < r.length; i++) {
                                            var o, a = r[i];
                                            null !== a && D < i && i < M && (b.beginPath(), b.setStrokeStyle(a.color || c.color), 
                                            b.setLineWidth(1), b.setFillStyle(a.color || c.color), o = a.x - a.width / 2, m.height, 
                                            a.y, m.area[2], b.moveTo(o, a.y), b.moveTo(o, a.y), b.lineTo(o + a.width - 2, a.y), 
                                            b.lineTo(o + a.width - 2, m.height - m.area[2]), b.lineTo(o, m.height - m.area[2]), 
                                            b.lineTo(o, a.y), b.closePath(), b.stroke(), b.fill(), b.closePath(), b.fill());
                                        }
                                        k += 1;
                                    }
                                    if ("area" == c.type) for (var s = L(r), l = 0; l < s.length; l++) {
                                        var u = s[l];
                                        if (b.beginPath(), b.setStrokeStyle(c.color), b.setFillStyle(W(c.color, .2)), b.setLineWidth(2 * m.pixelRatio), 
                                        1 < u.length) {
                                            var h = u[0], f = u[u.length - 1];
                                            b.moveTo(h.x, h.y);
                                            var p = 0;
                                            if ("curve" === c.style) for (var d = 0; d < u.length; d++) {
                                                var g, y = u[d];
                                                0 == p && y.x > C && (b.moveTo(y.x, y.y), p = 1), 0 < d && y.x > C && y.x < $ && (g = F(u, d - 1), 
                                                b.bezierCurveTo(g.ctrA.x, g.ctrA.y, g.ctrB.x, g.ctrB.y, y.x, y.y));
                                            } else for (var v = 0; v < u.length; v++) {
                                                var x = u[v];
                                                0 == p && x.x > C && (b.moveTo(x.x, x.y), p = 1), 0 < v && x.x > C && x.x < $ && b.lineTo(x.x, x.y);
                                            }
                                            b.lineTo(f.x, P), b.lineTo(h.x, P), b.lineTo(h.x, h.y);
                                        } else {
                                            h = u[0];
                                            b.moveTo(h.x - w / 2, h.y), b.lineTo(h.x + w / 2, h.y), b.lineTo(h.x + w / 2, P), 
                                            b.lineTo(h.x - w / 2, P), b.moveTo(h.x - w / 2, h.y);
                                        }
                                        b.closePath(), b.fill();
                                    }
                                    "line" == c.type && L(r).forEach(function(t, e) {
                                        var n;
                                        if ("dash" == c.lineType && (n = c.dashLength || 8, n *= m.pixelRatio, b.setLineDash([ n, n ])), 
                                        b.beginPath(), b.setStrokeStyle(c.color), b.setLineWidth(2 * m.pixelRatio), 1 === t.length) b.moveTo(t[0].x, t[0].y), 
                                        b.arc(t[0].x, t[0].y, 1, 0, 2 * Math.PI); else {
                                            b.moveTo(t[0].x, t[0].y);
                                            var r = 0;
                                            if ("curve" == c.style) for (var i = 0; i < t.length; i++) {
                                                var o, a = t[i];
                                                0 == r && a.x > C && (b.moveTo(a.x, a.y), r = 1), 0 < i && a.x > C && a.x < $ && (o = F(t, i - 1), 
                                                b.bezierCurveTo(o.ctrA.x, o.ctrA.y, o.ctrB.x, o.ctrB.y, a.x, a.y));
                                            } else for (var s = 0; s < t.length; s++) {
                                                var l = t[s];
                                                0 == r && l.x > C && (b.moveTo(l.x, l.y), r = 1), 0 < s && l.x > C && l.x < $ && b.lineTo(l.x, l.y);
                                            }
                                            b.moveTo(t[0].x, t[0].y);
                                        }
                                        b.stroke(), b.setLineDash([]);
                                    }), "point" == c.type && (c.addPoint = !0), 1 == c.addPoint && "column" !== c.type && E(r, c.color, c.pointShape, b, m);
                                }), !1 !== m.dataLabel && 1 === A && (k = 0, t.forEach(function(t, e) {
                                    var n = [].concat(m.chartData.yAxisData.ranges[t.index]), r = n.pop(), n = n.shift(), n = B(t.data, r, n, S, w, m, _, A);
                                    "column" !== t.type ? V(n, t, _, b) : (V(n = N(n, w, O, k, _, m), t, _, b), k += 1);
                                })), b.restore(), {
                                    xAxisPoints: S,
                                    calPoints: T,
                                    eachSpacing: w
                                };
                            }(s, i, o, a, t), n = e.xAxisPoints, r = e.calPoints, e = e.eachSpacing;
                            i.chartData.xAxisPoints = n, i.chartData.calPoints = r, i.chartData.eachSpacing = e, 
                            Z(0, i, o, a), !1 !== i.enableMarkLine && 1 === t && G(i, o, a), tt(i.series, i, o, a, i.chartData), 
                            K(i, o, a, t), st(0, a);
                        },
                        onAnimationFinish: function() {
                            e.event.trigger("renderComplete");
                        }
                    });
                    break;

                  case "column":
                    this.animationInstance = new lt({
                        timing: "easeIn",
                        duration: n,
                        onProcess: function(t) {
                            a.clearRect(0, 0, i.width, i.height), i.rotate && I(a, i), Q(0, i, 0, a), Y(l, i, o, a);
                            var e = q(s, i, o, a, t), n = e.xAxisPoints, r = e.calPoints, e = e.eachSpacing;
                            i.chartData.xAxisPoints = n, i.chartData.calPoints = r, i.chartData.eachSpacing = e, 
                            Z(0, i, o, a), !1 !== i.enableMarkLine && 1 === t && G(i, o, a), tt(i.series, i, o, a, i.chartData), 
                            K(i, o, a, t), st(0, a);
                        },
                        onAnimationFinish: function() {
                            e.event.trigger("renderComplete");
                        }
                    });
                    break;

                  case "area":
                    this.animationInstance = new lt({
                        timing: "easeIn",
                        duration: n,
                        onProcess: function(t) {
                            a.clearRect(0, 0, i.width, i.height), i.rotate && I(a, i), Q(0, i, 0, a), Y(l, i, o, a);
                            var e = function(t, A, S, w, e) {
                                var P = 4 < arguments.length && void 0 !== e ? e : 1, T = z({}, {
                                    type: "straight",
                                    opacity: .2,
                                    addLine: !1,
                                    width: 2,
                                    gradient: !1
                                }, A.extra.area), k = (e = A.chartData.xAxisData).xAxisPoints, O = e.eachSpacing, D = A.height - A.area[2], M = [];
                                w.save();
                                var C = 0, $ = A.width + O;
                                return A._scrollDistance_ && 0 !== A._scrollDistance_ && !0 === A.enableScroll && (w.translate(A._scrollDistance_, 0), 
                                C = -A._scrollDistance_ - O + A.area[3], $ = C + (A.xAxis.itemCount + 4) * O), t.forEach(function(t, e) {
                                    var n = [].concat(A.chartData.yAxisData.ranges[t.index]), r = n.pop(), n = n.shift(), n = B(t.data, r, n, k, O, A, S, P);
                                    M.push(n);
                                    for (var i = L(n), o = 0; o < i.length; o++) {
                                        var a = i[o];
                                        if (w.beginPath(), w.setStrokeStyle(W(t.color, T.opacity)), T.gradient ? ((l = w.createLinearGradient(0, A.area[0], 0, A.height - A.area[2])).addColorStop("0", W(t.color, T.opacity)), 
                                        l.addColorStop("1.0", W("#FFFFFF", .1)), w.setFillStyle(l)) : w.setFillStyle(W(t.color, T.opacity)), 
                                        w.setLineWidth(T.width * A.pixelRatio), 1 < a.length) {
                                            var s = a[0], l = a[a.length - 1];
                                            w.moveTo(s.x, s.y);
                                            var c = 0;
                                            if ("curve" === T.type) for (var u = 0; u < a.length; u++) {
                                                var h, f = a[u];
                                                0 == c && f.x > C && (w.moveTo(f.x, f.y), c = 1), 0 < u && f.x > C && f.x < $ && (h = F(a, u - 1), 
                                                w.bezierCurveTo(h.ctrA.x, h.ctrA.y, h.ctrB.x, h.ctrB.y, f.x, f.y));
                                            } else for (var p = 0; p < a.length; p++) {
                                                var d = a[p];
                                                0 == c && d.x > C && (w.moveTo(d.x, d.y), c = 1), 0 < p && d.x > C && d.x < $ && w.lineTo(d.x, d.y);
                                            }
                                            w.lineTo(l.x, D), w.lineTo(s.x, D), w.lineTo(s.x, s.y);
                                        } else {
                                            var g = a[0];
                                            w.moveTo(g.x - O / 2, g.y), w.lineTo(g.x + O / 2, g.y), w.lineTo(g.x + O / 2, D), 
                                            w.lineTo(g.x - O / 2, D), w.moveTo(g.x - O / 2, g.y);
                                        }
                                        if (w.closePath(), w.fill(), T.addLine) {
                                            if ("dash" == t.lineType && (g = t.dashLength || 8, g *= A.pixelRatio, w.setLineDash([ g, g ])), 
                                            w.beginPath(), w.setStrokeStyle(t.color), w.setLineWidth(T.width * A.pixelRatio), 
                                            1 === a.length) w.moveTo(a[0].x, a[0].y), w.arc(a[0].x, a[0].y, 1, 0, 2 * Math.PI); else {
                                                w.moveTo(a[0].x, a[0].y);
                                                var y = 0;
                                                if ("curve" === T.type) for (var v = 0; v < a.length; v++) {
                                                    var x, m = a[v];
                                                    0 == y && m.x > C && (w.moveTo(m.x, m.y), y = 1), 0 < v && m.x > C && m.x < $ && (x = F(a, v - 1), 
                                                    w.bezierCurveTo(x.ctrA.x, x.ctrA.y, x.ctrB.x, x.ctrB.y, m.x, m.y));
                                                } else for (var _ = 0; _ < a.length; _++) {
                                                    var b = a[_];
                                                    0 == y && b.x > C && (w.moveTo(b.x, b.y), y = 1), 0 < _ && b.x > C && b.x < $ && w.lineTo(b.x, b.y);
                                                }
                                                w.moveTo(a[0].x, a[0].y);
                                            }
                                            w.stroke(), w.setLineDash([]);
                                        }
                                    }
                                    !1 !== A.dataPointShape && E(n, t.color, t.pointShape, w, A);
                                }), !1 !== A.dataLabel && 1 === P && t.forEach(function(t, e) {
                                    var n = [].concat(A.chartData.yAxisData.ranges[t.index]), r = n.pop(), n = n.shift();
                                    V(B(t.data, r, n, k, O, A, S, P), t, S, w);
                                }), w.restore(), {
                                    xAxisPoints: k,
                                    calPoints: M,
                                    eachSpacing: O
                                };
                            }(s, i, o, a, t), n = e.xAxisPoints, r = e.calPoints, e = e.eachSpacing;
                            i.chartData.xAxisPoints = n, i.chartData.calPoints = r, i.chartData.eachSpacing = e, 
                            Z(0, i, o, a), !1 !== i.enableMarkLine && 1 === t && G(i, o, a), tt(i.series, i, o, a, i.chartData), 
                            K(i, o, a, t), st(0, a);
                        },
                        onAnimationFinish: function() {
                            e.event.trigger("renderComplete");
                        }
                    });
                    break;

                  case "ring":
                  case "pie":
                    this.animationInstance = new lt({
                        timing: "easeInOut",
                        duration: n,
                        onProcess: function(t) {
                            a.clearRect(0, 0, i.width, i.height), i.rotate && I(a, i), i.chartData.pieData = function(t, n, e, r, i) {
                                var o = 4 < arguments.length && void 0 !== i ? i : 1, a = z({}, {
                                    activeOpacity: .5,
                                    activeRadius: 10 * n.pixelRatio,
                                    offsetAngle: 0,
                                    labelWidth: 15 * n.pixelRatio,
                                    ringWidth: 0,
                                    border: !1,
                                    borderWidth: 2,
                                    borderColor: "#FFFFFF"
                                }, n.extra.pie), s = {
                                    x: n.area[3] + (n.width - n.area[1] - n.area[3]) / 2,
                                    y: n.area[0] + (n.height - n.area[0] - n.area[2]) / 2
                                };
                                0 == e.pieChartLinePadding && (e.pieChartLinePadding = a.activeRadius);
                                var l = Math.min((n.width - n.area[1] - n.area[3]) / 2 - e.pieChartLinePadding - e.pieChartTextPadding - e._pieTextMaxLength_, (n.height - n.area[0] - n.area[2]) / 2 - e.pieChartLinePadding - e.pieChartTextPadding);
                                t = M(t, l, o);
                                var c = a.activeRadius;
                                if ((t = t.map(function(t) {
                                    return t._start_ += a.offsetAngle * Math.PI / 180, t;
                                })).forEach(function(t, e) {
                                    n.tooltip && n.tooltip.index == e && (r.beginPath(), r.setFillStyle(W(t.color, n.extra.pie.activeOpacity || .5)), 
                                    r.moveTo(s.x, s.y), r.arc(s.x, s.y, t._radius_ + c, t._start_, t._start_ + 2 * t._proportion_ * Math.PI), 
                                    r.closePath(), r.fill()), r.beginPath(), r.setLineWidth(a.borderWidth * n.pixelRatio), 
                                    r.lineJoin = "round", r.setStrokeStyle(a.borderColor), r.setFillStyle(t.color), 
                                    r.moveTo(s.x, s.y), r.arc(s.x, s.y, t._radius_, t._start_, t._start_ + 2 * t._proportion_ * Math.PI), 
                                    r.closePath(), r.fill(), 1 == a.border && r.stroke();
                                }), "ring" === n.type && (i = .6 * l, "number" == typeof n.extra.pie.ringWidth && 0 < n.extra.pie.ringWidth && (i = Math.max(0, l - n.extra.pie.ringWidth)), 
                                r.beginPath(), r.setFillStyle(n.background || "#ffffff"), r.moveTo(s.x, s.y), r.arc(s.x, s.y, i, 0, 2 * Math.PI), 
                                r.closePath(), r.fill()), !1 !== n.dataLabel && 1 === o) {
                                    for (var u = !1, h = 0, f = t.length; h < f; h++) if (0 < t[h].data) {
                                        u = !0;
                                        break;
                                    }
                                    u && X(t, n, e, r, 0, s);
                                }
                                return 1 === o && "ring" === n.type && H(n, e, r, s), {
                                    center: s,
                                    radius: l,
                                    series: t
                                };
                            }(s, i, o, a, t), tt(i.series, i, o, a, i.chartData), K(i, o, a, t), st(0, a);
                        },
                        onAnimationFinish: function() {
                            e.event.trigger("renderComplete");
                        }
                    });
                    break;

                  case "rose":
                    this.animationInstance = new lt({
                        timing: "easeInOut",
                        duration: n,
                        onProcess: function(t) {
                            a.clearRect(0, 0, i.width, i.height), i.rotate && I(a, i), i.chartData.pieData = et(s, i, o, a, t), 
                            tt(i.series, i, o, a, i.chartData), K(i, o, a, t), st(0, a);
                        },
                        onAnimationFinish: function() {
                            e.event.trigger("renderComplete");
                        }
                    });
                    break;

                  case "radar":
                    this.animationInstance = new lt({
                        timing: "easeInOut",
                        duration: n,
                        onProcess: function(t) {
                            a.clearRect(0, 0, i.width, i.height), i.rotate && I(a, i), i.chartData.radarData = rt(s, i, o, a, t), 
                            tt(i.series, i, o, a, i.chartData), K(i, o, a, t), st(0, a);
                        },
                        onAnimationFinish: function() {
                            e.event.trigger("renderComplete");
                        }
                    });
                    break;

                  case "arcbar":
                    this.animationInstance = new lt({
                        timing: "easeInOut",
                        duration: n,
                        onProcess: function(t) {
                            a.clearRect(0, 0, i.width, i.height), i.rotate && I(a, i), i.chartData.arcbarData = function(t, e, n, r, i) {
                                var o, a, i = 4 < arguments.length && void 0 !== i ? i : 1, s = z({}, {
                                    startAngle: .75,
                                    endAngle: .25,
                                    type: "default",
                                    width: 12 * e.pixelRatio,
                                    gap: 2 * e.pixelRatio
                                }, e.extra.arcbar);
                                t = C(t, s, i), o = s.center || {
                                    x: e.width / 2,
                                    y: e.height / 2
                                }, s.radius ? a = s.radius : (a = Math.min(o.x, o.y), a -= 5 * e.pixelRatio, a -= s.width / 2);
                                for (var l = 0; l < t.length; l++) {
                                    var c = t[l];
                                    r.setLineWidth(s.width), r.setStrokeStyle(s.backgroundColor || "#E9E9E9"), r.setLineCap("round"), 
                                    r.beginPath(), "default" == s.type ? r.arc(o.x, o.y, a - (s.width + s.gap) * l, s.startAngle * Math.PI, s.endAngle * Math.PI, !1) : r.arc(o.x, o.y, a - (s.width + s.gap) * l, 0, 2 * Math.PI, !1), 
                                    r.stroke(), r.setLineWidth(s.width), r.setStrokeStyle(c.color), r.setLineCap("round"), 
                                    r.beginPath(), r.arc(o.x, o.y, a - (s.width + s.gap) * l, s.startAngle * Math.PI, c._proportion_ * Math.PI, !1), 
                                    r.stroke();
                                }
                                return H(e, n, r, o), {
                                    center: o,
                                    radius: a,
                                    series: t
                                };
                            }(s, i, o, a, t), st(0, a);
                        },
                        onAnimationFinish: function() {
                            e.event.trigger("renderComplete");
                        }
                    });
                    break;

                  case "gauge":
                    this.animationInstance = new lt({
                        timing: "easeInOut",
                        duration: n,
                        onProcess: function(t) {
                            a.clearRect(0, 0, i.width, i.height), i.rotate && I(a, i), i.chartData.gaugeData = nt(l, s, i, o, a, t), 
                            st(0, a);
                        },
                        onAnimationFinish: function() {
                            e.event.trigger("renderComplete");
                        }
                    });
                    break;

                  case "candle":
                    this.animationInstance = new lt({
                        timing: "easeIn",
                        duration: n,
                        onProcess: function(t) {
                            a.clearRect(0, 0, i.width, i.height), i.rotate && I(a, i), Q(0, i, 0, a), Y(l, i, o, a);
                            var e = J(s, c, i, o, a, t), n = e.xAxisPoints, r = e.calPoints, e = e.eachSpacing;
                            i.chartData.xAxisPoints = n, i.chartData.calPoints = r, i.chartData.eachSpacing = e, 
                            Z(0, i, o, a), !1 !== i.enableMarkLine && 1 === t && G(i, o, a), tt(c || i.series, i, o, a, i.chartData), 
                            K(i, o, a, t), st(0, a);
                        },
                        onAnimationFinish: function() {
                            e.event.trigger("renderComplete");
                        }
                    });
                }
            }
            function m() {
                this.events = {};
            }
            lt.prototype.stop = function() {
                this.isStop = !0;
            }, m.prototype.addEventListener = function(t, e) {
                this.events[t] = this.events[t] || [], this.events[t].push(e);
            }, m.prototype.trigger = function() {
                for (var t = arguments.length, e = Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                var r = e[0], i = e.slice(1);
                this.events[r] && this.events[r].forEach(function(t) {
                    try {
                        t.apply(null, i);
                    } catch (t) {
                        console.error(t);
                    }
                });
            };
            function t(t) {
                t.pixelRatio = t.pixelRatio || 1, t.fontSize = t.fontSize ? t.fontSize * t.pixelRatio : 13 * t.pixelRatio, 
                t.title = z({}, t.title), t.subtitle = z({}, t.subtitle), t.duration = t.duration || 1e3, 
                t.yAxis = z({}, {
                    data: [],
                    showTitle: !1,
                    disabled: !1,
                    disableGrid: !1,
                    splitNumber: 5,
                    gridType: "solid",
                    dashLength: 4 * t.pixelRatio,
                    gridColor: "#cccccc",
                    padding: 10,
                    fontColor: "#666666"
                }, t.yAxis), t.yAxis.dashLength *= t.pixelRatio, t.yAxis.padding *= t.pixelRatio, 
                t.xAxis = z({}, {
                    rotateLabel: !1,
                    type: "calibration",
                    gridType: "solid",
                    dashLength: 4,
                    scrollAlign: "left",
                    boundaryGap: "center",
                    axisLine: !0,
                    axisLineColor: "#cccccc"
                }, t.xAxis), t.xAxis.dashLength *= t.pixelRatio, t.legend = z({}, {
                    show: !0,
                    position: "bottom",
                    float: "center",
                    backgroundColor: "rgba(0,0,0,0)",
                    borderColor: "rgba(0,0,0,0)",
                    borderWidth: 0,
                    padding: 5,
                    margin: 5,
                    itemGap: 10,
                    fontSize: t.fontSize,
                    lineHeight: t.fontSize,
                    fontColor: "#333333",
                    format: {},
                    hiddenColor: "#CECECE"
                }, t.legend), t.legend.borderWidth = t.legend.borderWidth * t.pixelRatio, t.legend.itemGap = t.legend.itemGap * t.pixelRatio, 
                t.legend.padding = t.legend.padding * t.pixelRatio, t.legend.margin = t.legend.margin * t.pixelRatio, 
                t.extra = z({}, t.extra), t.rotate = !!t.rotate, t.animation = !!t.animation, t.rotate = !!t.rotate, 
                t.canvas2d = !!t.canvas2d;
                var e, n, r = JSON.parse(JSON.stringify(a));
                r.colors = t.colors || r.colors, r.yAxisTitleWidth = !0 !== t.yAxis.disabled && t.yAxis.title ? r.yAxisTitleWidth : 0, 
                "pie" != t.type && "ring" != t.type || (r.pieChartLinePadding = !1 === t.dataLabel ? 0 : t.extra.pie.labelWidth * t.pixelRatio || r.pieChartLinePadding * t.pixelRatio), 
                "rose" == t.type && (r.pieChartLinePadding = !1 === t.dataLabel ? 0 : t.extra.rose.labelWidth * t.pixelRatio || r.pieChartLinePadding * t.pixelRatio), 
                r.pieChartTextPadding = !1 === t.dataLabel ? 0 : r.pieChartTextPadding * t.pixelRatio, 
                r.yAxisSplit = t.yAxis.splitNumber || a.yAxisSplit, r.rotate = t.rotate, t.rotate && (e = t.width, 
                n = t.height, t.width = n, t.height = e), t.padding = t.padding || r.padding;
                for (var i = 0; i < 4; i++) t.padding[i] *= t.pixelRatio;
                r.yAxisWidth = a.yAxisWidth * t.pixelRatio, r.xAxisHeight = a.xAxisHeight * t.pixelRatio, 
                t.enableScroll && t.xAxis.scrollShow && (r.xAxisHeight += 6 * t.pixelRatio), r.xAxisLineHeight = a.xAxisLineHeight * t.pixelRatio, 
                r.fontSize = t.fontSize, r.titleFontSize = a.titleFontSize * t.pixelRatio, r.subtitleFontSize = a.subtitleFontSize * t.pixelRatio, 
                r.toolTipPadding = a.toolTipPadding * t.pixelRatio, r.toolTipLineHeight = a.toolTipLineHeight * t.pixelRatio, 
                r.columePadding = a.columePadding * t.pixelRatio, t.$this = t.$this || this, this.context = t.context || o.createCanvasContext(t.canvasId, t.$this), 
                t.canvas2d && (this.context.setStrokeStyle = function(t) {
                    return this.strokeStyle = t;
                }, this.context.setLineWidth = function(t) {
                    return this.lineWidth = t;
                }, this.context.setLineCap = function(t) {
                    return this.lineCap = t;
                }, this.context.setFontSize = function(t) {
                    return this.font = t + "px sans-serif";
                }, this.context.setFillStyle = function(t) {
                    return this.fillStyle = t;
                }, this.context.draw = function() {}), t.chartData = {}, this.event = new m(), this.scrollOption = {
                    currentOffset: 0,
                    startTouchX: 0,
                    distance: 0,
                    lastMoveTime: 0
                }, this.opts = t, this.config = r, x.call(this, t.type, t, r, this.context);
            }
            t.prototype.updateData = function() {
                var t = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {};
                switch (this.opts = z({}, this.opts, t), this.opts.updateData = !0, t.scrollPosition || "current") {
                  case "current":
                    this.opts._scrollDistance_ = this.scrollOption.currentOffset;
                    break;

                  case "left":
                    this.opts._scrollDistance_ = 0, this.scrollOption = {
                        currentOffset: 0,
                        startTouchX: 0,
                        distance: 0,
                        lastMoveTime: 0
                    };
                    break;

                  case "right":
                    var e = j(this.opts.series, this.opts, this.config).yAxisWidth;
                    this.config.yAxisWidth = e;
                    var n = R(this.opts.categories, this.opts, this.config), r = n.xAxisPoints, e = n.startX, i = n.endX - e - n.eachSpacing * (r.length - 1);
                    this.scrollOption = {
                        currentOffset: i,
                        startTouchX: i,
                        distance: 0,
                        lastMoveTime: 0
                    }, this.opts._scrollDistance_ = i;
                }
                x.call(this, this.opts.type, this.opts, this.config, this.context);
            }, t.prototype.zoom = function() {
                var t, e, n, r, i = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : this.opts.xAxis.itemCount;
                !0 === this.opts.enableScroll ? (t = Math.round(Math.abs(this.scrollOption.currentOffset) / this.opts.chartData.eachSpacing) + Math.round(this.opts.xAxis.itemCount / 2), 
                this.opts.animation = !1, this.opts.xAxis.itemCount = i.itemCount, n = j(this.opts.series, this.opts, this.config).yAxisWidth, 
                this.config.yAxisWidth = n, r = 0, i = (e = R(this.opts.categories, this.opts, this.config)).xAxisPoints, 
                n = e.startX, 0 < (r = (n = e.endX - n) / 2 - (e = e.eachSpacing) * t) && (r = 0), 
                r < (i = n - e * (i.length - 1)) && (r = i), this.scrollOption = {
                    currentOffset: r,
                    startTouchX: r,
                    distance: 0,
                    lastMoveTime: 0
                }, this.opts._scrollDistance_ = r, x.call(this, this.opts.type, this.opts, this.config, this.context)) : console.log("请启用滚动条后使用！");
            }, t.prototype.stopAnimation = function() {
                this.animationInstance && this.animationInstance.stop();
            }, t.prototype.addEventListener = function(t, e) {
                this.event.addEventListener(t, e);
            }, t.prototype.getCurrentDataIndex = function(t) {
                var e, r, i, o, a, n = null;
                if (n = (t.changedTouches ? t : t.mp).changedTouches[0]) {
                    var s = f(n, this.opts, t);
                    return "pie" === this.opts.type || "ring" === this.opts.type || "rose" === this.opts.type ? c({
                        x: s.x,
                        y: s.y
                    }, this.opts.chartData.pieData) : "radar" === this.opts.type ? (e = {
                        x: s.x,
                        y: s.y
                    }, n = this.opts.chartData.radarData, t = this.opts.categories.length, o = 2 * Math.PI / t, 
                    a = -1, d(e, n.center, n.radius) && (r = function(t) {
                        return t < 0 && (t += 2 * Math.PI), t > 2 * Math.PI && (t -= 2 * Math.PI), t;
                    }, i = Math.atan2(n.center.y - e.y, e.x - n.center.x), (i *= -1) < 0 && (i += 2 * Math.PI), 
                    n.angleList.map(function(t) {
                        return t = r(-1 * t);
                    }).forEach(function(t, e) {
                        var n = r(t - o / 2), t = r(t + o / 2);
                        t < n && (t += 2 * Math.PI), (n <= i && i <= t || i + 2 * Math.PI >= n && i + 2 * Math.PI <= t) && (a = e);
                    })), a) : "funnel" === this.opts.type ? function(t, e) {
                        for (var n = -1, r = 0, i = e.series.length; r < i; r++) {
                            var o = e.series[r];
                            if (t.x > o.funnelArea[0] && t.x < o.funnelArea[2] && t.y > o.funnelArea[1] && t.y < o.funnelArea[3]) {
                                n = r;
                                break;
                            }
                        }
                        return n;
                    }({
                        x: s.x,
                        y: s.y
                    }, this.opts.chartData.funnelData) : "map" === this.opts.type ? l({
                        x: s.x,
                        y: s.y
                    }, this.opts) : "word" === this.opts.type ? function(t, e) {
                        for (var n = -1, r = 0, i = e.length; r < i; r++) {
                            var o = e[r];
                            if (t.x > o.area[0] && t.x < o.area[2] && t.y > o.area[1] && t.y < o.area[3]) {
                                n = r;
                                break;
                            }
                        }
                        return n;
                    }({
                        x: s.x,
                        y: s.y
                    }, this.opts.chartData.wordCloudData) : function(n, t, e, r, i) {
                        var o = 4 < arguments.length && void 0 !== i ? i : 0, a = -1, s = e.chartData.eachSpacing / 2, l = [];
                        if (0 < t.length) {
                            for (var c = 1; c < e.chartData.xAxisPoints.length; c++) l.push(e.chartData.xAxisPoints[c] - s);
                            "line" != e.type && "area" != e.type || "justify" != e.xAxis.boundaryGap || (s = e.chartData.eachSpacing / 2), 
                            e.categories || (s = 0), i = e, (t = n).x <= i.width - i.area[1] + 10 && t.x >= i.area[3] - 10 && t.y >= i.area[0] && t.y <= i.height - i.area[2] && l.forEach(function(t, e) {
                                n.x + o + s > t && (a = e);
                            });
                        }
                        return a;
                    }({
                        x: s.x,
                        y: s.y
                    }, this.opts.chartData.calPoints, this.opts, this.config, Math.abs(this.scrollOption.currentOffset));
                }
                return -1;
            }, t.prototype.getLegendDataIndex = function(t) {
                var e = null;
                if (e = (t.changedTouches ? t : t.mp).changedTouches[0]) {
                    t = f(e, this.opts, t);
                    return function(t, e) {
                        var n, r, i = -1;
                        if (n = t, r = e.area, n.x > r.start.x && n.x < r.end.x && n.y > r.start.y && n.y < r.end.y) {
                            for (var o = e.points, a = -1, s = 0, l = o.length; s < l; s++) for (var c = o[s], u = 0; u < c.length; u++) {
                                a += 1;
                                var h = c[u].area;
                                if (t.x > h[0] && t.x < h[2] && t.y > h[1] && t.y < h[3]) {
                                    i = a;
                                    break;
                                }
                            }
                            return i;
                        }
                        return i;
                    }({
                        x: t.x,
                        y: t.y
                    }, this.opts.chartData.legendData);
                }
                return -1;
            }, t.prototype.touchLegend = function(t) {
                var e = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}, n = null;
                (n = (t.changedTouches ? t : t.mp).changedTouches[0]) && (f(n, this.opts, t), 0 <= (t = this.getLegendDataIndex(t)) && (this.opts.series[t].show = !this.opts.series[t].show, 
                this.opts.animation = !!e.animation, this.opts._scrollDistance_ = this.scrollOption.currentOffset, 
                x.call(this, this.opts.type, this.opts, this.config, this.context)));
            }, t.prototype.showToolTip = function(t) {
                var e = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {}, n = null;
                (n = (t.changedTouches ? t : t.mp).changedTouches[0]) || console.log("touchError");
                var r, i, o, a, s, l = f(n, this.opts, t), c = this.scrollOption.currentOffset, u = z({}, this.opts, {
                    _scrollDistance_: c,
                    animation: !1
                });
                "line" !== this.opts.type && "area" !== this.opts.type && "column" !== this.opts.type || (-1 < (s = null == e.index ? this.getCurrentDataIndex(t) : e.index) && (0 !== (a = p(this.opts.series, s)).length && (i = (r = function(t, e, n, r, i) {
                    for (var o = 4 < arguments.length && void 0 !== i ? i : {}, t = t.map(function(t) {
                        var e = r || t.data;
                        return {
                            text: o.format ? o.format(t, e[n]) : t.name + ": " + t.data,
                            color: t.color
                        };
                    }), a = [], s = {
                        x: 0,
                        y: 0
                    }, l = 0; l < e.length; l++) {
                        var c = e[l];
                        void 0 !== c[n] && null !== c[n] && a.push(c[n]);
                    }
                    for (var u = 0; u < a.length; u++) {
                        var h = a[u];
                        s.x = Math.round(h.x), s.y += h.y;
                    }
                    return s.y /= a.length, {
                        textList: t,
                        offset: s
                    };
                }(a, this.opts.chartData.calPoints, s, this.opts.categories, e)).textList, (o = r.offset).y = l.y, 
                u.tooltip = {
                    textList: e.textList || i,
                    offset: o,
                    option: e,
                    index: s
                })), x.call(this, u.type, u, this.config, this.context)), "mix" === this.opts.type && (-1 < (s = null == e.index ? this.getCurrentDataIndex(t) : e.index) && (c = this.scrollOption.currentOffset, 
                u = z({}, this.opts, {
                    _scrollDistance_: c,
                    animation: !1
                }), 0 !== (a = p(this.opts.series, s)).length && (i = (n = function(t, e, n, r, i) {
                    for (var o = 4 < arguments.length && void 0 !== i ? i : {}, t = (t = t.map(function(t) {
                        return {
                            text: o.format ? o.format(t, r[n]) : t.name + ": " + t.data,
                            color: t.color,
                            disableLegend: !!t.disableLegend
                        };
                    })).filter(function(t) {
                        if (!0 !== t.disableLegend) return t;
                    }), a = [], s = {
                        x: 0,
                        y: 0
                    }, l = 0; l < e.length; l++) {
                        var c = e[l];
                        void 0 !== c[n] && null !== c[n] && a.push(c[n]);
                    }
                    for (var u = 0; u < a.length; u++) {
                        var h = a[u];
                        s.x = Math.round(h.x), s.y += h.y;
                    }
                    return s.y /= a.length, {
                        textList: t,
                        offset: s
                    };
                }(a, this.opts.chartData.calPoints, s, this.opts.categories, e)).textList, (o = n.offset).y = l.y, 
                u.tooltip = {
                    textList: e.textList || i,
                    offset: o,
                    option: e,
                    index: s
                })), x.call(this, u.type, u, this.config, this.context)), "candle" === this.opts.type && (-1 < (s = null == e.index ? this.getCurrentDataIndex(t) : e.index) && (c = this.scrollOption.currentOffset, 
                u = z({}, this.opts, {
                    _scrollDistance_: c,
                    animation: !1
                }), 0 !== (a = p(this.opts.series, s)).length && (i = (r = function(i, t, e, o, n, r) {
                    var a = r.color.upFill, s = r.color.downFill, l = [ a, a, s, a ], c = [], n = {
                        text: n[o],
                        color: null
                    };
                    c.push(n), t.map(function(t) {
                        0 == o ? t.data[1] - t.data[0] < 0 ? l[1] = s : l[1] = a : (t.data[0] < i[o - 1][1] && (l[0] = s), 
                        t.data[1] < t.data[0] && (l[1] = s), t.data[2] > i[o - 1][1] && (l[2] = a), t.data[3] < i[o - 1][1] && (l[3] = s));
                        var e = {
                            text: "开盘：" + t.data[0],
                            color: l[0]
                        }, n = {
                            text: "收盘：" + t.data[1],
                            color: l[1]
                        }, r = {
                            text: "最低：" + t.data[2],
                            color: l[2]
                        }, t = {
                            text: "最高：" + t.data[3],
                            color: l[3]
                        };
                        c.push(e, n, r, t);
                    });
                    for (var u = [], t = {
                        x: 0,
                        y: 0
                    }, h = 0; h < e.length; h++) {
                        var f = e[h];
                        void 0 !== f[o] && null !== f[o] && u.push(f[o]);
                    }
                    return t.x = Math.round(u[0][0].x), {
                        textList: c,
                        offset: t
                    };
                }(this.opts.series[0].data, a, this.opts.chartData.calPoints, s, this.opts.categories, this.opts.extra.candle)).textList, 
                (o = r.offset).y = l.y, u.tooltip = {
                    textList: e.textList || i,
                    offset: o,
                    option: e,
                    index: s
                })), x.call(this, u.type, u, this.config, this.context)), "pie" !== this.opts.type && "ring" !== this.opts.type && "rose" !== this.opts.type && "funnel" !== this.opts.type || (-1 < (s = null == e.index ? this.getCurrentDataIndex(t) : e.index) && (c = this.scrollOption.currentOffset, 
                u = z({}, this.opts, {
                    _scrollDistance_: c,
                    animation: !1
                }), a = this.opts._series_[s], i = [ {
                    text: e.format ? e.format(a) : a.name + ": " + a.data,
                    color: a.color
                } ], o = {
                    x: l.x,
                    y: l.y
                }, u.tooltip = {
                    textList: e.textList || i,
                    offset: o,
                    option: e,
                    index: s
                }), x.call(this, u.type, u, this.config, this.context)), "map" !== this.opts.type && "word" !== this.opts.type || (-1 < (s = null == e.index ? this.getCurrentDataIndex(t) : e.index) && (c = this.scrollOption.currentOffset, 
                u = z({}, this.opts, {
                    _scrollDistance_: c,
                    animation: !1
                }), a = this.opts._series_[s], i = [ {
                    text: e.format ? e.format(a) : a.properties.name,
                    color: a.color
                } ], o = {
                    x: l.x,
                    y: l.y
                }, u.tooltip = {
                    textList: e.textList || i,
                    offset: o,
                    option: e,
                    index: s
                }), u.updateData = !1, x.call(this, u.type, u, this.config, this.context)), "radar" === this.opts.type && (-1 < (s = null == e.index ? this.getCurrentDataIndex(t) : e.index) && (c = this.scrollOption.currentOffset, 
                u = z({}, this.opts, {
                    _scrollDistance_: c,
                    animation: !1
                }), 0 !== (a = p(this.opts.series, s)).length && (i = a.map(function(t) {
                    return {
                        text: e.format ? e.format(t) : t.name + ": " + t.data,
                        color: t.color
                    };
                }), o = {
                    x: l.x,
                    y: l.y
                }, u.tooltip = {
                    textList: e.textList || i,
                    offset: o,
                    option: e,
                    index: s
                })), x.call(this, u.type, u, this.config, this.context));
            }, t.prototype.translate = function(t) {
                this.scrollOption = {
                    currentOffset: t,
                    startTouchX: t,
                    distance: 0,
                    lastMoveTime: 0
                };
                t = z({}, this.opts, {
                    _scrollDistance_: t,
                    animation: !1
                });
                x.call(this, this.opts.type, t, this.config, this.context);
            }, t.prototype.scrollStart = function(t) {
                var e = null, t = f(e = (t.changedTouches ? t : t.mp).changedTouches[0], this.opts, t);
                e && !0 === this.opts.enableScroll && (this.scrollOption.startTouchX = t.x);
            }, t.prototype.scroll = function(t) {
                0 === this.scrollOption.lastMoveTime && (this.scrollOption.lastMoveTime = Date.now());
                var e, n = this.opts.extra.touchMoveLimit || 20, r = Date.now();
                if (!(r - this.scrollOption.lastMoveTime < Math.floor(1e3 / n))) {
                    this.scrollOption.lastMoveTime = r;
                    var i = null;
                    if ((i = (t.changedTouches ? t : t.mp).changedTouches[0]) && !0 === this.opts.enableScroll) {
                        var o = f(i, this.opts, t).x - this.scrollOption.startTouchX, a = this.scrollOption.currentOffset, i = (e = a + o, 
                        r = (n = this).opts.chartData, this.config, i = this.opts, t = i.width - i.area[1] - i.area[3], 
                        r = r.eachSpacing * (i.chartData.xAxisData.xAxisPoints.length - 1), 0 <= (i = e) ? (i = 0, 
                        n.event.trigger("scrollLeft")) : Math.abs(e) >= r - t && (i = t - r, n.event.trigger("scrollRight")), 
                        i);
                        this.scrollOption.distance = o = i - a;
                        i = z({}, this.opts, {
                            _scrollDistance_: a + o,
                            animation: !1
                        });
                        return x.call(this, i.type, i, this.config, this.context), a + o;
                    }
                }
            }, t.prototype.scrollEnd = function(t) {
                var e, n;
                !0 === this.opts.enableScroll && (e = (n = this.scrollOption).currentOffset, n = n.distance, 
                this.scrollOption.currentOffset = e + n, this.scrollOption.distance = 0);
            }, "object" === _typeof(e.exports) && (e.exports = t);
        }).call(this, n("543d").default);
    },
    a035: function($, t, e) {
        var F = "function" == typeof Symbol && "symbol" == _typeof(Symbol.iterator) ? function(t) {
            return void 0 === t ? "undefined" : _typeof(t);
        } : function(t) {
            return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : void 0 === t ? "undefined" : _typeof(t);
        };
        (function() {
            function e() {}
            function h(t) {
                return t instanceof h ? t : this instanceof h ? void (this._wrapped = t) : new h(t);
            }
            var r = Array.prototype, a = Object.prototype, t = Function.prototype, i = r.push, s = r.slice, f = a.toString, n = a.hasOwnProperty, o = Array.isArray, l = Object.keys, c = t.bind, u = Object.create;
            ($.exports = h).VERSION = "1.8.2";
            function p(i, o, t) {
                if (void 0 === o) return i;
                switch (null == t ? 3 : t) {
                  case 1:
                    return function(t) {
                        return i.call(o, t);
                    };

                  case 2:
                    return function(t, e) {
                        return i.call(o, t, e);
                    };

                  case 3:
                    return function(t, e, n) {
                        return i.call(o, t, e, n);
                    };

                  case 4:
                    return function(t, e, n, r) {
                        return i.call(o, t, e, n, r);
                    };
                }
                return function() {
                    return i.apply(o, arguments);
                };
            }
            function d(t, e, n) {
                return null == t ? h.identity : h.isFunction(t) ? p(t, e, n) : h.isObject(t) ? h.matcher(t) : h.property(t);
            }
            h.iteratee = function(t, e) {
                return d(t, e, 1 / 0);
            };
            function g(t) {
                return h.isObject(t) ? u ? u(t) : (e.prototype = t, t = new e(), e.prototype = null, 
                t) : {};
            }
            function y(t) {
                return "number" == typeof (t = null != t && t.length) && 0 <= t && t <= x;
            }
            var v = function(l, c) {
                return function(t) {
                    var e = arguments.length;
                    if (e < 2 || null == t) return t;
                    for (var n = 1; n < e; n++) for (var r = arguments[n], i = l(r), o = i.length, a = 0; a < o; a++) {
                        var s = i[a];
                        c && void 0 !== t[s] || (t[s] = r[s]);
                    }
                    return t;
                };
            }, x = Math.pow(2, 53) - 1;
            function m(s) {
                return function(t, e, n, r) {
                    e = p(e, r, 4);
                    var i = !y(t) && h.keys(t), o = (i || t).length, r = 0 < s ? 0 : o - 1;
                    return arguments.length < 3 && (n = t[i ? i[r] : r], r += s), function(t, e, n, r, i, o) {
                        for (;0 <= i && i < o; i += s) {
                            var a = r ? r[i] : i;
                            n = e(n, t[a], a, t);
                        }
                        return n;
                    }(t, e, n, i, r, o);
                };
            }
            h.each = h.forEach = function(t, e, n) {
                if (e = p(e, n), y(t)) for (i = 0, o = t.length; i < o; i++) e(t[i], i, t); else for (var r = h.keys(t), i = 0, o = r.length; i < o; i++) e(t[r[i]], r[i], t);
                return t;
            }, h.map = h.collect = function(t, e, n) {
                e = d(e, n);
                for (var r = !y(t) && h.keys(t), i = (r || t).length, o = Array(i), a = 0; a < i; a++) {
                    var s = r ? r[a] : a;
                    o[a] = e(t[s], s, t);
                }
                return o;
            }, h.reduce = h.foldl = h.inject = m(1), h.reduceRight = h.foldr = m(-1), h.find = h.detect = function(t, e, n) {
                if (void 0 !== (n = y(t) ? h.findIndex(t, e, n) : h.findKey(t, e, n)) && -1 !== n) return t[n];
            }, h.filter = h.select = function(t, r, e) {
                var i = [];
                return r = d(r, e), h.each(t, function(t, e, n) {
                    r(t, e, n) && i.push(t);
                }), i;
            }, h.reject = function(t, e, n) {
                return h.filter(t, h.negate(d(e)), n);
            }, h.every = h.all = function(t, e, n) {
                e = d(e, n);
                for (var r = !y(t) && h.keys(t), i = (r || t).length, o = 0; o < i; o++) {
                    var a = r ? r[o] : o;
                    if (!e(t[a], a, t)) return !1;
                }
                return !0;
            }, h.some = h.any = function(t, e, n) {
                e = d(e, n);
                for (var r = !y(t) && h.keys(t), i = (r || t).length, o = 0; o < i; o++) {
                    var a = r ? r[o] : o;
                    if (e(t[a], a, t)) return !0;
                }
                return !1;
            }, h.contains = h.includes = h.include = function(t, e, n) {
                return y(t) || (t = h.values(t)), 0 <= h.indexOf(t, e, "number" == typeof n && n);
            }, h.invoke = function(t, n) {
                var r = s.call(arguments, 2), i = h.isFunction(n);
                return h.map(t, function(t) {
                    var e = i ? n : t[n];
                    return null == e ? e : e.apply(t, r);
                });
            }, h.pluck = function(t, e) {
                return h.map(t, h.property(e));
            }, h.where = function(t, e) {
                return h.filter(t, h.matcher(e));
            }, h.findWhere = function(t, e) {
                return h.find(t, h.matcher(e));
            }, h.max = function(t, r, e) {
                var n, i, o = -1 / 0, a = -1 / 0;
                if (null == r && null != t) for (var s = 0, l = (t = y(t) ? t : h.values(t)).length; s < l; s++) n = t[s], 
                o < n && (o = n); else r = d(r, e), h.each(t, function(t, e, n) {
                    i = r(t, e, n), (a < i || i === -1 / 0 && o === -1 / 0) && (o = t, a = i);
                });
                return o;
            }, h.min = function(t, r, e) {
                var n, i, o = 1 / 0, a = 1 / 0;
                if (null == r && null != t) for (var s = 0, l = (t = y(t) ? t : h.values(t)).length; s < l; s++) (n = t[s]) < o && (o = n); else r = d(r, e), 
                h.each(t, function(t, e, n) {
                    ((i = r(t, e, n)) < a || i === 1 / 0 && o === 1 / 0) && (o = t, a = i);
                });
                return o;
            }, h.shuffle = function(t) {
                for (var e, n = y(t) ? t : h.values(t), r = n.length, i = Array(r), o = 0; o < r; o++) (e = h.random(0, o)) !== o && (i[o] = i[e]), 
                i[e] = n[o];
                return i;
            }, h.sample = function(t, e, n) {
                return null == e || n ? (y(t) || (t = h.values(t)), t[h.random(t.length - 1)]) : h.shuffle(t).slice(0, Math.max(0, e));
            }, h.sortBy = function(t, r, e) {
                return r = d(r, e), h.pluck(h.map(t, function(t, e, n) {
                    return {
                        value: t,
                        index: e,
                        criteria: r(t, e, n)
                    };
                }).sort(function(t, e) {
                    var n = t.criteria, r = e.criteria;
                    if (n !== r) {
                        if (r < n || void 0 === n) return 1;
                        if (n < r || void 0 === r) return -1;
                    }
                    return t.index - e.index;
                }), "value");
            };
            t = function(o) {
                return function(n, r, t) {
                    var i = {};
                    return r = d(r, t), h.each(n, function(t, e) {
                        e = r(t, e, n);
                        o(i, t, e);
                    }), i;
                };
            };
            h.groupBy = t(function(t, e, n) {
                h.has(t, n) ? t[n].push(e) : t[n] = [ e ];
            }), h.indexBy = t(function(t, e, n) {
                t[n] = e;
            }), h.countBy = t(function(t, e, n) {
                h.has(t, n) ? t[n]++ : t[n] = 1;
            }), h.toArray = function(t) {
                return t ? h.isArray(t) ? s.call(t) : y(t) ? h.map(t, h.identity) : h.values(t) : [];
            }, h.size = function(t) {
                return null == t ? 0 : (y(t) ? t : h.keys(t)).length;
            }, h.partition = function(t, r, e) {
                r = d(r, e);
                var i = [], o = [];
                return h.each(t, function(t, e, n) {
                    (r(t, e, n) ? i : o).push(t);
                }), [ i, o ];
            }, h.first = h.head = h.take = function(t, e, n) {
                if (null != t) return null == e || n ? t[0] : h.initial(t, t.length - e);
            }, h.initial = function(t, e, n) {
                return s.call(t, 0, Math.max(0, t.length - (null == e || n ? 1 : e)));
            }, h.last = function(t, e, n) {
                if (null != t) return null == e || n ? t[t.length - 1] : h.rest(t, Math.max(0, t.length - e));
            }, h.rest = h.tail = h.drop = function(t, e, n) {
                return s.call(t, null == e || n ? 1 : e);
            }, h.compact = function(t) {
                return h.filter(t, h.identity);
            };
            function _(t, e, n, r) {
                for (var i = [], o = 0, a = r || 0, s = t && t.length; a < s; a++) {
                    var l = t[a];
                    if (y(l) && (h.isArray(l) || h.isArguments(l))) {
                        e || (l = _(l, e, n));
                        var c = 0, u = l.length;
                        for (i.length += u; c < u; ) i[o++] = l[c++];
                    } else n || (i[o++] = l);
                }
                return i;
            }
            function b(o) {
                return function(t, e, n) {
                    e = d(e, n);
                    for (var r = null != t && t.length, i = 0 < o ? 0 : r - 1; 0 <= i && i < r; i += o) if (e(t[i], i, t)) return i;
                    return -1;
                };
            }
            h.flatten = function(t, e) {
                return _(t, e, !1);
            }, h.without = function(t) {
                return h.difference(t, s.call(arguments, 1));
            }, h.uniq = h.unique = function(t, e, n, r) {
                if (null == t) return [];
                h.isBoolean(e) || (r = n, n = e, e = !1), null != n && (n = d(n, r));
                for (var i = [], o = [], a = 0, s = t.length; a < s; a++) {
                    var l = t[a], c = n ? n(l, a, t) : l;
                    e ? (a && o === c || i.push(l), o = c) : n ? h.contains(o, c) || (o.push(c), i.push(l)) : h.contains(i, l) || i.push(l);
                }
                return i;
            }, h.union = function() {
                return h.uniq(_(arguments, !0, !0));
            }, h.intersection = function(t) {
                if (null == t) return [];
                for (var e = [], n = arguments.length, r = 0, i = t.length; r < i; r++) {
                    var o = t[r];
                    if (!h.contains(e, o)) {
                        for (var a = 1; a < n && h.contains(arguments[a], o); a++) ;
                        a === n && e.push(o);
                    }
                }
                return e;
            }, h.difference = function(t) {
                var e = _(arguments, !0, !0, 1);
                return h.filter(t, function(t) {
                    return !h.contains(e, t);
                });
            }, h.zip = function() {
                return h.unzip(arguments);
            }, h.unzip = function(t) {
                for (var e = t && h.max(t, "length").length || 0, n = Array(e), r = 0; r < e; r++) n[r] = h.pluck(t, r);
                return n;
            }, h.object = function(t, e) {
                for (var n = {}, r = 0, i = t && t.length; r < i; r++) e ? n[t[r]] = e[r] : n[t[r][0]] = t[r][1];
                return n;
            }, h.indexOf = function(t, e, n) {
                var r = 0, i = t && t.length;
                if ("number" == typeof n) r = n < 0 ? Math.max(0, i + n) : n; else if (n && i) return t[r = h.sortedIndex(t, e)] === e ? r : -1;
                if (e != e) return h.findIndex(s.call(t, r), h.isNaN);
                for (;r < i; r++) if (t[r] === e) return r;
                return -1;
            }, h.lastIndexOf = function(t, e, n) {
                var r = t ? t.length : 0;
                if ("number" == typeof n && (r = n < 0 ? r + n + 1 : Math.min(r, n + 1)), e != e) return h.findLastIndex(s.call(t, 0, r), h.isNaN);
                for (;0 <= --r; ) if (t[r] === e) return r;
                return -1;
            }, h.findIndex = b(1), h.findLastIndex = b(-1), h.sortedIndex = function(t, e, n, r) {
                for (var i = (n = d(n, r, 1))(e), o = 0, a = t.length; o < a; ) {
                    var s = Math.floor((o + a) / 2);
                    n(t[s]) < i ? o = s + 1 : a = s;
                }
                return o;
            }, h.range = function(t, e, n) {
                arguments.length <= 1 && (e = t || 0, t = 0), n = n || 1;
                for (var r = Math.max(Math.ceil((e - t) / n), 0), i = Array(r), o = 0; o < r; o++, 
                t += n) i[o] = t;
                return i;
            };
            function A(t, e, n, r, i) {
                return r instanceof e ? (n = g(t.prototype), i = t.apply(n, i), h.isObject(i) ? i : n) : t.apply(n, i);
            }
            h.bind = function(e, n) {
                if (c && e.bind === c) return c.apply(e, s.call(arguments, 1));
                if (!h.isFunction(e)) throw new TypeError("Bind must be called on a function");
                var r = s.call(arguments, 2);
                return function t() {
                    return A(e, t, n, this, r.concat(s.call(arguments)));
                };
            }, h.partial = function(o) {
                var a = s.call(arguments, 1);
                return function t() {
                    for (var e = 0, n = a.length, r = Array(n), i = 0; i < n; i++) r[i] = a[i] === h ? arguments[e++] : a[i];
                    for (;e < arguments.length; ) r.push(arguments[e++]);
                    return A(o, t, this, this, r);
                };
            }, h.bindAll = function(t) {
                var e, n, r = arguments.length;
                if (r <= 1) throw new Error("bindAll must be passed function names");
                for (e = 1; e < r; e++) t[n = arguments[e]] = h.bind(t[n], t);
                return t;
            }, h.memoize = function(n, r) {
                function i(t) {
                    var e = i.cache, t = "" + (r ? r.apply(this, arguments) : t);
                    return h.has(e, t) || (e[t] = n.apply(this, arguments)), e[t];
                }
                return i.cache = {}, i;
            }, h.defer = h.partial(h.delay = function(t, e) {
                var n = s.call(arguments, 2);
                return setTimeout(function() {
                    return t.apply(null, n);
                }, e);
            }, h, 1), h.throttle = function(n, r, i) {
                var o, a, s, l = null, c = 0;
                i = i || {};
                function u() {
                    c = !1 === i.leading ? 0 : h.now(), l = null, s = n.apply(o, a), l || (o = a = null);
                }
                return function() {
                    var t = h.now();
                    c || !1 !== i.leading || (c = t);
                    var e = r - (t - c);
                    return o = this, a = arguments, e <= 0 || r < e ? (l && (clearTimeout(l), l = null), 
                    c = t, s = n.apply(o, a), l || (o = a = null)) : l || !1 === i.trailing || (l = setTimeout(u, e)), 
                    s;
                };
            }, h.debounce = function(e, n, r) {
                function i() {
                    var t = h.now() - l;
                    t < n && 0 <= t ? o = setTimeout(i, n - t) : (o = null, r || (c = e.apply(s, a), 
                    o || (s = a = null)));
                }
                var o, a, s, l, c;
                return function() {
                    s = this, a = arguments, l = h.now();
                    var t = r && !o;
                    return o = o || setTimeout(i, n), t && (c = e.apply(s, a), s = a = null), c;
                };
            }, h.wrap = function(t, e) {
                return h.partial(e, t);
            }, h.negate = function(t) {
                return function() {
                    return !t.apply(this, arguments);
                };
            }, h.compose = function() {
                var n = arguments, r = n.length - 1;
                return function() {
                    for (var t = r, e = n[r].apply(this, arguments); t--; ) e = n[t].call(this, e);
                    return e;
                };
            }, h.after = function(t, e) {
                return function() {
                    if (--t < 1) return e.apply(this, arguments);
                };
            }, h.once = h.partial(h.before = function(t, e) {
                var n;
                return function() {
                    return 0 < --t && (n = e.apply(this, arguments)), t <= 1 && (e = null), n;
                };
            }, 2);
            var S = !{
                toString: null
            }.propertyIsEnumerable("toString"), w = [ "valueOf", "isPrototypeOf", "toString", "propertyIsEnumerable", "hasOwnProperty", "toLocaleString" ];
            function P(t, e) {
                var n = w.length, r = t.constructor, i = h.isFunction(r) && r.prototype || a, o = "constructor";
                for (h.has(t, o) && !h.contains(e, o) && e.push(o); n--; ) (o = w[n]) in t && t[o] !== i[o] && !h.contains(e, o) && e.push(o);
            }
            h.keys = function(t) {
                if (!h.isObject(t)) return [];
                if (l) return l(t);
                var e, n = [];
                for (e in t) h.has(t, e) && n.push(e);
                return S && P(t, n), n;
            }, h.allKeys = function(t) {
                if (!h.isObject(t)) return [];
                var e, n = [];
                for (e in t) n.push(e);
                return S && P(t, n), n;
            }, h.values = function(t) {
                for (var e = h.keys(t), n = e.length, r = Array(n), i = 0; i < n; i++) r[i] = t[e[i]];
                return r;
            }, h.mapObject = function(t, e, n) {
                e = d(e, n);
                for (var r, i = h.keys(t), o = i.length, a = {}, s = 0; s < o; s++) a[r = i[s]] = e(t[r], r, t);
                return a;
            }, h.pairs = function(t) {
                for (var e = h.keys(t), n = e.length, r = Array(n), i = 0; i < n; i++) r[i] = [ e[i], t[e[i]] ];
                return r;
            }, h.invert = function(t) {
                for (var e = {}, n = h.keys(t), r = 0, i = n.length; r < i; r++) e[t[n[r]]] = n[r];
                return e;
            }, h.functions = h.methods = function(t) {
                var e, n = [];
                for (e in t) h.isFunction(t[e]) && n.push(e);
                return n.sort();
            }, h.extend = v(h.allKeys), h.extendOwn = h.assign = v(h.keys), h.findKey = function(t, e, n) {
                e = d(e, n);
                for (var r, i = h.keys(t), o = 0, a = i.length; o < a; o++) if (e(t[r = i[o]], r, t)) return r;
            }, h.pick = function(t, e, n) {
                var r, i, o = {}, a = t;
                if (null == a) return o;
                h.isFunction(e) ? (i = h.allKeys(a), r = p(e, n)) : (i = _(arguments, !1, !1, 1), 
                r = function(t, e, n) {
                    return e in n;
                }, a = Object(a));
                for (var s = 0, l = i.length; s < l; s++) {
                    var c = i[s], u = a[c];
                    r(u, c, a) && (o[c] = u);
                }
                return o;
            }, h.omit = function(t, e, n) {
                var r;
                return e = h.isFunction(e) ? h.negate(e) : (r = h.map(_(arguments, !1, !1, 1), String), 
                function(t, e) {
                    return !h.contains(r, e);
                }), h.pick(t, e, n);
            }, h.defaults = v(h.allKeys, !0), h.create = function(t, e) {
                t = g(t);
                return e && h.extendOwn(t, e), t;
            }, h.clone = function(t) {
                return h.isObject(t) ? h.isArray(t) ? t.slice() : h.extend({}, t) : t;
            }, h.tap = function(t, e) {
                return e(t), t;
            }, h.isMatch = function(t, e) {
                var n = h.keys(e), r = n.length;
                if (null == t) return !r;
                for (var i = Object(t), o = 0; o < r; o++) {
                    var a = n[o];
                    if (e[a] !== i[a] || !(a in i)) return !1;
                }
                return !0;
            }, h.isEqual = function(t, e) {
                return function t(e, n, r, i) {
                    if (e === n) return 0 !== e || 1 / e == 1 / n;
                    if (null == e || null == n) return e === n;
                    e instanceof h && (e = e._wrapped), n instanceof h && (n = n._wrapped);
                    var o = f.call(e);
                    if (o !== f.call(n)) return !1;
                    switch (o) {
                      case "[object RegExp]":
                      case "[object String]":
                        return "" + e == "" + n;

                      case "[object Number]":
                        return +e != +e ? +n != +n : 0 == +e ? 1 / +e == 1 / n : +e == +n;

                      case "[object Date]":
                      case "[object Boolean]":
                        return +e == +n;
                    }
                    var a = "[object Array]" === o;
                    if (!a) {
                        if ("object" != (void 0 === e ? "undefined" : F(e)) || "object" != (void 0 === n ? "undefined" : F(n))) return !1;
                        var s = e.constructor, o = n.constructor;
                        if (s !== o && !(h.isFunction(s) && s instanceof s && h.isFunction(o) && o instanceof o) && "constructor" in e && "constructor" in n) return !1;
                    }
                    i = i || [];
                    for (var l = (r = r || []).length; l--; ) if (r[l] === e) return i[l] === n;
                    if (r.push(e), i.push(n), a) {
                        if ((l = e.length) !== n.length) return !1;
                        for (;l--; ) if (!t(e[l], n[l], r, i)) return !1;
                    } else {
                        var c, u = h.keys(e), l = u.length;
                        if (h.keys(n).length !== l) return !1;
                        for (;l--; ) if (c = u[l], !h.has(n, c) || !t(e[c], n[c], r, i)) return !1;
                    }
                    return r.pop(), i.pop(), !0;
                }(t, e);
            }, h.isEmpty = function(t) {
                return null == t || (y(t) && (h.isArray(t) || h.isString(t) || h.isArguments(t)) ? 0 === t.length : 0 === h.keys(t).length);
            }, h.isElement = function(t) {
                return !(!t || 1 !== t.nodeType);
            }, h.isArray = o || function(t) {
                return "[object Array]" === f.call(t);
            }, h.isObject = function(t) {
                var e = void 0 === t ? "undefined" : F(t);
                return "function" === e || "object" === e && !!t;
            }, h.each([ "Arguments", "Function", "String", "Number", "Date", "RegExp", "Error" ], function(e) {
                h["is" + e] = function(t) {
                    return f.call(t) === "[object " + e + "]";
                };
            }), h.isArguments(arguments) || (h.isArguments = function(t) {
                return h.has(t, "callee");
            }), "object" != ("undefined" == typeof Int8Array ? "undefined" : F(Int8Array)) && (h.isFunction = function(t) {
                return "function" == typeof t || !1;
            }), h.isFinite = function(t) {
                return isFinite(t) && !isNaN(parseFloat(t));
            }, h.isNaN = function(t) {
                return h.isNumber(t) && t !== +t;
            }, h.isBoolean = function(t) {
                return !0 === t || !1 === t || "[object Boolean]" === f.call(t);
            }, h.isNull = function(t) {
                return null === t;
            }, h.isUndefined = function(t) {
                return void 0 === t;
            }, h.has = function(t, e) {
                return null != t && n.call(t, e);
            }, h.noConflict = function() {
                return root._ = previousUnderscore, this;
            }, h.identity = function(t) {
                return t;
            }, h.constant = function(t) {
                return function() {
                    return t;
                };
            }, h.noop = function() {}, h.property = function(e) {
                return function(t) {
                    return null == t ? void 0 : t[e];
                };
            }, h.propertyOf = function(e) {
                return null == e ? function() {} : function(t) {
                    return e[t];
                };
            }, h.matcher = h.matches = function(e) {
                return e = h.extendOwn({}, e), function(t) {
                    return h.isMatch(t, e);
                };
            }, h.times = function(t, e, n) {
                var r = Array(Math.max(0, t));
                e = p(e, n, 1);
                for (var i = 0; i < t; i++) r[i] = e(i);
                return r;
            }, h.random = function(t, e) {
                return null == e && (e = t, t = 0), t + Math.floor(Math.random() * (e - t + 1));
            }, h.now = Date.now || function() {
                return new Date().getTime();
            };
            t = {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#x27;",
                "`": "&#x60;"
            }, v = h.invert(t), o = function(e) {
                function n(t) {
                    return e[t];
                }
                var t = "(?:" + h.keys(e).join("|") + ")", r = RegExp(t), i = RegExp(t, "g");
                return function(t) {
                    return t = null == t ? "" : "" + t, r.test(t) ? t.replace(i, n) : t;
                };
            };
            h.escape = o(t), h.unescape = o(v), h.result = function(t, e, n) {
                e = null == t ? void 0 : t[e];
                return void 0 === e && (e = n), h.isFunction(e) ? e.call(t) : e;
            };
            var T = 0;
            h.uniqueId = function(t) {
                var e = ++T + "";
                return t ? t + e : e;
            }, h.templateSettings = {
                evaluate: /<%([\s\S]+?)%>/g,
                interpolate: /<%=([\s\S]+?)%>/g,
                escape: /<%-([\s\S]+?)%>/g
            };
            function k(t) {
                return "\\" + D[t];
            }
            var O = /(.)^/, D = {
                "'": "'",
                "\\": "\\",
                "\r": "r",
                "\n": "n",
                "\u2028": "u2028",
                "\u2029": "u2029"
            }, M = /\\|'|\r|\n|\u2028|\u2029/g;
            h.template = function(o, t, e) {
                !t && e && (t = e), t = h.defaults({}, t, h.templateSettings);
                var n = RegExp([ (t.escape || O).source, (t.interpolate || O).source, (t.evaluate || O).source ].join("|") + "|$", "g"), a = 0, s = "__p+='";
                o.replace(n, function(t, e, n, r, i) {
                    return s += o.slice(a, i).replace(M, k), a = i + t.length, e ? s += "'+\n((__t=(" + e + "))==null?'':_.escape(__t))+\n'" : n ? s += "'+\n((__t=(" + n + "))==null?'':__t)+\n'" : r && (s += "';\n" + r + "\n__p+='"), 
                    t;
                }), s += "';\n", t.variable || (s = "with(obj||{}){\n" + s + "}\n"), s = "var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};\n" + s + "return __p;\n";
                try {
                    var r = new Function(t.variable || "obj", "_", s);
                } catch (t) {
                    throw t.source = s, t;
                }
                e = function(t) {
                    return r.call(this, t, h);
                }, n = t.variable || "obj";
                return e.source = "function(" + n + "){\n" + s + "}", e;
            }, h.chain = function(t) {
                t = h(t);
                return t._chain = !0, t;
            };
            function C(t, e) {
                return t._chain ? h(e).chain() : e;
            }
            (h.mixin = function(n) {
                h.each(h.functions(n), function(t) {
                    var e = h[t] = n[t];
                    h.prototype[t] = function() {
                        var t = [ this._wrapped ];
                        return i.apply(t, arguments), C(this, e.apply(h, t));
                    };
                });
            })(h), h.each([ "pop", "push", "reverse", "shift", "sort", "splice", "unshift" ], function(e) {
                var n = r[e];
                h.prototype[e] = function() {
                    var t = this._wrapped;
                    return n.apply(t, arguments), "shift" !== e && "splice" !== e || 0 !== t.length || delete t[0], 
                    C(this, t);
                };
            }), h.each([ "concat", "join", "slice" ], function(t) {
                var e = r[t];
                h.prototype[t] = function() {
                    return C(this, e.apply(this._wrapped, arguments));
                };
            }), h.prototype.valueOf = h.prototype.toJSON = h.prototype.value = function() {
                return this._wrapped;
            }, h.prototype.toString = function() {
                return "" + this._wrapped;
            };
        }).call(void 0);
    },
    c8ba: function(t, e) {
        var n = function() {
            return this;
        }();
        try {
            n = n || new Function("return this")();
        } catch (t) {
            "object" === ("undefined" == typeof window ? "undefined" : _typeof(window)) && (n = window);
        }
        t.exports = n;
    },
    f0c5: function(t, e, n) {
        function r(t, e, n, r, i, o, a, s, l, c) {
            var u, h, f = "function" == typeof t ? t.options : t;
            if (l) {
                f.components || (f.components = {});
                var p, d = Object.prototype.hasOwnProperty;
                for (p in l) d.call(l, p) && !d.call(f.components, p) && (f.components[p] = l[p]);
            }
            return c && ((c.beforeCreate || (c.beforeCreate = [])).unshift(function() {
                this[c.__module] = this;
            }), (f.mixins || (f.mixins = [])).push(c)), e && (f.render = e, f.staticRenderFns = n, 
            f._compiled = !0), r && (f.functional = !0), o && (f._scopeId = "data-v-" + o), 
            a ? (u = function(t) {
                (t = t || this.$vnode && this.$vnode.ssrContext || this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext) || "undefined" == typeof __VUE_SSR_CONTEXT__ || (t = __VUE_SSR_CONTEXT__), 
                i && i.call(this, t), t && t._registeredComponents && t._registeredComponents.add(a);
            }, f._ssrRegister = u) : i && (u = s ? function() {
                i.call(this, this.$root.$options.shadowRoot);
            } : i), u && (f.functional ? (f._injectStyles = u, h = f.render, f.render = function(t, e) {
                return u.call(e), h(t, e);
            }) : (s = f.beforeCreate, f.beforeCreate = s ? [].concat(s, u) : [ u ])), {
                exports: t,
                options: f
            };
        }
        n.d(e, "a", function() {
            return r;
        });
    },
    f6b2: function(t, e) {}
} ]);