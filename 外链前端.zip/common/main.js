(global.webpackJsonp = global.webpackJsonp || []).push([ [ "common/main" ], {
    2760: function(e, t, c) {
        (function(e) {
            c("f6b2");
            var t = r(c("66fd")), n = r(c("60be")), o = r(c("3a75"));
            function r(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function u(t, e) {
                var n, o = Object.keys(t);
                return Object.getOwnPropertySymbols && (n = Object.getOwnPropertySymbols(t), e && (n = n.filter(function(e) {
                    return Object.getOwnPropertyDescriptor(t, e).enumerable;
                })), o.push.apply(o, n)), o;
            }
            t.default.config.productionTip = !1, n.default.mpType = "app", t.default.prototype.util = o.default, 
            t.default.prototype.$version = "1.4.0", e(new t.default(function(o) {
                for (var e = 1; e < arguments.length; e++) {
                    var r = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? u(Object(r), !0).forEach(function(e) {
                        var t, n;
                        t = o, e = r[n = e], n in t ? Object.defineProperty(t, n, {
                            value: e,
                            enumerable: !0,
                            configurable: !0,
                            writable: !0
                        }) : t[n] = e;
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(o, Object.getOwnPropertyDescriptors(r)) : u(Object(r)).forEach(function(e) {
                        Object.defineProperty(o, e, Object.getOwnPropertyDescriptor(r, e));
                    });
                }
                return o;
            }({}, n.default))).$mount();
        }).call(this, c("543d").createApp);
    },
    "5e87": function(e, t, n) {
        var o = n("7393");
        n.n(o).a;
    },
    "60be": function(e, t, n) {
        n.r(t);
        var o, r = n("fc67");
        for (o in r) "default" !== o && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(o);
        n("5e87");
        var u = n("f0c5"), u = Object(u.a)(r.default, void 0, void 0, !1, null, null, null, !1, void 0, void 0);
        t.default = u.exports;
    },
    7393: function(e, t, n) {},
    9785: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var o = {
            onLaunch: function() {
                console.log("App Launch");
            },
            onShow: function() {
                console.log("App Show");
            },
            onHide: function() {
                console.log("App Hide");
            }
        };
        t.default = o;
    },
    fc67: function(e, t, n) {
        n.r(t);
        var o, r = n("9785"), u = n.n(r);
        for (o in r) "default" !== o && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(o);
        t.default = u.a;
    }
}, [ [ "2760", "common/runtime", "common/vendor" ] ] ]);