module.exports = {
    name: "智慧外链接助手",
    uniacid: "2",
    acid: "2",
    multiid: "0",
    version: "1.4.0",
    siteroot: "https://wl.shengxiakj.cn/app/index.php"
};