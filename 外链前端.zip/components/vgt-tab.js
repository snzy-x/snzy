(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/vgt-tab" ], {
    5036: function(t, n, e) {
        (function(e) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var t = {
                props: {
                    list: {
                        type: Object,
                        required: !0,
                        default: function() {
                            return {};
                        }
                    },
                    itemStyleDefault: {
                        type: Object,
                        default: function() {
                            return {};
                        }
                    },
                    itemStyleActive: {
                        type: Object,
                        default: function() {
                            return {};
                        }
                    },
                    zIndex: {
                        type: [ String, Number ],
                        default: 1e3
                    }
                },
                data: function() {
                    return {
                        scrollViewLeftArr: new Map(),
                        choseInd: "小程序",
                        position: 0,
                        windowWidth: 0,
                        isShowList: !1
                    };
                },
                computed: {
                    getDefaultStyle: function() {
                        var t = this.itemStyleDefault;
                        return this.setStyle({
                            color: "#393939",
                            background: "#ececec"
                        }, t);
                    },
                    getActiveStyle: function() {
                        var t = this.itemStyleActive;
                        return this.setStyle({
                            color: "#fff",
                            background: "#3555fc"
                        }, t);
                    }
                },
                mounted: function() {
                    var n = this;
                    e.getSystemInfo({
                        success: function(t) {
                            t = t.windowWidth;
                            n.windowWidth = t;
                        }
                    });
                    var t = e.createSelectorQuery().in(this);
                    t.selectAll(".scroll-view-item").boundingClientRect(), t.exec(function(t) {
                        t[0].forEach(function(t) {
                            var e = t.dataset.item, t = {
                                name: e,
                                left: t.left
                            };
                            n.scrollViewLeftArr.set(e, t);
                        });
                    });
                },
                methods: {
                    onClickListItem: function(t, e) {
                        this.isShowList = !1;
                        var n = e.currentTarget.dataset.item, e = this.scrollViewLeftArr.get(n);
                        this.position = e.left - (this.windowWidth / 2 - 30), this.choseInd = t, this.$emit("onValueChange", n);
                    },
                    onClickScrollItem: function(t, e) {
                        this.choseInd = t;
                        t = e.currentTarget.dataset.item, e = e.target.offsetLeft;
                        console.log(this.windowWidth, "this.windowWidth"), this.position = e - (this.windowWidth / 2 - 30), 
                        this.$emit("onValueChange", t);
                    },
                    setStyle: function(e, t) {
                        Object.assign(e, t);
                        var n = "";
                        return Object.keys(e).forEach(function(t) {
                            n += "".concat(t, ": ").concat(e[t], ";");
                        }), n;
                    }
                }
            };
            n.default = t;
        }).call(this, e("543d").default);
    },
    "6aaf": function(t, e, n) {
        n.r(e);
        var o, i = n("5036"), c = n.n(i);
        for (o in i) "default" !== o && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(o);
        e.default = c.a;
    },
    dac1: function(t, e, n) {
        n.d(e, "b", function() {
            return o;
        }), n.d(e, "c", function() {
            return i;
        }), n.d(e, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, i = [];
    },
    e1d5: function(t, e, n) {},
    e41c: function(t, e, n) {
        var o = n("e1d5");
        n.n(o).a;
    },
    f2f1: function(t, e, n) {
        n.r(e);
        var o, i = n("dac1"), c = n("6aaf");
        for (o in c) "default" !== o && function(t) {
            n.d(e, t, function() {
                return c[t];
            });
        }(o);
        n("e41c");
        var a = n("f0c5"), i = Object(a.a)(c.default, i.b, i.c, !1, null, "08531568", null, !1, i.a, void 0);
        e.default = i.exports;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/vgt-tab-create-component", {
    "components/vgt-tab-create-component": function(t, e, n) {
        n("543d").createComponent(n("f2f1"));
    }
}, [ [ "components/vgt-tab-create-component" ] ] ]);