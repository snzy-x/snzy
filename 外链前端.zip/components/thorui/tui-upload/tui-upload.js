(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/thorui/tui-upload/tui-upload" ], {
    "08f7": function(t, e, n) {
        n.r(e);
        var i, r = n("4636"), a = n.n(r);
        for (i in r) "default" !== i && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(i);
        e.default = a.a;
    },
    "302a": function(t, e, n) {
        n.d(e, "b", function() {
            return i;
        }), n.d(e, "c", function() {
            return r;
        }), n.d(e, "a", function() {});
        var i = function() {
            this.$createElement;
            this._self._c;
        }, r = [];
    },
    4636: function(t, e, n) {
        (function(o) {
            function n(t) {
                return function(t) {
                    if (Array.isArray(t)) return i(t);
                }(t) || function(t) {
                    if ("undefined" != typeof Symbol && Symbol.iterator in Object(t)) return Array.from(t);
                }(t) || u(t) || function() {
                    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                }();
            }
            function u(t, e) {
                if (t) {
                    if ("string" == typeof t) return i(t, e);
                    var n = Object.prototype.toString.call(t).slice(8, -1);
                    return "Object" === n && t.constructor && (n = t.constructor.name), "Map" === n || "Set" === n ? Array.from(t) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? i(t, e) : void 0;
                }
            }
            function i(t, e) {
                (null == e || e > t.length) && (e = t.length);
                for (var n = 0, i = new Array(e); n < e; n++) i[n] = t[n];
                return i;
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var t = {
                name: "tuiUpload",
                props: {
                    value: {
                        type: Array,
                        default: function() {
                            return [];
                        }
                    },
                    forbidDel: {
                        type: Boolean,
                        default: !1
                    },
                    forbidAdd: {
                        type: Boolean,
                        default: !1
                    },
                    serverUrl: {
                        type: String,
                        default: ""
                    },
                    limit: {
                        type: Number,
                        default: 9
                    },
                    sizeType: {
                        type: Array,
                        default: function() {
                            return [ "original", "compressed" ];
                        }
                    },
                    sourceType: {
                        type: Array,
                        default: function() {
                            return [ "album", "camera" ];
                        }
                    },
                    imageFormat: {
                        type: Array,
                        default: function() {
                            return [];
                        }
                    },
                    size: {
                        type: Number,
                        default: 4
                    },
                    fileKeyName: {
                        type: String,
                        default: "file"
                    },
                    header: {
                        type: Object,
                        default: function() {
                            return {};
                        }
                    },
                    formData: {
                        type: Object,
                        default: function() {
                            return {};
                        }
                    }
                },
                data: function() {
                    return {
                        imageList: [],
                        statusArr: [],
                        siteroot: ""
                    };
                },
                created: function() {
                    this.initImages();
                },
                watch: {
                    value: function(t) {
                        t && this.initImages();
                    }
                },
                computed: {
                    isShowAdd: function() {
                        var t = !0;
                        return (this.forbidAdd || this.limit && this.imageList.length >= this.limit) && (t = !1), 
                        t;
                    }
                },
                methods: {
                    initImages: function() {
                        this.imageList = n(this.value);
                        var t, e = function(t, e) {
                            var n;
                            if ("undefined" == typeof Symbol || null == t[Symbol.iterator]) {
                                if (Array.isArray(t) || (n = u(t)) || e && t && "number" == typeof t.length) {
                                    n && (t = n);
                                    var i = 0, e = function() {};
                                    return {
                                        s: e,
                                        n: function() {
                                            return i >= t.length ? {
                                                done: !0
                                            } : {
                                                done: !1,
                                                value: t[i++]
                                            };
                                        },
                                        e: function(t) {
                                            throw t;
                                        },
                                        f: e
                                    };
                                }
                                throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                            }
                            var r, a = !0, o = !1;
                            return {
                                s: function() {
                                    n = t[Symbol.iterator]();
                                },
                                n: function() {
                                    var t = n.next();
                                    return a = t.done, t;
                                },
                                e: function(t) {
                                    o = !0, r = t;
                                },
                                f: function() {
                                    try {
                                        a || null == n.return || n.return();
                                    } finally {
                                        if (o) throw r;
                                    }
                                }
                            };
                        }(this.imageList);
                        try {
                            for (e.s(); !(t = e.n()).done; ) t.value, this.statusArr.push("1");
                        } catch (t) {
                            e.e(t);
                        } finally {
                            e.f();
                        }
                    },
                    reUpLoad: function(t) {
                        var e = this;
                        this.$set(this.statusArr, t, "2"), this.change(), this.uploadImage(t, this.imageList[t]).then(function() {
                            e.change();
                        }).catch(function() {
                            e.change();
                        });
                    },
                    change: function() {
                        var t = ~this.statusArr.indexOf("2") ? 2 : 1;
                        2 != t && ~this.statusArr.indexOf("3") ? t = 3 : this.$emit("complete", {
                            status: t,
                            imgArr: this.imageList
                        });
                    },
                    toast: function(t) {
                        t && o.showToast({
                            title: t,
                            icon: "none"
                        });
                    },
                    chooseImage: function() {
                        var c = this;
                        o.chooseImage({
                            count: c.limit - c.imageList.length,
                            sizeType: c.sizeType,
                            sourceType: c.sourceType,
                            success: function(t) {
                                for (var e = [], n = 0; n < t.tempFiles.length; n++) {
                                    if (c.imageList.length >= c.limit) {
                                        c.toast("最多可上传".concat(c.limit, "张图片"));
                                        break;
                                    }
                                    var i = t.tempFiles[n].path;
                                    if (0 < c.imageFormat.length) {
                                        var r = i.split(".")[i.split(".").length - 1];
                                        if (-1 == c.imageFormat.indexOf(r)) {
                                            var a = "只能上传 ".concat(c.imageFormat.join(","), " 格式图片！");
                                            c.toast(a);
                                            continue;
                                        }
                                    }
                                    a = t.tempFiles[n].size;
                                    1024 * c.size * 1024 < a ? (a = "单张图片大小不能超过：".concat(c.size, "MB"), c.toast(a)) : (e.push(i), 
                                    c.imageList.push(i), c.statusArr.push("2"));
                                }
                                c.change();
                                for (var o = c.imageList.length - e.length, u = 0; u < e.length; u++) {
                                    var s = o + u;
                                    c.serverUrl ? c.uploadImage(s, e[u]).then(function() {
                                        c.change();
                                    }).catch(function() {
                                        c.change();
                                    }) : (c.$set(c.statusArr, s, "1"), c.change());
                                }
                            }
                        });
                    },
                    uploadImage: function(i, t) {
                        var r = this, a = this;
                        return this.siteroot = "", new Promise(function(e, n) {
                            o.uploadFile({
                                url: r.serverUrl,
                                name: r.fileKeyName,
                                header: r.header,
                                formData: r.formData,
                                filePath: t,
                                success: function(t) {
                                    200 == t.statusCode ? (t = JSON.parse(t.data.replace(/\ufeff/g, "") || "{}"), console.log(t), 
                                    t.success ? (a.siteroot = t.url, t.path && (a.imageList[i] = t.path), a.$set(a.statusArr, i, t.path ? "1" : "3")) : (t.message && a.toast(t.message), 
                                    a.$set(a.statusArr, i, "3")), e(i)) : (a.$set(a.statusArr, i, "3"), n(i));
                                },
                                fail: function(t) {
                                    a.$set(a.statusArr, i, "3"), n(i);
                                }
                            });
                        });
                    },
                    delImage: function(t) {
                        this.imageList.splice(t, 1), this.statusArr.splice(t, 1), this.$emit("remove", {
                            index: t
                        }), this.change();
                    },
                    previewImage: function(t) {
                        this.imageList.length && o.previewImage({
                            current: this.imageList[t],
                            loop: !0,
                            urls: this.imageList
                        });
                    }
                }
            };
            e.default = t;
        }).call(this, n("543d").default);
    },
    "84ee": function(t, e, n) {},
    "87ec": function(t, e, n) {
        var i = n("84ee");
        n.n(i).a;
    },
    8970: function(t, e, n) {
        n.r(e);
        var i, r = n("302a"), a = n("08f7");
        for (i in a) "default" !== i && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(i);
        n("87ec");
        var o = n("f0c5"), r = Object(o.a)(a.default, r.b, r.c, !1, null, "2479648c", null, !1, r.a, void 0);
        e.default = r.exports;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/thorui/tui-upload/tui-upload-create-component", {
    "components/thorui/tui-upload/tui-upload-create-component": function(t, e, n) {
        n("543d").createComponent(n("8970"));
    }
}, [ [ "components/thorui/tui-upload/tui-upload-create-component" ] ] ]);