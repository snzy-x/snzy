(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/thorui/tui-tips/tui-tips" ], {
    "1d91": function(t, n, e) {
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var i = {
            name: "tuiTips",
            props: {
                position: {
                    type: String,
                    default: "top"
                }
            },
            data: function() {
                return {
                    timer: null,
                    show: !1,
                    msg: "无法连接到服务器~",
                    type: "translucent"
                };
            },
            methods: {
                showTips: function(t) {
                    var n = this, e = t.type, i = void 0 === e ? "translucent" : e, e = t.duration, e = void 0 === e ? 2e3 : e;
                    clearTimeout(this.timer), this.show = !0, this.type = i, this.msg = t.msg, this.timer = setTimeout(function() {
                        n.show = !1, clearTimeout(n.timer), n.timer = null;
                    }, e);
                }
            }
        };
        n.default = i;
    },
    "2ae8": function(t, n, e) {
        var i = e("498b");
        e.n(i).a;
    },
    "498b": function(t, n, e) {},
    "97bb": function(t, n, e) {
        e.d(n, "b", function() {
            return i;
        }), e.d(n, "c", function() {
            return o;
        }), e.d(n, "a", function() {});
        var i = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
    },
    9803: function(t, n, e) {
        e.r(n);
        var i, o = e("97bb"), u = e("9b6e");
        for (i in u) "default" !== i && function(t) {
            e.d(n, t, function() {
                return u[t];
            });
        }(i);
        e("2ae8");
        var c = e("f0c5"), o = Object(c.a)(u.default, o.b, o.c, !1, null, "5d9329fc", null, !1, o.a, void 0);
        n.default = o.exports;
    },
    "9b6e": function(t, n, e) {
        e.r(n);
        var i, o = e("1d91"), u = e.n(o);
        for (i in o) "default" !== i && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(i);
        n.default = u.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/thorui/tui-tips/tui-tips-create-component", {
    "components/thorui/tui-tips/tui-tips-create-component": function(t, n, e) {
        e("543d").createComponent(e("9803"));
    }
}, [ [ "components/thorui/tui-tips/tui-tips-create-component" ] ] ]);