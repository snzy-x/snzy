(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/thorui/tui-badge/tui-badge" ], {
    2463: function(t, e, n) {
        var a = n("a7cd");
        n.n(a).a;
    },
    a7cd: function(t, e, n) {},
    aeea: function(t, e, n) {
        n.d(e, "b", function() {
            return a;
        }), n.d(e, "c", function() {
            return o;
        }), n.d(e, "a", function() {});
        var a = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
    },
    b386: function(t, e, n) {
        n.r(e);
        var a, o = n("aeea"), u = n("e225");
        for (a in u) "default" !== a && function(t) {
            n.d(e, t, function() {
                return u[t];
            });
        }(a);
        n("2463");
        var c = n("f0c5"), o = Object(c.a)(u.default, o.b, o.c, !1, null, "5eb90b82", null, !1, o.a, void 0);
        e.default = o.exports;
    },
    cde7: function(t, e, n) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var a = {
            name: "tuiBadge",
            props: {
                type: {
                    type: String,
                    default: "primary"
                },
                dot: {
                    type: Boolean,
                    default: !1
                },
                margin: {
                    type: String,
                    default: "0"
                },
                absolute: {
                    type: Boolean,
                    default: !1
                },
                top: {
                    type: String,
                    default: "-8rpx"
                },
                right: {
                    type: String,
                    default: "0"
                },
                scaleRatio: {
                    type: Number,
                    default: 1
                },
                translateX: {
                    type: String,
                    default: "0"
                }
            },
            computed: {
                getStyle: function() {
                    return "scale(".concat(this.scaleRatio, ") translateX(").concat(this.translateX, ")");
                }
            },
            methods: {
                handleClick: function() {
                    this.$emit("click", {});
                }
            }
        };
        e.default = a;
    },
    e225: function(t, e, n) {
        n.r(e);
        var a, o = n("cde7"), u = n.n(o);
        for (a in o) "default" !== a && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(a);
        e.default = u.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/thorui/tui-badge/tui-badge-create-component", {
    "components/thorui/tui-badge/tui-badge-create-component": function(t, e, n) {
        n("543d").createComponent(n("b386"));
    }
}, [ [ "components/thorui/tui-badge/tui-badge-create-component" ] ] ]);