(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/thorui/tui-icon/tui-icon" ], {
    "20de": function(n, t, e) {
        e.r(t);
        var o, i = e("e2e0"), u = e.n(i);
        for (o in i) "default" !== o && function(n) {
            e.d(t, n, function() {
                return i[n];
            });
        }(o);
        t.default = u.a;
    },
    "5fcd": function(n, t, e) {},
    "766e": function(n, t, e) {
        var o = e("5fcd");
        e.n(o).a;
    },
    "8a4d": function(n, t, e) {
        e.r(t);
        var o, i = e("fbfa"), u = e("20de");
        for (o in u) "default" !== o && function(n) {
            e.d(t, n, function() {
                return u[n];
            });
        }(o);
        e("766e");
        var c = e("f0c5"), i = Object(c.a)(u.default, i.b, i.c, !1, null, "668a7627", null, !1, i.a, void 0);
        t.default = i.exports;
    },
    e2e0: function(n, t, e) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var o = {
            name: "tuiIcon",
            props: {
                name: {
                    type: String,
                    default: ""
                },
                size: {
                    type: Number,
                    default: 32
                },
                unit: {
                    type: String,
                    default: "px"
                },
                color: {
                    type: String,
                    default: "#999"
                },
                bold: {
                    type: Boolean,
                    default: !1
                },
                margin: {
                    type: String,
                    default: "0"
                },
                index: {
                    type: Number,
                    default: 0
                }
            },
            methods: {
                handleClick: function() {
                    this.$emit("click", {
                        index: this.index
                    });
                }
            }
        };
        t.default = o;
    },
    fbfa: function(n, t, e) {
        e.d(t, "b", function() {
            return o;
        }), e.d(t, "c", function() {
            return i;
        }), e.d(t, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, i = [];
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/thorui/tui-icon/tui-icon-create-component", {
    "components/thorui/tui-icon/tui-icon-create-component": function(n, t, e) {
        e("543d").createComponent(e("8a4d"));
    }
}, [ [ "components/thorui/tui-icon/tui-icon-create-component" ] ] ]);