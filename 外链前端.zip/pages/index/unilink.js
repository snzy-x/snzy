(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/index/unilink" ], {
    "0704": function(t, a, n) {},
    3766: function(t, a, n) {
        (function(t) {
            function a(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            n("f6b2"), a(n("66fd")), t(a(n("dbb5")).default);
        }).call(this, n("543d").createPage);
    },
    cd77: function(t, a, n) {
        n.r(a);
        var e, i = n("e705"), d = n.n(i);
        for (e in i) "default" !== e && function(t) {
            n.d(a, t, function() {
                return i[t];
            });
        }(e);
        a.default = d.a;
    },
    ce42: function(t, a, n) {
        var e = n("0704");
        n.n(e).a;
    },
    dbb5: function(t, a, n) {
        n.r(a);
        var e, i = n("fbd4"), d = n("cd77");
        for (e in d) "default" !== e && function(t) {
            n.d(a, t, function() {
                return d[t];
            });
        }(e);
        n("ce42");
        var u = n("f0c5"), i = Object(u.a)(d.default, i.b, i.c, !1, null, null, null, !1, i.a, void 0);
        a.default = i.exports;
    },
    e705: function(t, n, a) {
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var a = {
                data: function() {
                    return {
                        linkid: 0,
                        btnTitle: "",
                        path: "",
                        linkDetail: {},
                        headerImg: "",
                        messageImg: "../../static/images/clickme.png",
                        text: "",
                        type: ""
                    };
                },
                onLoad: function(t) {
                    console.log(t), t.linkid && (this.linkid = t.linkid, this.getLinkDetail());
                },
                methods: {
                    handleContact: function(t) {},
                    getLinkDetail: function() {
                        var a = this;
                        this.util.request({
                            url: "entry/wxapp/uniPage",
                            data: {
                                id: a.linkid
                            },
                            success: function(t) {
                                a.linkDetail = t.data.data, t.data.data.btn_title ? a.btnTitle = t.data.data.btn_title : a.btnTitle = "立刻获取" + t.data.data.type + "信息", 
                                t.data.data.advmessageimg && (a.messageImg = t.data.data.advmessageimg), t.data.data.advapptop ? a.headerImg = t.data.data.advapptop : a.headerImg = "../../static/images/header.png", 
                                t.data.data.advapptext ? a.text = t.data.data.advapptext : a.text = "最专业的智慧外链系统\n引流五湖四海，跳转四面八方", 
                                a.type = t.data.data.type, a.path = t.data.data.path + "?" + t.data.data.query;
                            }
                        });
                    },
                    goWxapp: function() {
                        t.navigateToMiniProgram({
                            appId: this.linkDetail.wxapp.appid,
                            path: this.path
                        });
                    }
                }
            };
            n.default = a;
        }).call(this, a("543d").default);
    },
    fbd4: function(t, a, n) {
        n.d(a, "b", function() {
            return e;
        }), n.d(a, "c", function() {
            return i;
        }), n.d(a, "a", function() {});
        var e = function() {
            this.$createElement;
            this._self._c;
        }, i = [];
    }
}, [ [ "3766", "common/runtime", "common/vendor" ] ] ]);