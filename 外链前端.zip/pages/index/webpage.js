(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/index/webpage" ], {
    "03a5": function(n, t, e) {
        e.r(t);
        var a, u = e("a5f1"), i = e("aac2");
        for (a in i) "default" !== a && function(n) {
            e.d(t, n, function() {
                return i[n];
            });
        }(a);
        e("a97d");
        var o = e("f0c5"), u = Object(o.a)(i.default, u.b, u.c, !1, null, null, null, !1, u.a, void 0);
        t.default = u.exports;
    },
    "13b3": function(n, t, e) {
        (function(n) {
            function t(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            e("f6b2"), t(e("66fd")), n(t(e("03a5")).default);
        }).call(this, e("543d").createPage);
    },
    2199: function(n, t, e) {},
    a5f1: function(n, t, e) {
        e.d(t, "b", function() {
            return a;
        }), e.d(t, "c", function() {
            return u;
        }), e.d(t, "a", function() {});
        var a = function() {
            this.$createElement;
            this._self._c;
        }, u = [];
    },
    a97d: function(n, t, e) {
        var a = e("2199");
        e.n(a).a;
    },
    aac2: function(n, t, e) {
        e.r(t);
        var a, u = e("dc56"), i = e.n(u);
        for (a in u) "default" !== a && function(n) {
            e.d(t, n, function() {
                return u[n];
            });
        }(a);
        t.default = i.a;
    },
    dc56: function(n, t, e) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var a = {
            data: function() {
                return {
                    linkid: 0,
                    url: ""
                };
            },
            onLoad: function(n) {
                n.linkid ? (this.linkid = n.linkid, this.getLinkDetail()) : this.url = decodeURIComponent(n.url);
            },
            methods: {
                getLinkDetail: function() {
                    var t = this;
                    this.util.request({
                        url: "entry/wxapp/uniPage",
                        data: {
                            id: t.linkid
                        },
                        success: function(n) {
                            t.url = n.data.data.return;
                        }
                    });
                }
            }
        };
        t.default = a;
    }
}, [ [ "13b3", "common/runtime", "common/vendor" ] ] ]);