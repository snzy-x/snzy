(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/index/premiums" ], {
    "4b33": function(t, n, e) {
        (function(t) {
            function n(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            e("f6b2"), n(e("66fd")), t(n(e("ea3f")).default);
        }).call(this, e("543d").createPage);
    },
    "4f8c": function(t, n, i) {
        (function(o) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var e = i("14a6"), t = {
                data: function() {
                    return {
                        id: 0,
                        tabid: 0,
                        cdkey: "",
                        type: "",
                        premiums: {
                            free: [],
                            vip: [],
                            isvip: !1,
                            vipstatus: "",
                            contact: ""
                        },
                        videoAd: !1,
                        promotion: {}
                    };
                },
                onLoad: function(t) {
                    t.id ? this.id = t.id : t.type && (this.type = t.type), this.getPremiums();
                },
                methods: {
                    changeTab: function(t) {
                        that.navIdx = t;
                    },
                    showcontact: function() {
                        var n = this;
                        this.premiums.contact ? o.showModal({
                            title: "联系方式",
                            content: this.premiums.contact,
                            confirmText: "复制",
                            cancelText: "取消",
                            success: function(t) {
                                t.confirm && e.getClipboardData(n.premiums.contact, function(t) {
                                    t && o.showToast({
                                        icon: "success",
                                        title: "已复制"
                                    });
                                });
                            }
                        }) : o.showToast({
                            icon: "none",
                            title: "敬请期待"
                        });
                    },
                    getPremiums: function() {
                        var n = this;
                        this.util.request({
                            url: "entry/wxapp/getPremiums",
                            data: {},
                            success: function(t) {
                                n.premiums = t.data.data, o.setStorageSync("isvip", t.data.data.isvip), o.setStorageSync("personal_domain", t.data.data.personal_domain);
                                t = o.getStorageSync("config");
                                o.getStorageSync("isvip") && !t.promotion.vipvideo || n.initAd(t);
                            }
                        });
                    },
                    initAd: function(t) {
                        var e = this;
                        if (!t.promotion.create) return !1;
                        var i = this;
                        t.promotion.create && wx.createRewardedVideoAd && (this.videoAd = wx.createRewardedVideoAd({
                            adUnitId: t.promotion.create
                        }), this.videoAd.onLoad(function() {}), this.videoAd.onError(function(t) {}), this.videoAd.onClose(function(t) {
                            var n;
                            t.isEnded ? (o.showLoading({
                                title: "获取结果中"
                            }), setTimeout(function() {
                                o.hideLoading(), o.showModal({
                                    title: "恭喜您可以创建外链啦",
                                    content: "立即点击确定按钮前往创建外链页面吧！",
                                    success: function(t) {
                                        if (t.confirm) return i.id ? o.navigateTo({
                                            url: "./addlink?id=" + i.id
                                        }) : "公众号文章" == e.type ? o.navigateTo({
                                            url: "./addurllink?type=" + e.type
                                        }) : i.type ? o.navigateTo({
                                            url: "./addunilink?type=" + i.type
                                        }) : o.switchTab({
                                            url: "/pages/index/index"
                                        }), !0;
                                    },
                                    showCancel: !1
                                });
                            }, 1e3)) : (console.log("观看视频失败"), n = e, o.showModal({
                                title: "就差一点啦",
                                content: "完整看完广告才可以哟，重看一遍吧",
                                success: function(t) {
                                    t.confirm && n.videoAd.show().catch(function() {
                                        n.videoAd.load().then(function() {
                                            return n.videoAd.show();
                                        }).catch(function(t) {
                                            console.log("激励视频 广告显示失败");
                                        });
                                    });
                                }
                            }));
                        }));
                    },
                    addlink: function() {
                        if (console.log(this.videoAd), !this.videoAd) return this.id ? o.navigateTo({
                            url: "./addlink?id=" + this.id
                        }) : "公众号文章" == this.type ? o.navigateTo({
                            url: "./addurllink?type=" + this.type
                        }) : this.type ? o.navigateTo({
                            url: "./addunilink?type=" + this.type
                        }) : o.switchTab({
                            url: "/pages/index/index"
                        }), !0;
                        var n = this;
                        o.showModal({
                            title: "就剩一步啦",
                            content: "观看完一段简短广告后，即可免费创建外链!",
                            success: function(t) {
                                t.confirm && n.videoAd.show().catch(function() {
                                    n.videoAd.load().then(function() {
                                        return n.videoAd.show();
                                    }).catch(function(t) {
                                        console.log("激励视频 广告显示失败");
                                    });
                                });
                            }
                        });
                    },
                    checkcdkey: function() {
                        var n = this;
                        this.util.request({
                            url: "entry/wxapp/checkCdkey",
                            data: {
                                cdkey: n.cdkey
                            },
                            success: function(t) {
                                o.showToast({
                                    icon: "none",
                                    title: t.data.message
                                }), n.cdkey = "", setTimeout(n.getPremiums, 1e3);
                            }
                        });
                    }
                }
            };
            n.default = t;
        }).call(this, i("543d").default);
    },
    "520b": function(t, n, e) {},
    "533a": function(t, n, e) {
        var i = e("520b");
        e.n(i).a;
    },
    "61a1": function(t, n, e) {
        e.r(n);
        var i, o = e("4f8c"), a = e.n(o);
        for (i in o) "default" !== i && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(i);
        n.default = a.a;
    },
    bac2: function(t, n, e) {
        e.d(n, "b", function() {
            return o;
        }), e.d(n, "c", function() {
            return a;
        }), e.d(n, "a", function() {
            return i;
        });
        var i = {
            tuiBadge: function() {
                return e.e("components/thorui/tui-badge/tui-badge").then(e.bind(null, "b386"));
            },
            tuiButton: function() {
                return e.e("components/thorui/tui-button/tui-button").then(e.bind(null, "e9bf"));
            }
        }, o = function() {
            var n = this;
            n.$createElement;
            n._self._c, n._isMounted || (n.e0 = function(t) {
                n.tabid = 0;
            }, n.e1 = function(t) {
                n.tabid = 1;
            });
        }, a = [];
    },
    ea3f: function(t, n, e) {
        e.r(n);
        var i, o = e("bac2"), a = e("61a1");
        for (i in a) "default" !== i && function(t) {
            e.d(n, t, function() {
                return a[t];
            });
        }(i);
        e("533a");
        var c = e("f0c5"), o = Object(c.a)(a.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        n.default = o.exports;
    }
}, [ [ "4b33", "common/runtime", "common/vendor" ] ] ]);