(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/index/bindwxapp" ], {
    2405: function(n, t, e) {
        e.r(t);
        var i, u = e("d1c1"), o = e("edd8");
        for (i in o) "default" !== i && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(i);
        e("c536");
        var a = e("f0c5"), u = Object(a.a)(o.default, u.b, u.c, !1, null, null, null, !1, u.a, void 0);
        t.default = u.exports;
    },
    "44cc": function(n, e, t) {
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var n = {
                data: function() {
                    return {
                        id: 0,
                        name: ""
                    };
                },
                onLoad: function(n) {},
                methods: {
                    handleContact: function(n) {
                        "/pages/index/wxappdetail" == n.detail.path && (n.detail.query && (n.detail.path = n.detail.path + "?id=" + n.detail.query.id), 
                        console.log("path:" + n.detail.path), t.navigateTo({
                            url: n.detail.path
                        })), console.log(n.detail.path), console.log(n.detail.query);
                    }
                }
            };
            e.default = n;
        }).call(this, t("543d").default);
    },
    "5f99": function(n, t, e) {},
    a048: function(n, t, e) {
        (function(n) {
            function t(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            e("f6b2"), t(e("66fd")), n(t(e("2405")).default);
        }).call(this, e("543d").createPage);
    },
    c536: function(n, t, e) {
        var i = e("5f99");
        e.n(i).a;
    },
    d1c1: function(n, t, e) {
        e.d(t, "b", function() {
            return u;
        }), e.d(t, "c", function() {
            return o;
        }), e.d(t, "a", function() {
            return i;
        });
        var i = {
            tuiIcon: function() {
                return e.e("components/thorui/tui-icon/tui-icon").then(e.bind(null, "8a4d"));
            },
            tuiBadge: function() {
                return e.e("components/thorui/tui-badge/tui-badge").then(e.bind(null, "b386"));
            },
            tuiTips: function() {
                return e.e("components/thorui/tui-tips/tui-tips").then(e.bind(null, "9803"));
            }
        }, u = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
    },
    edd8: function(n, t, e) {
        e.r(t);
        var i, u = e("44cc"), o = e.n(u);
        for (i in u) "default" !== i && function(n) {
            e.d(t, n, function() {
                return u[n];
            });
        }(i);
        t.default = o.a;
    }
}, [ [ "a048", "common/runtime", "common/vendor" ] ] ]);