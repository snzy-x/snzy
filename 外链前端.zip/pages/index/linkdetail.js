(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/index/linkdetail" ], {
    "496b": function(t, e, i) {},
    "4bf5": function(t, e, i) {
        i.r(e);
        var a, n = i("77a2"), o = i.n(n);
        for (a in n) "default" !== a && function(t) {
            i.d(e, t, function() {
                return n[t];
            });
        }(a);
        e.default = o.a;
    },
    5859: function(t, e, i) {
        i.r(e);
        var a, n = i("8a4a"), o = i("4bf5");
        for (a in o) "default" !== a && function(t) {
            i.d(e, t, function() {
                return o[t];
            });
        }(a);
        i("cc03");
        var r = i("f0c5"), n = Object(r.a)(o.default, n.b, n.c, !1, null, null, null, !1, n.a, void 0);
        e.default = n.exports;
    },
    7181: function(t, e, i) {
        (function(t) {
            function e(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            i("f6b2"), e(i("66fd")), t(e(i("5859")).default);
        }).call(this, i("543d").createPage);
    },
    "77a2": function(t, l, d) {
        (function(a) {
            Object.defineProperty(l, "__esModule", {
                value: !0
            }), l.default = void 0;
            var t, i = (t = d("6b50")) && t.__esModule ? t : {
                default: t
            };
            function n(t) {
                return function(t) {
                    if (Array.isArray(t)) return o(t);
                }(t) || function(t) {
                    if ("undefined" != typeof Symbol && Symbol.iterator in Object(t)) return Array.from(t);
                }(t) || function(t, e) {
                    if (t) {
                        if ("string" == typeof t) return o(t, e);
                        var i = Object.prototype.toString.call(t).slice(8, -1);
                        return "Object" === i && t.constructor && (i = t.constructor.name), "Map" === i || "Set" === i ? Array.from(t) : "Arguments" === i || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(i) ? o(t, e) : void 0;
                    }
                }(t) || function() {
                    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                }();
            }
            function o(t, e) {
                (null == e || e > t.length) && (e = t.length);
                for (var i = 0, a = new Array(e); i < e; i++) a[i] = t[i];
                return a;
            }
            var r, s = d("14a6"), c = null, u = null, e = {
                data: function() {
                    return {
                        id: 0,
                        toJSON: "",
                        name: "",
                        wxapp: "",
                        link: "",
                        views: "",
                        arrives: "",
                        qrcode: "",
                        expiretime: "",
                        cWidth: "700",
                        cHeight: "200",
                        pixelRatio: 1,
                        chartAData: {
                            categories: [],
                            series: [ {
                                name: "打开次数",
                                data: [],
                                color: "#000000"
                            } ]
                        },
                        chartBData: {
                            categories: [],
                            series: [ {
                                name: "触达次数",
                                data: [],
                                color: "#000000"
                            } ]
                        },
                        promotion: {}
                    };
                },
                onPullDownRefresh: function() {
                    this.getLinkDetail(this.id);
                },
                onShareAppMessage: function() {},
                onReady: function() {},
                onLoad: function(t) {
                    this.id = t.id, this.getLinkDetail(t.id), (r = this).cWidth = a.upx2px(700), this.cHeight = a.upx2px(310);
                    t = a.getStorageSync("config");
                    a.getStorageSync("isvip") && !t.promotion.vipshow || (this.promotion = t.promotion);
                },
                methods: {
                    getLinkDetail: function(t) {
                        var i = this;
                        this.util.request({
                            url: "entry/wxapp/linkDetail",
                            data: {
                                id: t
                            },
                            success: function(t) {
                                console.log(t), i.name = t.data.data.name, i.link = t.data.data.link, i.views = t.data.data.views, 
                                i.arrives = t.data.data.arrives, i.qrcode = t.data.data.qrcode, i.expiretime = t.data.data.expiretime, 
                                i.wxapp = t.data.data.wxapp, a.stopPullDownRefresh();
                                var e = i.chartAData;
                                e.categories = t.data.data.visit.categories, e.series[0].data = t.data.data.visit.views, 
                                e.series[0].color = "#1890ff", e.series[0].type = "line", e.series[0].pointShape = "circle", 
                                e.series[0].legendShape = "line", r.showLineA("canvasLineA", e);
                                e = i.chartBData;
                                e.categories = t.data.data.visit.categories, e.series[0].data = t.data.data.visit.arrives, 
                                e.series[0].color = "#1890ff", e.series[0].type = "line", e.series[0].pointShape = "circle", 
                                e.series[0].legendShape = "line", r.showLineB("canvasLineB", e);
                            },
                            fail: function() {
                                a.stopPullDownRefresh();
                            }
                        });
                    },
                    clipboard: function(t) {
                        var e = this.link;
                        s.getClipboardData(e, function(t) {
                            t && a.showToast({
                                title: "已复制"
                            });
                        }, t);
                    },
                    save: function() {
                        var e = this;
                        a.showToast({
                            icon: "loading",
                            title: "正在保存图片",
                            duration: 1e3
                        }), a.getSetting({
                            success: function(t) {
                                t.authSetting["scope.writePhotosAlbum"] ? e.savePhoto() : a.authorize({
                                    scope: "scope.writePhotosAlbum",
                                    success: function() {
                                        e.savePhoto();
                                    },
                                    fail: function() {
                                        a.openSetting({
                                            success: function() {
                                                a.authorize({
                                                    scope: "scope.writePhotosAlbum",
                                                    success: function() {
                                                        e.savePhoto();
                                                    }
                                                });
                                            }
                                        });
                                    }
                                });
                            }
                        });
                    },
                    savePhoto: function() {
                        a.downloadFile({
                            url: this.qrcode,
                            success: function(t) {
                                a.saveImageToPhotosAlbum({
                                    filePath: t.tempFilePath,
                                    success: function(t) {
                                        a.showToast({
                                            title: "保存成功",
                                            icon: "success",
                                            duration: 1e3
                                        });
                                    }
                                });
                            },
                            fail: function(t) {
                                console.log(t);
                            }
                        });
                    },
                    dellink: function() {
                        this.util.request({
                            url: "entry/wxapp/linkDel",
                            data: {
                                id: this.id
                            },
                            success: function(t) {
                                a.showToast({
                                    icon: "success",
                                    title: t.data.message
                                }), setTimeout(function() {
                                    var t = getCurrentPages(), t = t[t.length - 2];
                                    a.navigateBack(2), t.$vm.refresh();
                                }, 1e3);
                            },
                            complete: function(t) {
                                a.stopPullDownRefresh();
                            }
                        });
                    },
                    showLineA: function(t, e) {
                        c = new i.default({
                            $this: r,
                            canvasId: t,
                            type: "line",
                            fontSize: 11,
                            legend: {
                                show: !0
                            },
                            dataLabel: !1,
                            dataPointShape: !0,
                            background: "#FFFFFF",
                            pixelRatio: r.pixelRatio,
                            categories: e.categories,
                            series: e.series,
                            animation: !0,
                            xAxis: {
                                type: "grid",
                                gridColor: "#CCCCCC",
                                gridType: "dash",
                                dashLength: 8
                            },
                            yAxis: {
                                gridType: "dash",
                                gridColor: "#CCCCCC",
                                dashLength: 7,
                                splitNumber: 5,
                                min: 10,
                                max: 10 * Math.ceil(Math.max.apply(Math, n(e.series[0].data)) / 10),
                                format: function(t) {
                                    return t.toFixed(0) + "次";
                                }
                            },
                            width: r.cWidth * r.pixelRatio,
                            height: r.cHeight * r.pixelRatio,
                            extra: {
                                line: {
                                    type: "straight"
                                }
                            }
                        });
                    },
                    showLineB: function(t, e) {
                        u = new i.default({
                            $this: r,
                            canvasId: t,
                            type: "line",
                            fontSize: 11,
                            legend: {
                                show: !0
                            },
                            dataLabel: !1,
                            dataPointShape: !0,
                            background: "#FFFFFF",
                            pixelRatio: r.pixelRatio,
                            categories: e.categories,
                            series: e.series,
                            animation: !0,
                            xAxis: {
                                type: "grid",
                                gridColor: "#CCCCCC",
                                gridType: "dash",
                                dashLength: 8
                            },
                            yAxis: {
                                gridType: "dash",
                                gridColor: "#CCCCCC",
                                dashLength: 7,
                                splitNumber: 5,
                                min: 10,
                                max: 10 * Math.ceil(Math.max.apply(Math, n(e.series[0].data)) / 10),
                                format: function(t) {
                                    return t.toFixed(0) + "次";
                                }
                            },
                            width: r.cWidth * r.pixelRatio,
                            height: r.cHeight * r.pixelRatio,
                            extra: {
                                line: {
                                    type: "straight"
                                }
                            }
                        });
                    },
                    touchLineA: function(t) {
                        c.showToolTip(t, {
                            format: function(t, e) {
                                return e + " " + t.name + ":" + t.data;
                            }
                        });
                    },
                    touchLineB: function(t) {
                        u.showToolTip(t, {
                            format: function(t, e) {
                                return e + " " + t.name + ":" + t.data;
                            }
                        });
                    }
                }
            };
            l.default = e;
        }).call(this, d("543d").default);
    },
    "8a4a": function(t, e, i) {
        i.d(e, "b", function() {
            return n;
        }), i.d(e, "c", function() {
            return o;
        }), i.d(e, "a", function() {
            return a;
        });
        var a = {
            tuiBadge: function() {
                return i.e("components/thorui/tui-badge/tui-badge").then(i.bind(null, "b386"));
            }
        }, n = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
    },
    cc03: function(t, e, i) {
        var a = i("496b");
        i.n(a).a;
    }
}, [ [ "7181", "common/runtime", "common/vendor" ] ] ]);