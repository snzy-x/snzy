(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/index/addurllink" ], {
    "21f8": function(t, n, e) {
        e.d(n, "b", function() {
            return a;
        }), e.d(n, "c", function() {
            return u;
        }), e.d(n, "a", function() {
            return i;
        });
        var i = {
            tuiIcon: function() {
                return e.e("components/thorui/tui-icon/tui-icon").then(e.bind(null, "8a4d"));
            },
            tuiButton: function() {
                return e.e("components/thorui/tui-button/tui-button").then(e.bind(null, "e9bf"));
            },
            tuiBadge: function() {
                return e.e("components/thorui/tui-badge/tui-badge").then(e.bind(null, "b386"));
            }
        }, a = function() {
            this.$createElement;
            this._self._c;
        }, u = [];
    },
    2924: function(t, n, e) {},
    "2ace": function(t, n, e) {
        e.r(n);
        var i, a = e("21f8"), u = e("d05f");
        for (i in u) "default" !== i && function(t) {
            e.d(n, t, function() {
                return u[t];
            });
        }(i);
        e("d864");
        var o = e("f0c5"), a = Object(o.a)(u.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        n.default = a.exports;
    },
    "821b": function(t, i, a) {
        (function(e) {
            Object.defineProperty(i, "__esModule", {
                value: !0
            }), i.default = void 0;
            var t = a("14a6"), n = {
                data: function() {
                    return {
                        name: "",
                        url: "",
                        type: "",
                        share_title: "",
                        personal_domain: !1,
                        list: {
                            "公众号文章": "gzhwz",
                            "任意网址": "rywz"
                        },
                        appid: "",
                        icon: ""
                    };
                },
                onLoad: function(t) {
                    var n = e.getStorageSync("config");
                    this.appid = n.appid, this.type = t.type, this.icon = "../../static/images/i" + this.list[this.type] + ".jpg", 
                    e.setNavigationBarTitle({
                        title: "创建" + this.type + "链接"
                    }), this.personal_domain = e.getStorageSync("personal_domain");
                },
                methods: {
                    copy: function() {
                        t.getClipboardData(this.appid, function(t) {
                            t && e.showToast({
                                icon: "success",
                                title: "已复制"
                            });
                        });
                    },
                    create: function() {
                        var t = this;
                        this.util.request({
                            url: "entry/wxapp/unilinkCreate",
                            data: {
                                name: t.name,
                                share_title: t.share_title,
                                return: t.url,
                                type: t.type
                            },
                            success: function(n) {
                                e.showToast({
                                    icon: "success",
                                    title: n.data.message
                                }), setTimeout(function() {
                                    var t;
                                    n.data.data.linkid ? e.redirectTo({
                                        url: "./linkdetail?id=" + n.data.data.linkid
                                    }) : (t = (t = getCurrentPages())[t.length - 2], e.navigateBack(2), t.$vm.refresh());
                                }, 1e3);
                            }
                        });
                    },
                    cancel: function() {
                        e.navigateBack({
                            delta: 2
                        });
                    }
                }
            };
            i.default = n;
        }).call(this, a("543d").default);
    },
    "8e10": function(t, n, e) {
        (function(t) {
            function n(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            e("f6b2"), n(e("66fd")), t(n(e("2ace")).default);
        }).call(this, e("543d").createPage);
    },
    d05f: function(t, n, e) {
        e.r(n);
        var i, a = e("821b"), u = e.n(a);
        for (i in a) "default" !== i && function(t) {
            e.d(n, t, function() {
                return a[t];
            });
        }(i);
        n.default = u.a;
    },
    d864: function(t, n, e) {
        var i = e("2924");
        e.n(i).a;
    }
}, [ [ "8e10", "common/runtime", "common/vendor" ] ] ]);