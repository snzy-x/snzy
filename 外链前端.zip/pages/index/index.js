(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/index/index" ], {
    "61e0": function(n, t, o) {
        (function(n) {
            function t(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            o("f6b2"), t(o("66fd")), n(t(o("db9b")).default);
        }).call(this, o("543d").createPage);
    },
    b7b5: function(n, t, o) {
        (function(a) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = {
                data: function() {
                    return {
                        bannerList: [],
                        unilinks: {
                            "微信号": !0,
                            "个人小程序": !0,
                            "公众号文章": !0,
                            "公众号": !0,
                            "微信群": !0,
                            "视频号": !0,
                            "企业微信": !0
                        },
                        promotion: {},
                        config: ""
                    };
                },
                onPullDownRefresh: function() {
                    this.getConfig();
                },
                onShareAppMessage: function() {},
                onLoad: function() {
                    var t = this;
                    this.util.getUserInfo(function(n) {
                        t.getConfig();
                    });
                },
                methods: {
                    getConfig: function() {
                        var t = this;
                        this.util.request({
                            url: "entry/wxapp/config",
                            data: {},
                            success: function(n) {
                                n.data.data.config && (t.bannerList = n.data.data.config.banners, t.unilinks = n.data.data.unilinks, 
                                n.data.data.config.promotion && (a.getStorageSync("isvip") && !n.data.data.config.promotion.vipshow || (t.promotion = n.data.data.config.promotion)), 
                                a.setStorage({
                                    key: "config",
                                    data: n.data.data.config
                                }));
                            },
                            complete: function(n) {
                                a.stopPullDownRefresh();
                            }
                        });
                    },
                    go: function(o) {
                        var e = a.getStorageSync("config"), n = this;
                        "" == e.userinfo.nickname || "" == e.userinfo.avatar ? a.getUserProfile({
                            desc: "获取用户头像与昵称",
                            success: function(t) {
                                console.log(t), t.userInfo.avatarUrl, t.userInfo.nickName, n.util.request({
                                    url: "entry/wxapp/updateUser",
                                    data: {
                                        avatar: t.userInfo.avatarUrl,
                                        nickname: t.userInfo.nickName
                                    },
                                    success: function(n) {
                                        console.log(n), e.userinfo.avatar = t.userInfo.avatarUrl, e.userinfo.nickname = t.userInfo.nickName, 
                                        a.setStorageSync("config", e), a.navigateTo({
                                            url: o
                                        });
                                    }
                                });
                            },
                            fail: function(n) {
                                a.showToast({
                                    icon: "none",
                                    title: "授权拒绝"
                                }), console.log(n);
                            }
                        }) : a.navigateTo({
                            url: o
                        });
                    }
                }
            };
            t.default = n;
        }).call(this, o("543d").default);
    },
    d284: function(n, t, o) {
        o.d(t, "b", function() {
            return a;
        }), o.d(t, "c", function() {
            return i;
        }), o.d(t, "a", function() {
            return e;
        });
        var e = {
            tuiBadge: function() {
                return o.e("components/thorui/tui-badge/tui-badge").then(o.bind(null, "b386"));
            }
        }, a = function() {
            this.$createElement;
            this._self._c;
        }, i = [];
    },
    d83a: function(n, t, o) {
        o.r(t);
        var e, a = o("b7b5"), i = o.n(a);
        for (e in a) "default" !== e && function(n) {
            o.d(t, n, function() {
                return a[n];
            });
        }(e);
        t.default = i.a;
    },
    db9b: function(n, t, o) {
        o.r(t);
        var e, a = o("d284"), i = o("d83a");
        for (e in i) "default" !== e && function(n) {
            o.d(t, n, function() {
                return i[n];
            });
        }(e);
        o("f3dd");
        var u = o("f0c5"), a = Object(u.a)(i.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        t.default = a.exports;
    },
    e374: function(n, t, o) {},
    f3dd: function(n, t, o) {
        var e = o("e374");
        o.n(e).a;
    }
}, [ [ "61e0", "common/runtime", "common/vendor" ] ]

 ]

);