(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/my/my" ], {
    "690d": function(t, n, e) {
        (function(t) {
            function n(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            e("f6b2"), n(e("66fd")), t(n(e("da23")).default);
        }).call(this, e("543d").createPage);
    },
    "75c2": function(t, n, a) {
        (function(e) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var o = a("14a6"), t = {
                data: function() {
                    return {
                        helpurl: "",
                        isvip: "",
                        vipstatus: "",
                        contact: '',
                        userinfo: {
                            id: "",
                            nickname: "",
                            wxapps: "",
                            links: ""
                        },
                        promotion: {}
                    };
                },
                onLoad: function() {
                    this.getUserHome();
                    var t = e.getStorageSync("config");
                    console.log(!e.getStorageSync("isvip")), e.getStorageSync("isvip") && !t.promotion.vipshow || (this.promotion = t.promotion);
                },
                onPullDownRefresh: function() {
                    this.getUserHome();
                },
                methods: {
                    getUserHome: function() {
                        var n = this;
                        this.util.request({
                            url: "entry/wxapp/userHome",
                            data: {},
                            success: function(t) {
                                console.log(t), n.isvip = t.data.data.isvip, n.vipstatus = t.data.data.vipstatus, 
                                n.userinfo = t.data.data.userinfo, n.helpurl = t.data.data.helpurl, 
                                n.contact = t.data.data.contact, 
                                e.setStorageSync("isvip", t.data.data.isvip), e.setStorageSync("personal_domain", t.data.data.personal_domain);
                            },
                            complete: function() {
                                e.stopPullDownRefresh();
                            }
                        });
                    },
                    addWxapp: function() {
                        e.navigateTo({
                            url: "/pages/index/addwxapp"
                        });
                    },
                    premiums: function() {
                        e.navigateTo({
                            url: "/pages/index/premiums"
                        });
                    },
                    myWxapps: function() {
                        e.switchTab({
                            url: "/pages/index/index"
                        });
                    },
                    myLinks: function() {
                        e.switchTab({
                            url: "/pages/my/linklist"
                        });
                    },
                    help: function() {
                        this.helpurl && e.navigateTo({
                            url: "/pages/index/webpage?url=" + this.helpurl
                        });
                    },
                    showcontact: function() {
                        var n = this;
                        this.contact ? e.showModal({
                            title: "联系方式",
                            content: this.contact,
                            confirmText: "复制",
                            cancelText: "取消",
                            success: function(t) {
                                t.confirm && o.getClipboardData(n.contact, function(t) {
                                    t && e.showToast({
                                        icon: "success",
                                        title: "已复制"
                                    });
                                });
                            }
                        }) : e.showToast({
                            icon: "none",
                            title: "敬请期待"
                        });
                    }
                }
            };
            n.default = t;
        }).call(this, a("543d").default);
    },
    9060: function(t, n, e) {
        e.r(n);
        var o, a = e("75c2"), i = e.n(a);
        for (o in a) "default" !== o && function(t) {
            e.d(n, t, function() {
                return a[t];
            });
        }(o);
        n.default = i.a;
    },
    abb9: function(t, n, e) {
        var o = e("f589");
        e.n(o).a;
    },
    da23: function(t, n, e) {
        e.r(n);
        var o, a = e("f9e3"), i = e("9060");
        for (o in i) "default" !== o && function(t) {
            e.d(n, t, function() {
                return i[t];
            });
        }(o);
        e("abb9");
        var u = e("f0c5"), a = Object(u.a)(i.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        n.default = a.exports;
    },
    f589: function(t, n, e) {},
    f9e3: function(t, n, e) {
        e.d(n, "b", function() {
            return a;
        }), e.d(n, "c", function() {
            return i;
        }), e.d(n, "a", function() {
            return o;
        });
        var o = {
            tuiButton: function() {
                return e.e("components/thorui/tui-button/tui-button").then(e.bind(null, "e9bf"));
            },
            tuiBadge: function() {
                return e.e("components/thorui/tui-badge/tui-badge").then(e.bind(null, "b386"));
            }
        }, a = function() {
            this.$createElement;
            this._self._c;
        }, i = [];
    }
}, [ [ "690d", "common/runtime", "common/vendor" ] ] ]);